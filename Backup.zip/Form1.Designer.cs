﻿namespace LodeRunner
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.imgBlocks = new System.Windows.Forms.ImageList(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.pic000 = new System.Windows.Forms.PictureBox();
            this.pic010 = new System.Windows.Forms.PictureBox();
            this.pic020 = new System.Windows.Forms.PictureBox();
            this.pic030 = new System.Windows.Forms.PictureBox();
            this.pic040 = new System.Windows.Forms.PictureBox();
            this.pic050 = new System.Windows.Forms.PictureBox();
            this.pic060 = new System.Windows.Forms.PictureBox();
            this.pic070 = new System.Windows.Forms.PictureBox();
            this.pic080 = new System.Windows.Forms.PictureBox();
            this.pic090 = new System.Windows.Forms.PictureBox();
            this.pic0A0 = new System.Windows.Forms.PictureBox();
            this.pic0B0 = new System.Windows.Forms.PictureBox();
            this.pic0C0 = new System.Windows.Forms.PictureBox();
            this.pic0D0 = new System.Windows.Forms.PictureBox();
            this.pic0E0 = new System.Windows.Forms.PictureBox();
            this.pic0F0 = new System.Windows.Forms.PictureBox();
            this.pic100 = new System.Windows.Forms.PictureBox();
            this.pic110 = new System.Windows.Forms.PictureBox();
            this.pic120 = new System.Windows.Forms.PictureBox();
            this.pic130 = new System.Windows.Forms.PictureBox();
            this.pic140 = new System.Windows.Forms.PictureBox();
            this.pic150 = new System.Windows.Forms.PictureBox();
            this.pic160 = new System.Windows.Forms.PictureBox();
            this.pic170 = new System.Windows.Forms.PictureBox();
            this.pic180 = new System.Windows.Forms.PictureBox();
            this.pic190 = new System.Windows.Forms.PictureBox();
            this.pic1A0 = new System.Windows.Forms.PictureBox();
            this.pic1B0 = new System.Windows.Forms.PictureBox();
            this.pic001 = new System.Windows.Forms.PictureBox();
            this.pic011 = new System.Windows.Forms.PictureBox();
            this.pic021 = new System.Windows.Forms.PictureBox();
            this.pic031 = new System.Windows.Forms.PictureBox();
            this.pic041 = new System.Windows.Forms.PictureBox();
            this.pic051 = new System.Windows.Forms.PictureBox();
            this.pic061 = new System.Windows.Forms.PictureBox();
            this.pic071 = new System.Windows.Forms.PictureBox();
            this.pic081 = new System.Windows.Forms.PictureBox();
            this.pic091 = new System.Windows.Forms.PictureBox();
            this.pic0A1 = new System.Windows.Forms.PictureBox();
            this.pic0B1 = new System.Windows.Forms.PictureBox();
            this.pic0C1 = new System.Windows.Forms.PictureBox();
            this.pic0D1 = new System.Windows.Forms.PictureBox();
            this.pic0E1 = new System.Windows.Forms.PictureBox();
            this.pic0F1 = new System.Windows.Forms.PictureBox();
            this.pic101 = new System.Windows.Forms.PictureBox();
            this.pic111 = new System.Windows.Forms.PictureBox();
            this.pic121 = new System.Windows.Forms.PictureBox();
            this.pic131 = new System.Windows.Forms.PictureBox();
            this.pic141 = new System.Windows.Forms.PictureBox();
            this.pic151 = new System.Windows.Forms.PictureBox();
            this.pic161 = new System.Windows.Forms.PictureBox();
            this.pic171 = new System.Windows.Forms.PictureBox();
            this.pic181 = new System.Windows.Forms.PictureBox();
            this.pic191 = new System.Windows.Forms.PictureBox();
            this.pic1A1 = new System.Windows.Forms.PictureBox();
            this.pic1B1 = new System.Windows.Forms.PictureBox();
            this.pic002 = new System.Windows.Forms.PictureBox();
            this.pic012 = new System.Windows.Forms.PictureBox();
            this.pic022 = new System.Windows.Forms.PictureBox();
            this.pic032 = new System.Windows.Forms.PictureBox();
            this.pic042 = new System.Windows.Forms.PictureBox();
            this.pic052 = new System.Windows.Forms.PictureBox();
            this.pic062 = new System.Windows.Forms.PictureBox();
            this.pic072 = new System.Windows.Forms.PictureBox();
            this.pic082 = new System.Windows.Forms.PictureBox();
            this.pic092 = new System.Windows.Forms.PictureBox();
            this.pic0A2 = new System.Windows.Forms.PictureBox();
            this.pic0B2 = new System.Windows.Forms.PictureBox();
            this.pic0C2 = new System.Windows.Forms.PictureBox();
            this.pic0D2 = new System.Windows.Forms.PictureBox();
            this.pic0E2 = new System.Windows.Forms.PictureBox();
            this.pic0F2 = new System.Windows.Forms.PictureBox();
            this.pic102 = new System.Windows.Forms.PictureBox();
            this.pic112 = new System.Windows.Forms.PictureBox();
            this.pic122 = new System.Windows.Forms.PictureBox();
            this.pic132 = new System.Windows.Forms.PictureBox();
            this.pic142 = new System.Windows.Forms.PictureBox();
            this.pic152 = new System.Windows.Forms.PictureBox();
            this.pic162 = new System.Windows.Forms.PictureBox();
            this.pic172 = new System.Windows.Forms.PictureBox();
            this.pic182 = new System.Windows.Forms.PictureBox();
            this.pic192 = new System.Windows.Forms.PictureBox();
            this.pic1A2 = new System.Windows.Forms.PictureBox();
            this.pic1B2 = new System.Windows.Forms.PictureBox();
            this.pic003 = new System.Windows.Forms.PictureBox();
            this.pic013 = new System.Windows.Forms.PictureBox();
            this.pic023 = new System.Windows.Forms.PictureBox();
            this.pic033 = new System.Windows.Forms.PictureBox();
            this.pic043 = new System.Windows.Forms.PictureBox();
            this.pic053 = new System.Windows.Forms.PictureBox();
            this.pic063 = new System.Windows.Forms.PictureBox();
            this.pic073 = new System.Windows.Forms.PictureBox();
            this.pic083 = new System.Windows.Forms.PictureBox();
            this.pic093 = new System.Windows.Forms.PictureBox();
            this.pic0A3 = new System.Windows.Forms.PictureBox();
            this.pic0B3 = new System.Windows.Forms.PictureBox();
            this.pic0C3 = new System.Windows.Forms.PictureBox();
            this.pic0D3 = new System.Windows.Forms.PictureBox();
            this.pic0E3 = new System.Windows.Forms.PictureBox();
            this.pic0F3 = new System.Windows.Forms.PictureBox();
            this.pic103 = new System.Windows.Forms.PictureBox();
            this.pic113 = new System.Windows.Forms.PictureBox();
            this.pic123 = new System.Windows.Forms.PictureBox();
            this.pic133 = new System.Windows.Forms.PictureBox();
            this.pic143 = new System.Windows.Forms.PictureBox();
            this.pic153 = new System.Windows.Forms.PictureBox();
            this.pic163 = new System.Windows.Forms.PictureBox();
            this.pic173 = new System.Windows.Forms.PictureBox();
            this.pic183 = new System.Windows.Forms.PictureBox();
            this.pic193 = new System.Windows.Forms.PictureBox();
            this.pic1A3 = new System.Windows.Forms.PictureBox();
            this.pic1B3 = new System.Windows.Forms.PictureBox();
            this.pic004 = new System.Windows.Forms.PictureBox();
            this.pic014 = new System.Windows.Forms.PictureBox();
            this.pic024 = new System.Windows.Forms.PictureBox();
            this.pic034 = new System.Windows.Forms.PictureBox();
            this.pic044 = new System.Windows.Forms.PictureBox();
            this.pic054 = new System.Windows.Forms.PictureBox();
            this.pic064 = new System.Windows.Forms.PictureBox();
            this.pic074 = new System.Windows.Forms.PictureBox();
            this.pic084 = new System.Windows.Forms.PictureBox();
            this.pic094 = new System.Windows.Forms.PictureBox();
            this.pic0A4 = new System.Windows.Forms.PictureBox();
            this.pic0B4 = new System.Windows.Forms.PictureBox();
            this.pic0C4 = new System.Windows.Forms.PictureBox();
            this.pic0D4 = new System.Windows.Forms.PictureBox();
            this.pic0E4 = new System.Windows.Forms.PictureBox();
            this.pic0F4 = new System.Windows.Forms.PictureBox();
            this.pic104 = new System.Windows.Forms.PictureBox();
            this.pic114 = new System.Windows.Forms.PictureBox();
            this.pic124 = new System.Windows.Forms.PictureBox();
            this.pic134 = new System.Windows.Forms.PictureBox();
            this.pic144 = new System.Windows.Forms.PictureBox();
            this.pic154 = new System.Windows.Forms.PictureBox();
            this.pic164 = new System.Windows.Forms.PictureBox();
            this.pic174 = new System.Windows.Forms.PictureBox();
            this.pic184 = new System.Windows.Forms.PictureBox();
            this.pic194 = new System.Windows.Forms.PictureBox();
            this.pic1A4 = new System.Windows.Forms.PictureBox();
            this.pic1B4 = new System.Windows.Forms.PictureBox();
            this.pic005 = new System.Windows.Forms.PictureBox();
            this.pic015 = new System.Windows.Forms.PictureBox();
            this.pic025 = new System.Windows.Forms.PictureBox();
            this.pic035 = new System.Windows.Forms.PictureBox();
            this.pic045 = new System.Windows.Forms.PictureBox();
            this.pic055 = new System.Windows.Forms.PictureBox();
            this.pic065 = new System.Windows.Forms.PictureBox();
            this.pic075 = new System.Windows.Forms.PictureBox();
            this.pic085 = new System.Windows.Forms.PictureBox();
            this.pic095 = new System.Windows.Forms.PictureBox();
            this.pic0A5 = new System.Windows.Forms.PictureBox();
            this.pic0B5 = new System.Windows.Forms.PictureBox();
            this.pic0C5 = new System.Windows.Forms.PictureBox();
            this.pic0D5 = new System.Windows.Forms.PictureBox();
            this.pic0E5 = new System.Windows.Forms.PictureBox();
            this.pic0F5 = new System.Windows.Forms.PictureBox();
            this.pic105 = new System.Windows.Forms.PictureBox();
            this.pic115 = new System.Windows.Forms.PictureBox();
            this.pic125 = new System.Windows.Forms.PictureBox();
            this.pic135 = new System.Windows.Forms.PictureBox();
            this.pic145 = new System.Windows.Forms.PictureBox();
            this.pic155 = new System.Windows.Forms.PictureBox();
            this.pic165 = new System.Windows.Forms.PictureBox();
            this.pic175 = new System.Windows.Forms.PictureBox();
            this.pic185 = new System.Windows.Forms.PictureBox();
            this.pic195 = new System.Windows.Forms.PictureBox();
            this.pic1A5 = new System.Windows.Forms.PictureBox();
            this.pic1B5 = new System.Windows.Forms.PictureBox();
            this.pic006 = new System.Windows.Forms.PictureBox();
            this.pic016 = new System.Windows.Forms.PictureBox();
            this.pic026 = new System.Windows.Forms.PictureBox();
            this.pic036 = new System.Windows.Forms.PictureBox();
            this.pic046 = new System.Windows.Forms.PictureBox();
            this.pic056 = new System.Windows.Forms.PictureBox();
            this.pic066 = new System.Windows.Forms.PictureBox();
            this.pic076 = new System.Windows.Forms.PictureBox();
            this.pic086 = new System.Windows.Forms.PictureBox();
            this.pic096 = new System.Windows.Forms.PictureBox();
            this.pic0A6 = new System.Windows.Forms.PictureBox();
            this.pic0B6 = new System.Windows.Forms.PictureBox();
            this.pic0C6 = new System.Windows.Forms.PictureBox();
            this.pic0D6 = new System.Windows.Forms.PictureBox();
            this.pic0E6 = new System.Windows.Forms.PictureBox();
            this.pic0F6 = new System.Windows.Forms.PictureBox();
            this.pic106 = new System.Windows.Forms.PictureBox();
            this.pic116 = new System.Windows.Forms.PictureBox();
            this.pic126 = new System.Windows.Forms.PictureBox();
            this.pic136 = new System.Windows.Forms.PictureBox();
            this.pic146 = new System.Windows.Forms.PictureBox();
            this.pic156 = new System.Windows.Forms.PictureBox();
            this.pic166 = new System.Windows.Forms.PictureBox();
            this.pic176 = new System.Windows.Forms.PictureBox();
            this.pic186 = new System.Windows.Forms.PictureBox();
            this.pic196 = new System.Windows.Forms.PictureBox();
            this.pic1A6 = new System.Windows.Forms.PictureBox();
            this.pic1B6 = new System.Windows.Forms.PictureBox();
            this.pic007 = new System.Windows.Forms.PictureBox();
            this.pic017 = new System.Windows.Forms.PictureBox();
            this.pic027 = new System.Windows.Forms.PictureBox();
            this.pic037 = new System.Windows.Forms.PictureBox();
            this.pic047 = new System.Windows.Forms.PictureBox();
            this.pic057 = new System.Windows.Forms.PictureBox();
            this.pic067 = new System.Windows.Forms.PictureBox();
            this.pic077 = new System.Windows.Forms.PictureBox();
            this.pic087 = new System.Windows.Forms.PictureBox();
            this.pic097 = new System.Windows.Forms.PictureBox();
            this.pic0A7 = new System.Windows.Forms.PictureBox();
            this.pic0B7 = new System.Windows.Forms.PictureBox();
            this.pic0C7 = new System.Windows.Forms.PictureBox();
            this.pic0D7 = new System.Windows.Forms.PictureBox();
            this.pic0E7 = new System.Windows.Forms.PictureBox();
            this.pic0F7 = new System.Windows.Forms.PictureBox();
            this.pic107 = new System.Windows.Forms.PictureBox();
            this.pic117 = new System.Windows.Forms.PictureBox();
            this.pic127 = new System.Windows.Forms.PictureBox();
            this.pic137 = new System.Windows.Forms.PictureBox();
            this.pic147 = new System.Windows.Forms.PictureBox();
            this.pic157 = new System.Windows.Forms.PictureBox();
            this.pic167 = new System.Windows.Forms.PictureBox();
            this.pic177 = new System.Windows.Forms.PictureBox();
            this.pic187 = new System.Windows.Forms.PictureBox();
            this.pic197 = new System.Windows.Forms.PictureBox();
            this.pic1A7 = new System.Windows.Forms.PictureBox();
            this.pic1B7 = new System.Windows.Forms.PictureBox();
            this.pic008 = new System.Windows.Forms.PictureBox();
            this.pic018 = new System.Windows.Forms.PictureBox();
            this.pic028 = new System.Windows.Forms.PictureBox();
            this.pic038 = new System.Windows.Forms.PictureBox();
            this.pic048 = new System.Windows.Forms.PictureBox();
            this.pic058 = new System.Windows.Forms.PictureBox();
            this.pic068 = new System.Windows.Forms.PictureBox();
            this.pic078 = new System.Windows.Forms.PictureBox();
            this.pic088 = new System.Windows.Forms.PictureBox();
            this.pic098 = new System.Windows.Forms.PictureBox();
            this.pic0A8 = new System.Windows.Forms.PictureBox();
            this.pic0B8 = new System.Windows.Forms.PictureBox();
            this.pic0C8 = new System.Windows.Forms.PictureBox();
            this.pic0D8 = new System.Windows.Forms.PictureBox();
            this.pic0E8 = new System.Windows.Forms.PictureBox();
            this.pic0F8 = new System.Windows.Forms.PictureBox();
            this.pic108 = new System.Windows.Forms.PictureBox();
            this.pic118 = new System.Windows.Forms.PictureBox();
            this.pic128 = new System.Windows.Forms.PictureBox();
            this.pic138 = new System.Windows.Forms.PictureBox();
            this.pic148 = new System.Windows.Forms.PictureBox();
            this.pic158 = new System.Windows.Forms.PictureBox();
            this.pic168 = new System.Windows.Forms.PictureBox();
            this.pic178 = new System.Windows.Forms.PictureBox();
            this.pic188 = new System.Windows.Forms.PictureBox();
            this.pic198 = new System.Windows.Forms.PictureBox();
            this.pic1A8 = new System.Windows.Forms.PictureBox();
            this.pic1B8 = new System.Windows.Forms.PictureBox();
            this.pic009 = new System.Windows.Forms.PictureBox();
            this.pic019 = new System.Windows.Forms.PictureBox();
            this.pic029 = new System.Windows.Forms.PictureBox();
            this.pic039 = new System.Windows.Forms.PictureBox();
            this.pic049 = new System.Windows.Forms.PictureBox();
            this.pic059 = new System.Windows.Forms.PictureBox();
            this.pic069 = new System.Windows.Forms.PictureBox();
            this.pic079 = new System.Windows.Forms.PictureBox();
            this.pic089 = new System.Windows.Forms.PictureBox();
            this.pic099 = new System.Windows.Forms.PictureBox();
            this.pic0A9 = new System.Windows.Forms.PictureBox();
            this.pic0B9 = new System.Windows.Forms.PictureBox();
            this.pic0C9 = new System.Windows.Forms.PictureBox();
            this.pic0D9 = new System.Windows.Forms.PictureBox();
            this.pic0E9 = new System.Windows.Forms.PictureBox();
            this.pic0F9 = new System.Windows.Forms.PictureBox();
            this.pic109 = new System.Windows.Forms.PictureBox();
            this.pic119 = new System.Windows.Forms.PictureBox();
            this.pic129 = new System.Windows.Forms.PictureBox();
            this.pic139 = new System.Windows.Forms.PictureBox();
            this.pic149 = new System.Windows.Forms.PictureBox();
            this.pic159 = new System.Windows.Forms.PictureBox();
            this.pic169 = new System.Windows.Forms.PictureBox();
            this.pic179 = new System.Windows.Forms.PictureBox();
            this.pic189 = new System.Windows.Forms.PictureBox();
            this.pic199 = new System.Windows.Forms.PictureBox();
            this.pic1A9 = new System.Windows.Forms.PictureBox();
            this.pic1B9 = new System.Windows.Forms.PictureBox();
            this.pic00A = new System.Windows.Forms.PictureBox();
            this.pic01A = new System.Windows.Forms.PictureBox();
            this.pic02A = new System.Windows.Forms.PictureBox();
            this.pic03A = new System.Windows.Forms.PictureBox();
            this.pic04A = new System.Windows.Forms.PictureBox();
            this.pic05A = new System.Windows.Forms.PictureBox();
            this.pic06A = new System.Windows.Forms.PictureBox();
            this.pic07A = new System.Windows.Forms.PictureBox();
            this.pic08A = new System.Windows.Forms.PictureBox();
            this.pic09A = new System.Windows.Forms.PictureBox();
            this.pic0AA = new System.Windows.Forms.PictureBox();
            this.pic0BA = new System.Windows.Forms.PictureBox();
            this.pic0CA = new System.Windows.Forms.PictureBox();
            this.pic0DA = new System.Windows.Forms.PictureBox();
            this.pic0EA = new System.Windows.Forms.PictureBox();
            this.pic0FA = new System.Windows.Forms.PictureBox();
            this.pic10A = new System.Windows.Forms.PictureBox();
            this.pic11A = new System.Windows.Forms.PictureBox();
            this.pic12A = new System.Windows.Forms.PictureBox();
            this.pic13A = new System.Windows.Forms.PictureBox();
            this.pic14A = new System.Windows.Forms.PictureBox();
            this.pic15A = new System.Windows.Forms.PictureBox();
            this.pic16A = new System.Windows.Forms.PictureBox();
            this.pic17A = new System.Windows.Forms.PictureBox();
            this.pic18A = new System.Windows.Forms.PictureBox();
            this.pic19A = new System.Windows.Forms.PictureBox();
            this.pic1AA = new System.Windows.Forms.PictureBox();
            this.pic1BA = new System.Windows.Forms.PictureBox();
            this.pic00B = new System.Windows.Forms.PictureBox();
            this.pic01B = new System.Windows.Forms.PictureBox();
            this.pic02B = new System.Windows.Forms.PictureBox();
            this.pic03B = new System.Windows.Forms.PictureBox();
            this.pic04B = new System.Windows.Forms.PictureBox();
            this.pic05B = new System.Windows.Forms.PictureBox();
            this.pic06B = new System.Windows.Forms.PictureBox();
            this.pic07B = new System.Windows.Forms.PictureBox();
            this.pic08B = new System.Windows.Forms.PictureBox();
            this.pic09B = new System.Windows.Forms.PictureBox();
            this.pic0AB = new System.Windows.Forms.PictureBox();
            this.pic0BB = new System.Windows.Forms.PictureBox();
            this.pic0CB = new System.Windows.Forms.PictureBox();
            this.pic0DB = new System.Windows.Forms.PictureBox();
            this.pic0EB = new System.Windows.Forms.PictureBox();
            this.pic0FB = new System.Windows.Forms.PictureBox();
            this.pic10B = new System.Windows.Forms.PictureBox();
            this.pic11B = new System.Windows.Forms.PictureBox();
            this.pic12B = new System.Windows.Forms.PictureBox();
            this.pic13B = new System.Windows.Forms.PictureBox();
            this.pic14B = new System.Windows.Forms.PictureBox();
            this.pic15B = new System.Windows.Forms.PictureBox();
            this.pic16B = new System.Windows.Forms.PictureBox();
            this.pic17B = new System.Windows.Forms.PictureBox();
            this.pic18B = new System.Windows.Forms.PictureBox();
            this.pic19B = new System.Windows.Forms.PictureBox();
            this.pic1AB = new System.Windows.Forms.PictureBox();
            this.pic1BB = new System.Windows.Forms.PictureBox();
            this.pic00C = new System.Windows.Forms.PictureBox();
            this.pic01C = new System.Windows.Forms.PictureBox();
            this.pic02C = new System.Windows.Forms.PictureBox();
            this.pic03C = new System.Windows.Forms.PictureBox();
            this.pic04C = new System.Windows.Forms.PictureBox();
            this.pic05C = new System.Windows.Forms.PictureBox();
            this.pic06C = new System.Windows.Forms.PictureBox();
            this.pic07C = new System.Windows.Forms.PictureBox();
            this.pic08C = new System.Windows.Forms.PictureBox();
            this.pic09C = new System.Windows.Forms.PictureBox();
            this.pic0AC = new System.Windows.Forms.PictureBox();
            this.pic0BC = new System.Windows.Forms.PictureBox();
            this.pic0CC = new System.Windows.Forms.PictureBox();
            this.pic0DC = new System.Windows.Forms.PictureBox();
            this.pic0EC = new System.Windows.Forms.PictureBox();
            this.pic0FC = new System.Windows.Forms.PictureBox();
            this.pic10C = new System.Windows.Forms.PictureBox();
            this.pic11C = new System.Windows.Forms.PictureBox();
            this.pic12C = new System.Windows.Forms.PictureBox();
            this.pic13C = new System.Windows.Forms.PictureBox();
            this.pic14C = new System.Windows.Forms.PictureBox();
            this.pic15C = new System.Windows.Forms.PictureBox();
            this.pic16C = new System.Windows.Forms.PictureBox();
            this.pic17C = new System.Windows.Forms.PictureBox();
            this.pic18C = new System.Windows.Forms.PictureBox();
            this.pic19C = new System.Windows.Forms.PictureBox();
            this.pic1AC = new System.Windows.Forms.PictureBox();
            this.pic1BC = new System.Windows.Forms.PictureBox();
            this.pic00D = new System.Windows.Forms.PictureBox();
            this.pic01D = new System.Windows.Forms.PictureBox();
            this.pic02D = new System.Windows.Forms.PictureBox();
            this.pic03D = new System.Windows.Forms.PictureBox();
            this.pic04D = new System.Windows.Forms.PictureBox();
            this.pic05D = new System.Windows.Forms.PictureBox();
            this.pic06D = new System.Windows.Forms.PictureBox();
            this.pic07D = new System.Windows.Forms.PictureBox();
            this.pic08D = new System.Windows.Forms.PictureBox();
            this.pic09D = new System.Windows.Forms.PictureBox();
            this.pic0AD = new System.Windows.Forms.PictureBox();
            this.pic0BD = new System.Windows.Forms.PictureBox();
            this.pic0CD = new System.Windows.Forms.PictureBox();
            this.pic0DD = new System.Windows.Forms.PictureBox();
            this.pic0ED = new System.Windows.Forms.PictureBox();
            this.pic0FD = new System.Windows.Forms.PictureBox();
            this.pic10D = new System.Windows.Forms.PictureBox();
            this.pic11D = new System.Windows.Forms.PictureBox();
            this.pic12D = new System.Windows.Forms.PictureBox();
            this.pic13D = new System.Windows.Forms.PictureBox();
            this.pic14D = new System.Windows.Forms.PictureBox();
            this.pic15D = new System.Windows.Forms.PictureBox();
            this.pic16D = new System.Windows.Forms.PictureBox();
            this.pic17D = new System.Windows.Forms.PictureBox();
            this.pic18D = new System.Windows.Forms.PictureBox();
            this.pic19D = new System.Windows.Forms.PictureBox();
            this.pic1AD = new System.Windows.Forms.PictureBox();
            this.pic1BD = new System.Windows.Forms.PictureBox();
            this.pic00E = new System.Windows.Forms.PictureBox();
            this.pic01E = new System.Windows.Forms.PictureBox();
            this.pic02E = new System.Windows.Forms.PictureBox();
            this.pic03E = new System.Windows.Forms.PictureBox();
            this.pic04E = new System.Windows.Forms.PictureBox();
            this.pic05E = new System.Windows.Forms.PictureBox();
            this.pic06E = new System.Windows.Forms.PictureBox();
            this.pic07E = new System.Windows.Forms.PictureBox();
            this.pic08E = new System.Windows.Forms.PictureBox();
            this.pic09E = new System.Windows.Forms.PictureBox();
            this.pic0AE = new System.Windows.Forms.PictureBox();
            this.pic0BE = new System.Windows.Forms.PictureBox();
            this.pic0CE = new System.Windows.Forms.PictureBox();
            this.pic0DE = new System.Windows.Forms.PictureBox();
            this.pic0EE = new System.Windows.Forms.PictureBox();
            this.pic0FE = new System.Windows.Forms.PictureBox();
            this.pic10E = new System.Windows.Forms.PictureBox();
            this.pic11E = new System.Windows.Forms.PictureBox();
            this.pic12E = new System.Windows.Forms.PictureBox();
            this.pic13E = new System.Windows.Forms.PictureBox();
            this.pic14E = new System.Windows.Forms.PictureBox();
            this.pic15E = new System.Windows.Forms.PictureBox();
            this.pic16E = new System.Windows.Forms.PictureBox();
            this.pic17E = new System.Windows.Forms.PictureBox();
            this.pic18E = new System.Windows.Forms.PictureBox();
            this.pic19E = new System.Windows.Forms.PictureBox();
            this.pic1AE = new System.Windows.Forms.PictureBox();
            this.pic1BE = new System.Windows.Forms.PictureBox();
            this.pic00F = new System.Windows.Forms.PictureBox();
            this.pic01F = new System.Windows.Forms.PictureBox();
            this.pic02F = new System.Windows.Forms.PictureBox();
            this.pic03F = new System.Windows.Forms.PictureBox();
            this.pic04F = new System.Windows.Forms.PictureBox();
            this.pic05F = new System.Windows.Forms.PictureBox();
            this.pic06F = new System.Windows.Forms.PictureBox();
            this.pic07F = new System.Windows.Forms.PictureBox();
            this.pic08F = new System.Windows.Forms.PictureBox();
            this.pic09F = new System.Windows.Forms.PictureBox();
            this.pic0AF = new System.Windows.Forms.PictureBox();
            this.pic0BF = new System.Windows.Forms.PictureBox();
            this.pic0CF = new System.Windows.Forms.PictureBox();
            this.pic0DF = new System.Windows.Forms.PictureBox();
            this.pic0EF = new System.Windows.Forms.PictureBox();
            this.pic0FF = new System.Windows.Forms.PictureBox();
            this.pic10F = new System.Windows.Forms.PictureBox();
            this.pic11F = new System.Windows.Forms.PictureBox();
            this.pic12F = new System.Windows.Forms.PictureBox();
            this.pic13F = new System.Windows.Forms.PictureBox();
            this.pic14F = new System.Windows.Forms.PictureBox();
            this.pic15F = new System.Windows.Forms.PictureBox();
            this.pic16F = new System.Windows.Forms.PictureBox();
            this.pic17F = new System.Windows.Forms.PictureBox();
            this.pic18F = new System.Windows.Forms.PictureBox();
            this.pic19F = new System.Windows.Forms.PictureBox();
            this.pic1AF = new System.Windows.Forms.PictureBox();
            this.pic1BF = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic000)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic010)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic020)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic030)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic040)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic050)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic060)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic070)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic080)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic090)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0A0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0B0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0C0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0D0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0E0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0F0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic100)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic110)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic120)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic130)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic140)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic150)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic160)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic170)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic180)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic190)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1A0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1B0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic001)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic011)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic021)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic031)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic041)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic051)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic061)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic071)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic081)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic091)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0A1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0B1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0C1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0D1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0E1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0F1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic101)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic111)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic121)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic131)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic141)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic151)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic161)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic171)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic181)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic191)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1A1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1B1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic002)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic012)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic022)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic032)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic042)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic052)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic062)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic072)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic082)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic092)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0A2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0B2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0C2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0D2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0E2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0F2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic102)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic112)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic122)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic132)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic142)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic152)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic162)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic172)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic182)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic192)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1A2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1B2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic003)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic013)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic023)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic033)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic043)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic053)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic063)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic073)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic083)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic093)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0A3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0B3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0C3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0D3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0E3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0F3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic103)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic113)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic123)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic133)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic143)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic153)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic163)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic173)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic183)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic193)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1A3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1B3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic004)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic014)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic024)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic034)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic044)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic054)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic064)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic074)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic084)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic094)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0A4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0B4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0C4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0D4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0E4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0F4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic104)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic114)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic124)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic134)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic144)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic154)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic164)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic174)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic184)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic194)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1A4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1B4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic005)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic015)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic025)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic035)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic045)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic055)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic065)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic075)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic085)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic095)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0A5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0B5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0C5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0D5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0E5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0F5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic105)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic115)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic125)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic135)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic145)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic155)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic165)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic175)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic185)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic195)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1A5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1B5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic006)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic016)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic026)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic036)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic046)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic056)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic066)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic076)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic086)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic096)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0A6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0B6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0C6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0D6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0E6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0F6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic106)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic116)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic126)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic136)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic146)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic156)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic166)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic176)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic186)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic196)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1A6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1B6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic007)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic017)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic027)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic037)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic047)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic057)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic067)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic077)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic087)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic097)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0A7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0B7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0C7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0D7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0E7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0F7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic107)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic117)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic127)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic137)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic147)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic157)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic167)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic177)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic187)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic197)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1A7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1B7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic008)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic018)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic028)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic038)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic048)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic058)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic068)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic078)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic088)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic098)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0A8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0B8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0C8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0D8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0E8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0F8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic108)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic118)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic128)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic138)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic148)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic158)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic168)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic178)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic188)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic198)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1A8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1B8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic009)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic019)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic029)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic039)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic049)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic059)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic069)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic079)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic089)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic099)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0A9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0B9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0C9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0D9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0E9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0F9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic109)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic119)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic129)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic139)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic149)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic159)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic169)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic179)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic189)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic199)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1A9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1B9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic00A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic01A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic02A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic03A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic04A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic05A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic06A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic07A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic08A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic09A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0AA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0BA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0CA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0DA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0EA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0FA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic10A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic11A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic12A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic13A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic14A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic15A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic16A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic17A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic18A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic19A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1AA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1BA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic00B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic01B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic02B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic03B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic04B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic05B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic06B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic07B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic08B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic09B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0AB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0BB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0CB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0DB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0EB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0FB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic10B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic11B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic12B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic13B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic14B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic15B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic16B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic17B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic18B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic19B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1AB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1BB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic00C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic01C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic02C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic03C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic04C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic05C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic06C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic07C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic08C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic09C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0AC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0BC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0CC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0DC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0EC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0FC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic10C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic11C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic12C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic13C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic14C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic15C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic16C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic17C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic18C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic19C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1AC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1BC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic00D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic01D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic02D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic03D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic04D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic05D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic06D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic07D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic08D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic09D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0AD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0BD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0CD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0DD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0ED)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0FD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic10D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic11D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic12D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic13D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic14D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic15D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic16D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic17D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic18D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic19D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1AD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1BD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic00E)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic01E)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic02E)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic03E)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic04E)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic05E)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic06E)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic07E)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic08E)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic09E)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0AE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0BE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0CE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0DE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0EE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0FE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic10E)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic11E)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic12E)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic13E)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic14E)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic15E)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic16E)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic17E)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic18E)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic19E)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1AE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1BE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic00F)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic01F)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic02F)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic03F)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic04F)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic05F)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic06F)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic07F)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic08F)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic09F)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0AF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0BF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0CF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0DF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0EF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0FF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic10F)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic11F)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic12F)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic13F)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic14F)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic15F)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic16F)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic17F)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic18F)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic19F)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1AF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1BF)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // imgBlocks
            // 
            this.imgBlocks.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgBlocks.ImageStream")));
            this.imgBlocks.TransparentColor = System.Drawing.Color.Transparent;
            this.imgBlocks.Images.SetKeyName(0, "Blank.png");
            this.imgBlocks.Images.SetKeyName(1, "Brick.png");
            this.imgBlocks.Images.SetKeyName(2, "Soild.png");
            this.imgBlocks.Images.SetKeyName(3, "Ladder1.png");
            this.imgBlocks.Images.SetKeyName(4, "Rail.png");
            this.imgBlocks.Images.SetKeyName(5, "Fallthrough.png");
            this.imgBlocks.Images.SetKeyName(6, "Gold.png");
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.pic000);
            this.panel1.Controls.Add(this.pic010);
            this.panel1.Controls.Add(this.pic020);
            this.panel1.Controls.Add(this.pic030);
            this.panel1.Controls.Add(this.pic040);
            this.panel1.Controls.Add(this.pic050);
            this.panel1.Controls.Add(this.pic060);
            this.panel1.Controls.Add(this.pic070);
            this.panel1.Controls.Add(this.pic080);
            this.panel1.Controls.Add(this.pic090);
            this.panel1.Controls.Add(this.pic0A0);
            this.panel1.Controls.Add(this.pic0B0);
            this.panel1.Controls.Add(this.pic0C0);
            this.panel1.Controls.Add(this.pic0D0);
            this.panel1.Controls.Add(this.pic0E0);
            this.panel1.Controls.Add(this.pic0F0);
            this.panel1.Controls.Add(this.pic100);
            this.panel1.Controls.Add(this.pic110);
            this.panel1.Controls.Add(this.pic120);
            this.panel1.Controls.Add(this.pic130);
            this.panel1.Controls.Add(this.pic140);
            this.panel1.Controls.Add(this.pic150);
            this.panel1.Controls.Add(this.pic160);
            this.panel1.Controls.Add(this.pic170);
            this.panel1.Controls.Add(this.pic180);
            this.panel1.Controls.Add(this.pic190);
            this.panel1.Controls.Add(this.pic1A0);
            this.panel1.Controls.Add(this.pic1B0);
            this.panel1.Controls.Add(this.pic001);
            this.panel1.Controls.Add(this.pic011);
            this.panel1.Controls.Add(this.pic021);
            this.panel1.Controls.Add(this.pic031);
            this.panel1.Controls.Add(this.pic041);
            this.panel1.Controls.Add(this.pic051);
            this.panel1.Controls.Add(this.pic061);
            this.panel1.Controls.Add(this.pic071);
            this.panel1.Controls.Add(this.pic081);
            this.panel1.Controls.Add(this.pic091);
            this.panel1.Controls.Add(this.pic0A1);
            this.panel1.Controls.Add(this.pic0B1);
            this.panel1.Controls.Add(this.pic0C1);
            this.panel1.Controls.Add(this.pic0D1);
            this.panel1.Controls.Add(this.pic0E1);
            this.panel1.Controls.Add(this.pic0F1);
            this.panel1.Controls.Add(this.pic101);
            this.panel1.Controls.Add(this.pic111);
            this.panel1.Controls.Add(this.pic121);
            this.panel1.Controls.Add(this.pic131);
            this.panel1.Controls.Add(this.pic141);
            this.panel1.Controls.Add(this.pic151);
            this.panel1.Controls.Add(this.pic161);
            this.panel1.Controls.Add(this.pic171);
            this.panel1.Controls.Add(this.pic181);
            this.panel1.Controls.Add(this.pic191);
            this.panel1.Controls.Add(this.pic1A1);
            this.panel1.Controls.Add(this.pic1B1);
            this.panel1.Controls.Add(this.pic002);
            this.panel1.Controls.Add(this.pic012);
            this.panel1.Controls.Add(this.pic022);
            this.panel1.Controls.Add(this.pic032);
            this.panel1.Controls.Add(this.pic042);
            this.panel1.Controls.Add(this.pic052);
            this.panel1.Controls.Add(this.pic062);
            this.panel1.Controls.Add(this.pic072);
            this.panel1.Controls.Add(this.pic082);
            this.panel1.Controls.Add(this.pic092);
            this.panel1.Controls.Add(this.pic0A2);
            this.panel1.Controls.Add(this.pic0B2);
            this.panel1.Controls.Add(this.pic0C2);
            this.panel1.Controls.Add(this.pic0D2);
            this.panel1.Controls.Add(this.pic0E2);
            this.panel1.Controls.Add(this.pic0F2);
            this.panel1.Controls.Add(this.pic102);
            this.panel1.Controls.Add(this.pic112);
            this.panel1.Controls.Add(this.pic122);
            this.panel1.Controls.Add(this.pic132);
            this.panel1.Controls.Add(this.pic142);
            this.panel1.Controls.Add(this.pic152);
            this.panel1.Controls.Add(this.pic162);
            this.panel1.Controls.Add(this.pic172);
            this.panel1.Controls.Add(this.pic182);
            this.panel1.Controls.Add(this.pic192);
            this.panel1.Controls.Add(this.pic1A2);
            this.panel1.Controls.Add(this.pic1B2);
            this.panel1.Controls.Add(this.pic003);
            this.panel1.Controls.Add(this.pic013);
            this.panel1.Controls.Add(this.pic023);
            this.panel1.Controls.Add(this.pic033);
            this.panel1.Controls.Add(this.pic043);
            this.panel1.Controls.Add(this.pic053);
            this.panel1.Controls.Add(this.pic063);
            this.panel1.Controls.Add(this.pic073);
            this.panel1.Controls.Add(this.pic083);
            this.panel1.Controls.Add(this.pic093);
            this.panel1.Controls.Add(this.pic0A3);
            this.panel1.Controls.Add(this.pic0B3);
            this.panel1.Controls.Add(this.pic0C3);
            this.panel1.Controls.Add(this.pic0D3);
            this.panel1.Controls.Add(this.pic0E3);
            this.panel1.Controls.Add(this.pic0F3);
            this.panel1.Controls.Add(this.pic103);
            this.panel1.Controls.Add(this.pic113);
            this.panel1.Controls.Add(this.pic123);
            this.panel1.Controls.Add(this.pic133);
            this.panel1.Controls.Add(this.pic143);
            this.panel1.Controls.Add(this.pic153);
            this.panel1.Controls.Add(this.pic163);
            this.panel1.Controls.Add(this.pic173);
            this.panel1.Controls.Add(this.pic183);
            this.panel1.Controls.Add(this.pic193);
            this.panel1.Controls.Add(this.pic1A3);
            this.panel1.Controls.Add(this.pic1B3);
            this.panel1.Controls.Add(this.pic004);
            this.panel1.Controls.Add(this.pic014);
            this.panel1.Controls.Add(this.pic024);
            this.panel1.Controls.Add(this.pic034);
            this.panel1.Controls.Add(this.pic044);
            this.panel1.Controls.Add(this.pic054);
            this.panel1.Controls.Add(this.pic064);
            this.panel1.Controls.Add(this.pic074);
            this.panel1.Controls.Add(this.pic084);
            this.panel1.Controls.Add(this.pic094);
            this.panel1.Controls.Add(this.pic0A4);
            this.panel1.Controls.Add(this.pic0B4);
            this.panel1.Controls.Add(this.pic0C4);
            this.panel1.Controls.Add(this.pic0D4);
            this.panel1.Controls.Add(this.pic0E4);
            this.panel1.Controls.Add(this.pic0F4);
            this.panel1.Controls.Add(this.pic104);
            this.panel1.Controls.Add(this.pic114);
            this.panel1.Controls.Add(this.pic124);
            this.panel1.Controls.Add(this.pic134);
            this.panel1.Controls.Add(this.pic144);
            this.panel1.Controls.Add(this.pic154);
            this.panel1.Controls.Add(this.pic164);
            this.panel1.Controls.Add(this.pic174);
            this.panel1.Controls.Add(this.pic184);
            this.panel1.Controls.Add(this.pic194);
            this.panel1.Controls.Add(this.pic1A4);
            this.panel1.Controls.Add(this.pic1B4);
            this.panel1.Controls.Add(this.pic005);
            this.panel1.Controls.Add(this.pic015);
            this.panel1.Controls.Add(this.pic025);
            this.panel1.Controls.Add(this.pic035);
            this.panel1.Controls.Add(this.pic045);
            this.panel1.Controls.Add(this.pic055);
            this.panel1.Controls.Add(this.pic065);
            this.panel1.Controls.Add(this.pic075);
            this.panel1.Controls.Add(this.pic085);
            this.panel1.Controls.Add(this.pic095);
            this.panel1.Controls.Add(this.pic0A5);
            this.panel1.Controls.Add(this.pic0B5);
            this.panel1.Controls.Add(this.pic0C5);
            this.panel1.Controls.Add(this.pic0D5);
            this.panel1.Controls.Add(this.pic0E5);
            this.panel1.Controls.Add(this.pic0F5);
            this.panel1.Controls.Add(this.pic105);
            this.panel1.Controls.Add(this.pic115);
            this.panel1.Controls.Add(this.pic125);
            this.panel1.Controls.Add(this.pic135);
            this.panel1.Controls.Add(this.pic145);
            this.panel1.Controls.Add(this.pic155);
            this.panel1.Controls.Add(this.pic165);
            this.panel1.Controls.Add(this.pic175);
            this.panel1.Controls.Add(this.pic185);
            this.panel1.Controls.Add(this.pic195);
            this.panel1.Controls.Add(this.pic1A5);
            this.panel1.Controls.Add(this.pic1B5);
            this.panel1.Controls.Add(this.pic006);
            this.panel1.Controls.Add(this.pic016);
            this.panel1.Controls.Add(this.pic026);
            this.panel1.Controls.Add(this.pic036);
            this.panel1.Controls.Add(this.pic046);
            this.panel1.Controls.Add(this.pic056);
            this.panel1.Controls.Add(this.pic066);
            this.panel1.Controls.Add(this.pic076);
            this.panel1.Controls.Add(this.pic086);
            this.panel1.Controls.Add(this.pic096);
            this.panel1.Controls.Add(this.pic0A6);
            this.panel1.Controls.Add(this.pic0B6);
            this.panel1.Controls.Add(this.pic0C6);
            this.panel1.Controls.Add(this.pic0D6);
            this.panel1.Controls.Add(this.pic0E6);
            this.panel1.Controls.Add(this.pic0F6);
            this.panel1.Controls.Add(this.pic106);
            this.panel1.Controls.Add(this.pic116);
            this.panel1.Controls.Add(this.pic126);
            this.panel1.Controls.Add(this.pic136);
            this.panel1.Controls.Add(this.pic146);
            this.panel1.Controls.Add(this.pic156);
            this.panel1.Controls.Add(this.pic166);
            this.panel1.Controls.Add(this.pic176);
            this.panel1.Controls.Add(this.pic186);
            this.panel1.Controls.Add(this.pic196);
            this.panel1.Controls.Add(this.pic1A6);
            this.panel1.Controls.Add(this.pic1B6);
            this.panel1.Controls.Add(this.pic007);
            this.panel1.Controls.Add(this.pic017);
            this.panel1.Controls.Add(this.pic027);
            this.panel1.Controls.Add(this.pic037);
            this.panel1.Controls.Add(this.pic047);
            this.panel1.Controls.Add(this.pic057);
            this.panel1.Controls.Add(this.pic067);
            this.panel1.Controls.Add(this.pic077);
            this.panel1.Controls.Add(this.pic087);
            this.panel1.Controls.Add(this.pic097);
            this.panel1.Controls.Add(this.pic0A7);
            this.panel1.Controls.Add(this.pic0B7);
            this.panel1.Controls.Add(this.pic0C7);
            this.panel1.Controls.Add(this.pic0D7);
            this.panel1.Controls.Add(this.pic0E7);
            this.panel1.Controls.Add(this.pic0F7);
            this.panel1.Controls.Add(this.pic107);
            this.panel1.Controls.Add(this.pic117);
            this.panel1.Controls.Add(this.pic127);
            this.panel1.Controls.Add(this.pic137);
            this.panel1.Controls.Add(this.pic147);
            this.panel1.Controls.Add(this.pic157);
            this.panel1.Controls.Add(this.pic167);
            this.panel1.Controls.Add(this.pic177);
            this.panel1.Controls.Add(this.pic187);
            this.panel1.Controls.Add(this.pic197);
            this.panel1.Controls.Add(this.pic1A7);
            this.panel1.Controls.Add(this.pic1B7);
            this.panel1.Controls.Add(this.pic008);
            this.panel1.Controls.Add(this.pic018);
            this.panel1.Controls.Add(this.pic028);
            this.panel1.Controls.Add(this.pic038);
            this.panel1.Controls.Add(this.pic048);
            this.panel1.Controls.Add(this.pic058);
            this.panel1.Controls.Add(this.pic068);
            this.panel1.Controls.Add(this.pic078);
            this.panel1.Controls.Add(this.pic088);
            this.panel1.Controls.Add(this.pic098);
            this.panel1.Controls.Add(this.pic0A8);
            this.panel1.Controls.Add(this.pic0B8);
            this.panel1.Controls.Add(this.pic0C8);
            this.panel1.Controls.Add(this.pic0D8);
            this.panel1.Controls.Add(this.pic0E8);
            this.panel1.Controls.Add(this.pic0F8);
            this.panel1.Controls.Add(this.pic108);
            this.panel1.Controls.Add(this.pic118);
            this.panel1.Controls.Add(this.pic128);
            this.panel1.Controls.Add(this.pic138);
            this.panel1.Controls.Add(this.pic148);
            this.panel1.Controls.Add(this.pic158);
            this.panel1.Controls.Add(this.pic168);
            this.panel1.Controls.Add(this.pic178);
            this.panel1.Controls.Add(this.pic188);
            this.panel1.Controls.Add(this.pic198);
            this.panel1.Controls.Add(this.pic1A8);
            this.panel1.Controls.Add(this.pic1B8);
            this.panel1.Controls.Add(this.pic009);
            this.panel1.Controls.Add(this.pic019);
            this.panel1.Controls.Add(this.pic029);
            this.panel1.Controls.Add(this.pic039);
            this.panel1.Controls.Add(this.pic049);
            this.panel1.Controls.Add(this.pic059);
            this.panel1.Controls.Add(this.pic069);
            this.panel1.Controls.Add(this.pic079);
            this.panel1.Controls.Add(this.pic089);
            this.panel1.Controls.Add(this.pic099);
            this.panel1.Controls.Add(this.pic0A9);
            this.panel1.Controls.Add(this.pic0B9);
            this.panel1.Controls.Add(this.pic0C9);
            this.panel1.Controls.Add(this.pic0D9);
            this.panel1.Controls.Add(this.pic0E9);
            this.panel1.Controls.Add(this.pic0F9);
            this.panel1.Controls.Add(this.pic109);
            this.panel1.Controls.Add(this.pic119);
            this.panel1.Controls.Add(this.pic129);
            this.panel1.Controls.Add(this.pic139);
            this.panel1.Controls.Add(this.pic149);
            this.panel1.Controls.Add(this.pic159);
            this.panel1.Controls.Add(this.pic169);
            this.panel1.Controls.Add(this.pic179);
            this.panel1.Controls.Add(this.pic189);
            this.panel1.Controls.Add(this.pic199);
            this.panel1.Controls.Add(this.pic1A9);
            this.panel1.Controls.Add(this.pic1B9);
            this.panel1.Controls.Add(this.pic00A);
            this.panel1.Controls.Add(this.pic01A);
            this.panel1.Controls.Add(this.pic02A);
            this.panel1.Controls.Add(this.pic03A);
            this.panel1.Controls.Add(this.pic04A);
            this.panel1.Controls.Add(this.pic05A);
            this.panel1.Controls.Add(this.pic06A);
            this.panel1.Controls.Add(this.pic07A);
            this.panel1.Controls.Add(this.pic08A);
            this.panel1.Controls.Add(this.pic09A);
            this.panel1.Controls.Add(this.pic0AA);
            this.panel1.Controls.Add(this.pic0BA);
            this.panel1.Controls.Add(this.pic0CA);
            this.panel1.Controls.Add(this.pic0DA);
            this.panel1.Controls.Add(this.pic0EA);
            this.panel1.Controls.Add(this.pic0FA);
            this.panel1.Controls.Add(this.pic10A);
            this.panel1.Controls.Add(this.pic11A);
            this.panel1.Controls.Add(this.pic12A);
            this.panel1.Controls.Add(this.pic13A);
            this.panel1.Controls.Add(this.pic14A);
            this.panel1.Controls.Add(this.pic15A);
            this.panel1.Controls.Add(this.pic16A);
            this.panel1.Controls.Add(this.pic17A);
            this.panel1.Controls.Add(this.pic18A);
            this.panel1.Controls.Add(this.pic19A);
            this.panel1.Controls.Add(this.pic1AA);
            this.panel1.Controls.Add(this.pic1BA);
            this.panel1.Controls.Add(this.pic00B);
            this.panel1.Controls.Add(this.pic01B);
            this.panel1.Controls.Add(this.pic02B);
            this.panel1.Controls.Add(this.pic03B);
            this.panel1.Controls.Add(this.pic04B);
            this.panel1.Controls.Add(this.pic05B);
            this.panel1.Controls.Add(this.pic06B);
            this.panel1.Controls.Add(this.pic07B);
            this.panel1.Controls.Add(this.pic08B);
            this.panel1.Controls.Add(this.pic09B);
            this.panel1.Controls.Add(this.pic0AB);
            this.panel1.Controls.Add(this.pic0BB);
            this.panel1.Controls.Add(this.pic0CB);
            this.panel1.Controls.Add(this.pic0DB);
            this.panel1.Controls.Add(this.pic0EB);
            this.panel1.Controls.Add(this.pic0FB);
            this.panel1.Controls.Add(this.pic10B);
            this.panel1.Controls.Add(this.pic11B);
            this.panel1.Controls.Add(this.pic12B);
            this.panel1.Controls.Add(this.pic13B);
            this.panel1.Controls.Add(this.pic14B);
            this.panel1.Controls.Add(this.pic15B);
            this.panel1.Controls.Add(this.pic16B);
            this.panel1.Controls.Add(this.pic17B);
            this.panel1.Controls.Add(this.pic18B);
            this.panel1.Controls.Add(this.pic19B);
            this.panel1.Controls.Add(this.pic1AB);
            this.panel1.Controls.Add(this.pic1BB);
            this.panel1.Controls.Add(this.pic00C);
            this.panel1.Controls.Add(this.pic01C);
            this.panel1.Controls.Add(this.pic02C);
            this.panel1.Controls.Add(this.pic03C);
            this.panel1.Controls.Add(this.pic04C);
            this.panel1.Controls.Add(this.pic05C);
            this.panel1.Controls.Add(this.pic06C);
            this.panel1.Controls.Add(this.pic07C);
            this.panel1.Controls.Add(this.pic08C);
            this.panel1.Controls.Add(this.pic09C);
            this.panel1.Controls.Add(this.pic0AC);
            this.panel1.Controls.Add(this.pic0BC);
            this.panel1.Controls.Add(this.pic0CC);
            this.panel1.Controls.Add(this.pic0DC);
            this.panel1.Controls.Add(this.pic0EC);
            this.panel1.Controls.Add(this.pic0FC);
            this.panel1.Controls.Add(this.pic10C);
            this.panel1.Controls.Add(this.pic11C);
            this.panel1.Controls.Add(this.pic12C);
            this.panel1.Controls.Add(this.pic13C);
            this.panel1.Controls.Add(this.pic14C);
            this.panel1.Controls.Add(this.pic15C);
            this.panel1.Controls.Add(this.pic16C);
            this.panel1.Controls.Add(this.pic17C);
            this.panel1.Controls.Add(this.pic18C);
            this.panel1.Controls.Add(this.pic19C);
            this.panel1.Controls.Add(this.pic1AC);
            this.panel1.Controls.Add(this.pic1BC);
            this.panel1.Controls.Add(this.pic00D);
            this.panel1.Controls.Add(this.pic01D);
            this.panel1.Controls.Add(this.pic02D);
            this.panel1.Controls.Add(this.pic03D);
            this.panel1.Controls.Add(this.pic04D);
            this.panel1.Controls.Add(this.pic05D);
            this.panel1.Controls.Add(this.pic06D);
            this.panel1.Controls.Add(this.pic07D);
            this.panel1.Controls.Add(this.pic08D);
            this.panel1.Controls.Add(this.pic09D);
            this.panel1.Controls.Add(this.pic0AD);
            this.panel1.Controls.Add(this.pic0BD);
            this.panel1.Controls.Add(this.pic0CD);
            this.panel1.Controls.Add(this.pic0DD);
            this.panel1.Controls.Add(this.pic0ED);
            this.panel1.Controls.Add(this.pic0FD);
            this.panel1.Controls.Add(this.pic10D);
            this.panel1.Controls.Add(this.pic11D);
            this.panel1.Controls.Add(this.pic12D);
            this.panel1.Controls.Add(this.pic13D);
            this.panel1.Controls.Add(this.pic14D);
            this.panel1.Controls.Add(this.pic15D);
            this.panel1.Controls.Add(this.pic16D);
            this.panel1.Controls.Add(this.pic17D);
            this.panel1.Controls.Add(this.pic18D);
            this.panel1.Controls.Add(this.pic19D);
            this.panel1.Controls.Add(this.pic1AD);
            this.panel1.Controls.Add(this.pic1BD);
            this.panel1.Controls.Add(this.pic00E);
            this.panel1.Controls.Add(this.pic01E);
            this.panel1.Controls.Add(this.pic02E);
            this.panel1.Controls.Add(this.pic03E);
            this.panel1.Controls.Add(this.pic04E);
            this.panel1.Controls.Add(this.pic05E);
            this.panel1.Controls.Add(this.pic06E);
            this.panel1.Controls.Add(this.pic07E);
            this.panel1.Controls.Add(this.pic08E);
            this.panel1.Controls.Add(this.pic09E);
            this.panel1.Controls.Add(this.pic0AE);
            this.panel1.Controls.Add(this.pic0BE);
            this.panel1.Controls.Add(this.pic0CE);
            this.panel1.Controls.Add(this.pic0DE);
            this.panel1.Controls.Add(this.pic0EE);
            this.panel1.Controls.Add(this.pic0FE);
            this.panel1.Controls.Add(this.pic10E);
            this.panel1.Controls.Add(this.pic11E);
            this.panel1.Controls.Add(this.pic12E);
            this.panel1.Controls.Add(this.pic13E);
            this.panel1.Controls.Add(this.pic14E);
            this.panel1.Controls.Add(this.pic15E);
            this.panel1.Controls.Add(this.pic16E);
            this.panel1.Controls.Add(this.pic17E);
            this.panel1.Controls.Add(this.pic18E);
            this.panel1.Controls.Add(this.pic19E);
            this.panel1.Controls.Add(this.pic1AE);
            this.panel1.Controls.Add(this.pic1BE);
            this.panel1.Controls.Add(this.pic00F);
            this.panel1.Controls.Add(this.pic01F);
            this.panel1.Controls.Add(this.pic02F);
            this.panel1.Controls.Add(this.pic03F);
            this.panel1.Controls.Add(this.pic04F);
            this.panel1.Controls.Add(this.pic05F);
            this.panel1.Controls.Add(this.pic06F);
            this.panel1.Controls.Add(this.pic07F);
            this.panel1.Controls.Add(this.pic08F);
            this.panel1.Controls.Add(this.pic09F);
            this.panel1.Controls.Add(this.pic0AF);
            this.panel1.Controls.Add(this.pic0BF);
            this.panel1.Controls.Add(this.pic0CF);
            this.panel1.Controls.Add(this.pic0DF);
            this.panel1.Controls.Add(this.pic0EF);
            this.panel1.Controls.Add(this.pic0FF);
            this.panel1.Controls.Add(this.pic10F);
            this.panel1.Controls.Add(this.pic11F);
            this.panel1.Controls.Add(this.pic12F);
            this.panel1.Controls.Add(this.pic13F);
            this.panel1.Controls.Add(this.pic14F);
            this.panel1.Controls.Add(this.pic15F);
            this.panel1.Controls.Add(this.pic16F);
            this.panel1.Controls.Add(this.pic17F);
            this.panel1.Controls.Add(this.pic18F);
            this.panel1.Controls.Add(this.pic19F);
            this.panel1.Controls.Add(this.pic1AF);
            this.panel1.Controls.Add(this.pic1BF);
            this.panel1.Location = new System.Drawing.Point(33, 39);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(534, 337);
            this.panel1.TabIndex = 448;
            // 
            // pic000
            // 
            this.pic000.Location = new System.Drawing.Point(0, 0);
            this.pic000.Name = "pic000";
            this.pic000.Size = new System.Drawing.Size(20, 22);
            this.pic000.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pic000.TabIndex = 448;
            this.pic000.TabStop = false;
            // 
            // pic010
            // 
            this.pic010.Location = new System.Drawing.Point(19, 0);
            this.pic010.Name = "pic010";
            this.pic010.Size = new System.Drawing.Size(20, 22);
            this.pic010.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic010.TabIndex = 449;
            this.pic010.TabStop = false;
            // 
            // pic020
            // 
            this.pic020.Location = new System.Drawing.Point(38, 0);
            this.pic020.Name = "pic020";
            this.pic020.Size = new System.Drawing.Size(20, 22);
            this.pic020.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic020.TabIndex = 450;
            this.pic020.TabStop = false;
            // 
            // pic030
            // 
            this.pic030.Location = new System.Drawing.Point(57, 0);
            this.pic030.Name = "pic030";
            this.pic030.Size = new System.Drawing.Size(20, 22);
            this.pic030.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic030.TabIndex = 451;
            this.pic030.TabStop = false;
            // 
            // pic040
            // 
            this.pic040.Location = new System.Drawing.Point(76, 0);
            this.pic040.Name = "pic040";
            this.pic040.Size = new System.Drawing.Size(20, 22);
            this.pic040.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic040.TabIndex = 452;
            this.pic040.TabStop = false;
            // 
            // pic050
            // 
            this.pic050.Location = new System.Drawing.Point(95, 0);
            this.pic050.Name = "pic050";
            this.pic050.Size = new System.Drawing.Size(20, 22);
            this.pic050.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic050.TabIndex = 453;
            this.pic050.TabStop = false;
            // 
            // pic060
            // 
            this.pic060.Location = new System.Drawing.Point(114, 0);
            this.pic060.Name = "pic060";
            this.pic060.Size = new System.Drawing.Size(20, 22);
            this.pic060.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic060.TabIndex = 454;
            this.pic060.TabStop = false;
            // 
            // pic070
            // 
            this.pic070.Location = new System.Drawing.Point(133, 0);
            this.pic070.Name = "pic070";
            this.pic070.Size = new System.Drawing.Size(20, 22);
            this.pic070.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic070.TabIndex = 455;
            this.pic070.TabStop = false;
            // 
            // pic080
            // 
            this.pic080.Location = new System.Drawing.Point(152, 0);
            this.pic080.Name = "pic080";
            this.pic080.Size = new System.Drawing.Size(20, 22);
            this.pic080.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic080.TabIndex = 456;
            this.pic080.TabStop = false;
            // 
            // pic090
            // 
            this.pic090.Location = new System.Drawing.Point(171, 0);
            this.pic090.Name = "pic090";
            this.pic090.Size = new System.Drawing.Size(20, 22);
            this.pic090.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic090.TabIndex = 457;
            this.pic090.TabStop = false;
            // 
            // pic0A0
            // 
            this.pic0A0.Location = new System.Drawing.Point(190, 0);
            this.pic0A0.Name = "pic0A0";
            this.pic0A0.Size = new System.Drawing.Size(20, 22);
            this.pic0A0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0A0.TabIndex = 458;
            this.pic0A0.TabStop = false;
            // 
            // pic0B0
            // 
            this.pic0B0.Location = new System.Drawing.Point(209, 0);
            this.pic0B0.Name = "pic0B0";
            this.pic0B0.Size = new System.Drawing.Size(20, 22);
            this.pic0B0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0B0.TabIndex = 459;
            this.pic0B0.TabStop = false;
            // 
            // pic0C0
            // 
            this.pic0C0.Location = new System.Drawing.Point(228, 0);
            this.pic0C0.Name = "pic0C0";
            this.pic0C0.Size = new System.Drawing.Size(20, 22);
            this.pic0C0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0C0.TabIndex = 460;
            this.pic0C0.TabStop = false;
            // 
            // pic0D0
            // 
            this.pic0D0.Location = new System.Drawing.Point(247, 0);
            this.pic0D0.Name = "pic0D0";
            this.pic0D0.Size = new System.Drawing.Size(20, 22);
            this.pic0D0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0D0.TabIndex = 461;
            this.pic0D0.TabStop = false;
            // 
            // pic0E0
            // 
            this.pic0E0.Location = new System.Drawing.Point(266, 0);
            this.pic0E0.Name = "pic0E0";
            this.pic0E0.Size = new System.Drawing.Size(20, 22);
            this.pic0E0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0E0.TabIndex = 462;
            this.pic0E0.TabStop = false;
            // 
            // pic0F0
            // 
            this.pic0F0.Location = new System.Drawing.Point(285, 0);
            this.pic0F0.Name = "pic0F0";
            this.pic0F0.Size = new System.Drawing.Size(20, 22);
            this.pic0F0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0F0.TabIndex = 463;
            this.pic0F0.TabStop = false;
            // 
            // pic100
            // 
            this.pic100.Location = new System.Drawing.Point(304, 0);
            this.pic100.Name = "pic100";
            this.pic100.Size = new System.Drawing.Size(20, 22);
            this.pic100.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic100.TabIndex = 464;
            this.pic100.TabStop = false;
            // 
            // pic110
            // 
            this.pic110.Location = new System.Drawing.Point(323, 0);
            this.pic110.Name = "pic110";
            this.pic110.Size = new System.Drawing.Size(20, 22);
            this.pic110.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic110.TabIndex = 465;
            this.pic110.TabStop = false;
            // 
            // pic120
            // 
            this.pic120.Location = new System.Drawing.Point(342, 0);
            this.pic120.Name = "pic120";
            this.pic120.Size = new System.Drawing.Size(20, 22);
            this.pic120.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic120.TabIndex = 466;
            this.pic120.TabStop = false;
            // 
            // pic130
            // 
            this.pic130.Location = new System.Drawing.Point(361, 0);
            this.pic130.Name = "pic130";
            this.pic130.Size = new System.Drawing.Size(20, 22);
            this.pic130.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic130.TabIndex = 467;
            this.pic130.TabStop = false;
            // 
            // pic140
            // 
            this.pic140.Location = new System.Drawing.Point(380, 0);
            this.pic140.Name = "pic140";
            this.pic140.Size = new System.Drawing.Size(20, 22);
            this.pic140.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic140.TabIndex = 468;
            this.pic140.TabStop = false;
            // 
            // pic150
            // 
            this.pic150.Location = new System.Drawing.Point(399, 0);
            this.pic150.Name = "pic150";
            this.pic150.Size = new System.Drawing.Size(20, 22);
            this.pic150.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic150.TabIndex = 469;
            this.pic150.TabStop = false;
            // 
            // pic160
            // 
            this.pic160.Location = new System.Drawing.Point(418, 0);
            this.pic160.Name = "pic160";
            this.pic160.Size = new System.Drawing.Size(20, 22);
            this.pic160.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic160.TabIndex = 470;
            this.pic160.TabStop = false;
            // 
            // pic170
            // 
            this.pic170.Location = new System.Drawing.Point(437, 0);
            this.pic170.Name = "pic170";
            this.pic170.Size = new System.Drawing.Size(20, 22);
            this.pic170.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic170.TabIndex = 471;
            this.pic170.TabStop = false;
            // 
            // pic180
            // 
            this.pic180.Location = new System.Drawing.Point(456, 0);
            this.pic180.Name = "pic180";
            this.pic180.Size = new System.Drawing.Size(20, 22);
            this.pic180.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic180.TabIndex = 472;
            this.pic180.TabStop = false;
            // 
            // pic190
            // 
            this.pic190.Location = new System.Drawing.Point(475, 0);
            this.pic190.Name = "pic190";
            this.pic190.Size = new System.Drawing.Size(20, 22);
            this.pic190.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic190.TabIndex = 473;
            this.pic190.TabStop = false;
            // 
            // pic1A0
            // 
            this.pic1A0.Location = new System.Drawing.Point(494, 0);
            this.pic1A0.Name = "pic1A0";
            this.pic1A0.Size = new System.Drawing.Size(20, 22);
            this.pic1A0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1A0.TabIndex = 474;
            this.pic1A0.TabStop = false;
            // 
            // pic1B0
            // 
            this.pic1B0.Location = new System.Drawing.Point(513, 0);
            this.pic1B0.Name = "pic1B0";
            this.pic1B0.Size = new System.Drawing.Size(20, 22);
            this.pic1B0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1B0.TabIndex = 475;
            this.pic1B0.TabStop = false;
            // 
            // pic001
            // 
            this.pic001.Location = new System.Drawing.Point(0, 21);
            this.pic001.Name = "pic001";
            this.pic001.Size = new System.Drawing.Size(20, 22);
            this.pic001.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic001.TabIndex = 476;
            this.pic001.TabStop = false;
            // 
            // pic011
            // 
            this.pic011.Location = new System.Drawing.Point(19, 21);
            this.pic011.Name = "pic011";
            this.pic011.Size = new System.Drawing.Size(20, 22);
            this.pic011.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic011.TabIndex = 477;
            this.pic011.TabStop = false;
            // 
            // pic021
            // 
            this.pic021.Location = new System.Drawing.Point(38, 21);
            this.pic021.Name = "pic021";
            this.pic021.Size = new System.Drawing.Size(20, 22);
            this.pic021.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic021.TabIndex = 478;
            this.pic021.TabStop = false;
            // 
            // pic031
            // 
            this.pic031.Location = new System.Drawing.Point(57, 21);
            this.pic031.Name = "pic031";
            this.pic031.Size = new System.Drawing.Size(20, 22);
            this.pic031.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic031.TabIndex = 479;
            this.pic031.TabStop = false;
            // 
            // pic041
            // 
            this.pic041.Location = new System.Drawing.Point(76, 21);
            this.pic041.Name = "pic041";
            this.pic041.Size = new System.Drawing.Size(20, 22);
            this.pic041.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic041.TabIndex = 480;
            this.pic041.TabStop = false;
            // 
            // pic051
            // 
            this.pic051.Location = new System.Drawing.Point(95, 21);
            this.pic051.Name = "pic051";
            this.pic051.Size = new System.Drawing.Size(20, 22);
            this.pic051.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic051.TabIndex = 481;
            this.pic051.TabStop = false;
            // 
            // pic061
            // 
            this.pic061.Location = new System.Drawing.Point(114, 21);
            this.pic061.Name = "pic061";
            this.pic061.Size = new System.Drawing.Size(20, 22);
            this.pic061.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic061.TabIndex = 482;
            this.pic061.TabStop = false;
            // 
            // pic071
            // 
            this.pic071.Location = new System.Drawing.Point(133, 21);
            this.pic071.Name = "pic071";
            this.pic071.Size = new System.Drawing.Size(20, 22);
            this.pic071.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic071.TabIndex = 483;
            this.pic071.TabStop = false;
            // 
            // pic081
            // 
            this.pic081.Location = new System.Drawing.Point(152, 21);
            this.pic081.Name = "pic081";
            this.pic081.Size = new System.Drawing.Size(20, 22);
            this.pic081.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic081.TabIndex = 484;
            this.pic081.TabStop = false;
            // 
            // pic091
            // 
            this.pic091.Location = new System.Drawing.Point(171, 21);
            this.pic091.Name = "pic091";
            this.pic091.Size = new System.Drawing.Size(20, 22);
            this.pic091.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic091.TabIndex = 485;
            this.pic091.TabStop = false;
            // 
            // pic0A1
            // 
            this.pic0A1.Location = new System.Drawing.Point(190, 21);
            this.pic0A1.Name = "pic0A1";
            this.pic0A1.Size = new System.Drawing.Size(20, 22);
            this.pic0A1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0A1.TabIndex = 486;
            this.pic0A1.TabStop = false;
            // 
            // pic0B1
            // 
            this.pic0B1.Location = new System.Drawing.Point(209, 21);
            this.pic0B1.Name = "pic0B1";
            this.pic0B1.Size = new System.Drawing.Size(20, 22);
            this.pic0B1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0B1.TabIndex = 487;
            this.pic0B1.TabStop = false;
            // 
            // pic0C1
            // 
            this.pic0C1.Location = new System.Drawing.Point(228, 21);
            this.pic0C1.Name = "pic0C1";
            this.pic0C1.Size = new System.Drawing.Size(20, 22);
            this.pic0C1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0C1.TabIndex = 488;
            this.pic0C1.TabStop = false;
            // 
            // pic0D1
            // 
            this.pic0D1.Location = new System.Drawing.Point(247, 21);
            this.pic0D1.Name = "pic0D1";
            this.pic0D1.Size = new System.Drawing.Size(20, 22);
            this.pic0D1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0D1.TabIndex = 489;
            this.pic0D1.TabStop = false;
            // 
            // pic0E1
            // 
            this.pic0E1.Location = new System.Drawing.Point(266, 21);
            this.pic0E1.Name = "pic0E1";
            this.pic0E1.Size = new System.Drawing.Size(20, 22);
            this.pic0E1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0E1.TabIndex = 490;
            this.pic0E1.TabStop = false;
            // 
            // pic0F1
            // 
            this.pic0F1.Location = new System.Drawing.Point(285, 21);
            this.pic0F1.Name = "pic0F1";
            this.pic0F1.Size = new System.Drawing.Size(20, 22);
            this.pic0F1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0F1.TabIndex = 491;
            this.pic0F1.TabStop = false;
            // 
            // pic101
            // 
            this.pic101.Location = new System.Drawing.Point(304, 21);
            this.pic101.Name = "pic101";
            this.pic101.Size = new System.Drawing.Size(20, 22);
            this.pic101.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic101.TabIndex = 492;
            this.pic101.TabStop = false;
            // 
            // pic111
            // 
            this.pic111.Location = new System.Drawing.Point(323, 21);
            this.pic111.Name = "pic111";
            this.pic111.Size = new System.Drawing.Size(20, 22);
            this.pic111.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic111.TabIndex = 493;
            this.pic111.TabStop = false;
            // 
            // pic121
            // 
            this.pic121.Location = new System.Drawing.Point(342, 21);
            this.pic121.Name = "pic121";
            this.pic121.Size = new System.Drawing.Size(20, 22);
            this.pic121.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic121.TabIndex = 494;
            this.pic121.TabStop = false;
            // 
            // pic131
            // 
            this.pic131.Location = new System.Drawing.Point(361, 21);
            this.pic131.Name = "pic131";
            this.pic131.Size = new System.Drawing.Size(20, 22);
            this.pic131.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic131.TabIndex = 495;
            this.pic131.TabStop = false;
            // 
            // pic141
            // 
            this.pic141.Location = new System.Drawing.Point(380, 21);
            this.pic141.Name = "pic141";
            this.pic141.Size = new System.Drawing.Size(20, 22);
            this.pic141.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic141.TabIndex = 496;
            this.pic141.TabStop = false;
            // 
            // pic151
            // 
            this.pic151.Location = new System.Drawing.Point(399, 21);
            this.pic151.Name = "pic151";
            this.pic151.Size = new System.Drawing.Size(20, 22);
            this.pic151.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic151.TabIndex = 497;
            this.pic151.TabStop = false;
            // 
            // pic161
            // 
            this.pic161.Location = new System.Drawing.Point(418, 21);
            this.pic161.Name = "pic161";
            this.pic161.Size = new System.Drawing.Size(20, 22);
            this.pic161.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic161.TabIndex = 498;
            this.pic161.TabStop = false;
            // 
            // pic171
            // 
            this.pic171.Location = new System.Drawing.Point(437, 21);
            this.pic171.Name = "pic171";
            this.pic171.Size = new System.Drawing.Size(20, 22);
            this.pic171.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic171.TabIndex = 499;
            this.pic171.TabStop = false;
            // 
            // pic181
            // 
            this.pic181.Location = new System.Drawing.Point(456, 21);
            this.pic181.Name = "pic181";
            this.pic181.Size = new System.Drawing.Size(20, 22);
            this.pic181.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic181.TabIndex = 500;
            this.pic181.TabStop = false;
            // 
            // pic191
            // 
            this.pic191.Location = new System.Drawing.Point(475, 21);
            this.pic191.Name = "pic191";
            this.pic191.Size = new System.Drawing.Size(20, 22);
            this.pic191.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic191.TabIndex = 501;
            this.pic191.TabStop = false;
            // 
            // pic1A1
            // 
            this.pic1A1.Location = new System.Drawing.Point(494, 21);
            this.pic1A1.Name = "pic1A1";
            this.pic1A1.Size = new System.Drawing.Size(20, 22);
            this.pic1A1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1A1.TabIndex = 502;
            this.pic1A1.TabStop = false;
            // 
            // pic1B1
            // 
            this.pic1B1.Location = new System.Drawing.Point(513, 21);
            this.pic1B1.Name = "pic1B1";
            this.pic1B1.Size = new System.Drawing.Size(20, 22);
            this.pic1B1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1B1.TabIndex = 503;
            this.pic1B1.TabStop = false;
            // 
            // pic002
            // 
            this.pic002.Location = new System.Drawing.Point(0, 42);
            this.pic002.Name = "pic002";
            this.pic002.Size = new System.Drawing.Size(20, 22);
            this.pic002.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic002.TabIndex = 504;
            this.pic002.TabStop = false;
            // 
            // pic012
            // 
            this.pic012.Location = new System.Drawing.Point(19, 42);
            this.pic012.Name = "pic012";
            this.pic012.Size = new System.Drawing.Size(20, 22);
            this.pic012.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic012.TabIndex = 505;
            this.pic012.TabStop = false;
            // 
            // pic022
            // 
            this.pic022.Location = new System.Drawing.Point(38, 42);
            this.pic022.Name = "pic022";
            this.pic022.Size = new System.Drawing.Size(20, 22);
            this.pic022.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic022.TabIndex = 506;
            this.pic022.TabStop = false;
            // 
            // pic032
            // 
            this.pic032.Location = new System.Drawing.Point(57, 42);
            this.pic032.Name = "pic032";
            this.pic032.Size = new System.Drawing.Size(20, 22);
            this.pic032.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic032.TabIndex = 507;
            this.pic032.TabStop = false;
            // 
            // pic042
            // 
            this.pic042.Location = new System.Drawing.Point(76, 42);
            this.pic042.Name = "pic042";
            this.pic042.Size = new System.Drawing.Size(20, 22);
            this.pic042.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic042.TabIndex = 508;
            this.pic042.TabStop = false;
            // 
            // pic052
            // 
            this.pic052.Location = new System.Drawing.Point(95, 42);
            this.pic052.Name = "pic052";
            this.pic052.Size = new System.Drawing.Size(20, 22);
            this.pic052.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic052.TabIndex = 509;
            this.pic052.TabStop = false;
            // 
            // pic062
            // 
            this.pic062.Location = new System.Drawing.Point(114, 42);
            this.pic062.Name = "pic062";
            this.pic062.Size = new System.Drawing.Size(20, 22);
            this.pic062.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic062.TabIndex = 510;
            this.pic062.TabStop = false;
            // 
            // pic072
            // 
            this.pic072.Location = new System.Drawing.Point(133, 42);
            this.pic072.Name = "pic072";
            this.pic072.Size = new System.Drawing.Size(20, 22);
            this.pic072.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic072.TabIndex = 511;
            this.pic072.TabStop = false;
            // 
            // pic082
            // 
            this.pic082.Location = new System.Drawing.Point(152, 42);
            this.pic082.Name = "pic082";
            this.pic082.Size = new System.Drawing.Size(20, 22);
            this.pic082.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic082.TabIndex = 512;
            this.pic082.TabStop = false;
            // 
            // pic092
            // 
            this.pic092.Location = new System.Drawing.Point(171, 42);
            this.pic092.Name = "pic092";
            this.pic092.Size = new System.Drawing.Size(20, 22);
            this.pic092.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic092.TabIndex = 513;
            this.pic092.TabStop = false;
            // 
            // pic0A2
            // 
            this.pic0A2.Location = new System.Drawing.Point(190, 42);
            this.pic0A2.Name = "pic0A2";
            this.pic0A2.Size = new System.Drawing.Size(20, 22);
            this.pic0A2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0A2.TabIndex = 514;
            this.pic0A2.TabStop = false;
            // 
            // pic0B2
            // 
            this.pic0B2.Location = new System.Drawing.Point(209, 42);
            this.pic0B2.Name = "pic0B2";
            this.pic0B2.Size = new System.Drawing.Size(20, 22);
            this.pic0B2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0B2.TabIndex = 515;
            this.pic0B2.TabStop = false;
            // 
            // pic0C2
            // 
            this.pic0C2.Location = new System.Drawing.Point(228, 42);
            this.pic0C2.Name = "pic0C2";
            this.pic0C2.Size = new System.Drawing.Size(20, 22);
            this.pic0C2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0C2.TabIndex = 516;
            this.pic0C2.TabStop = false;
            // 
            // pic0D2
            // 
            this.pic0D2.Location = new System.Drawing.Point(247, 42);
            this.pic0D2.Name = "pic0D2";
            this.pic0D2.Size = new System.Drawing.Size(20, 22);
            this.pic0D2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0D2.TabIndex = 517;
            this.pic0D2.TabStop = false;
            // 
            // pic0E2
            // 
            this.pic0E2.Location = new System.Drawing.Point(266, 42);
            this.pic0E2.Name = "pic0E2";
            this.pic0E2.Size = new System.Drawing.Size(20, 22);
            this.pic0E2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0E2.TabIndex = 518;
            this.pic0E2.TabStop = false;
            // 
            // pic0F2
            // 
            this.pic0F2.Location = new System.Drawing.Point(285, 42);
            this.pic0F2.Name = "pic0F2";
            this.pic0F2.Size = new System.Drawing.Size(20, 22);
            this.pic0F2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0F2.TabIndex = 519;
            this.pic0F2.TabStop = false;
            // 
            // pic102
            // 
            this.pic102.Location = new System.Drawing.Point(304, 42);
            this.pic102.Name = "pic102";
            this.pic102.Size = new System.Drawing.Size(20, 22);
            this.pic102.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic102.TabIndex = 520;
            this.pic102.TabStop = false;
            // 
            // pic112
            // 
            this.pic112.Location = new System.Drawing.Point(323, 42);
            this.pic112.Name = "pic112";
            this.pic112.Size = new System.Drawing.Size(20, 22);
            this.pic112.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic112.TabIndex = 521;
            this.pic112.TabStop = false;
            // 
            // pic122
            // 
            this.pic122.Location = new System.Drawing.Point(342, 42);
            this.pic122.Name = "pic122";
            this.pic122.Size = new System.Drawing.Size(20, 22);
            this.pic122.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic122.TabIndex = 522;
            this.pic122.TabStop = false;
            // 
            // pic132
            // 
            this.pic132.Location = new System.Drawing.Point(361, 42);
            this.pic132.Name = "pic132";
            this.pic132.Size = new System.Drawing.Size(20, 22);
            this.pic132.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic132.TabIndex = 523;
            this.pic132.TabStop = false;
            // 
            // pic142
            // 
            this.pic142.Location = new System.Drawing.Point(380, 42);
            this.pic142.Name = "pic142";
            this.pic142.Size = new System.Drawing.Size(20, 22);
            this.pic142.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic142.TabIndex = 524;
            this.pic142.TabStop = false;
            // 
            // pic152
            // 
            this.pic152.Location = new System.Drawing.Point(399, 42);
            this.pic152.Name = "pic152";
            this.pic152.Size = new System.Drawing.Size(20, 22);
            this.pic152.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic152.TabIndex = 525;
            this.pic152.TabStop = false;
            // 
            // pic162
            // 
            this.pic162.Location = new System.Drawing.Point(418, 42);
            this.pic162.Name = "pic162";
            this.pic162.Size = new System.Drawing.Size(20, 22);
            this.pic162.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic162.TabIndex = 526;
            this.pic162.TabStop = false;
            // 
            // pic172
            // 
            this.pic172.Location = new System.Drawing.Point(437, 42);
            this.pic172.Name = "pic172";
            this.pic172.Size = new System.Drawing.Size(20, 22);
            this.pic172.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic172.TabIndex = 527;
            this.pic172.TabStop = false;
            // 
            // pic182
            // 
            this.pic182.Location = new System.Drawing.Point(456, 42);
            this.pic182.Name = "pic182";
            this.pic182.Size = new System.Drawing.Size(20, 22);
            this.pic182.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic182.TabIndex = 528;
            this.pic182.TabStop = false;
            // 
            // pic192
            // 
            this.pic192.Location = new System.Drawing.Point(475, 42);
            this.pic192.Name = "pic192";
            this.pic192.Size = new System.Drawing.Size(20, 22);
            this.pic192.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic192.TabIndex = 529;
            this.pic192.TabStop = false;
            // 
            // pic1A2
            // 
            this.pic1A2.Location = new System.Drawing.Point(494, 42);
            this.pic1A2.Name = "pic1A2";
            this.pic1A2.Size = new System.Drawing.Size(20, 22);
            this.pic1A2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1A2.TabIndex = 530;
            this.pic1A2.TabStop = false;
            // 
            // pic1B2
            // 
            this.pic1B2.Location = new System.Drawing.Point(513, 42);
            this.pic1B2.Name = "pic1B2";
            this.pic1B2.Size = new System.Drawing.Size(20, 22);
            this.pic1B2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1B2.TabIndex = 531;
            this.pic1B2.TabStop = false;
            // 
            // pic003
            // 
            this.pic003.Location = new System.Drawing.Point(0, 63);
            this.pic003.Name = "pic003";
            this.pic003.Size = new System.Drawing.Size(20, 22);
            this.pic003.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic003.TabIndex = 532;
            this.pic003.TabStop = false;
            // 
            // pic013
            // 
            this.pic013.Location = new System.Drawing.Point(19, 63);
            this.pic013.Name = "pic013";
            this.pic013.Size = new System.Drawing.Size(20, 22);
            this.pic013.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic013.TabIndex = 533;
            this.pic013.TabStop = false;
            // 
            // pic023
            // 
            this.pic023.Location = new System.Drawing.Point(38, 63);
            this.pic023.Name = "pic023";
            this.pic023.Size = new System.Drawing.Size(20, 22);
            this.pic023.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic023.TabIndex = 534;
            this.pic023.TabStop = false;
            // 
            // pic033
            // 
            this.pic033.Location = new System.Drawing.Point(57, 63);
            this.pic033.Name = "pic033";
            this.pic033.Size = new System.Drawing.Size(20, 22);
            this.pic033.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic033.TabIndex = 535;
            this.pic033.TabStop = false;
            // 
            // pic043
            // 
            this.pic043.Location = new System.Drawing.Point(76, 63);
            this.pic043.Name = "pic043";
            this.pic043.Size = new System.Drawing.Size(20, 22);
            this.pic043.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic043.TabIndex = 536;
            this.pic043.TabStop = false;
            // 
            // pic053
            // 
            this.pic053.Location = new System.Drawing.Point(95, 63);
            this.pic053.Name = "pic053";
            this.pic053.Size = new System.Drawing.Size(20, 22);
            this.pic053.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic053.TabIndex = 537;
            this.pic053.TabStop = false;
            // 
            // pic063
            // 
            this.pic063.Location = new System.Drawing.Point(114, 63);
            this.pic063.Name = "pic063";
            this.pic063.Size = new System.Drawing.Size(20, 22);
            this.pic063.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic063.TabIndex = 538;
            this.pic063.TabStop = false;
            // 
            // pic073
            // 
            this.pic073.Location = new System.Drawing.Point(133, 63);
            this.pic073.Name = "pic073";
            this.pic073.Size = new System.Drawing.Size(20, 22);
            this.pic073.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic073.TabIndex = 539;
            this.pic073.TabStop = false;
            // 
            // pic083
            // 
            this.pic083.Location = new System.Drawing.Point(152, 63);
            this.pic083.Name = "pic083";
            this.pic083.Size = new System.Drawing.Size(20, 22);
            this.pic083.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic083.TabIndex = 540;
            this.pic083.TabStop = false;
            // 
            // pic093
            // 
            this.pic093.Location = new System.Drawing.Point(171, 63);
            this.pic093.Name = "pic093";
            this.pic093.Size = new System.Drawing.Size(20, 22);
            this.pic093.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic093.TabIndex = 541;
            this.pic093.TabStop = false;
            // 
            // pic0A3
            // 
            this.pic0A3.Location = new System.Drawing.Point(190, 63);
            this.pic0A3.Name = "pic0A3";
            this.pic0A3.Size = new System.Drawing.Size(20, 22);
            this.pic0A3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0A3.TabIndex = 542;
            this.pic0A3.TabStop = false;
            // 
            // pic0B3
            // 
            this.pic0B3.Location = new System.Drawing.Point(209, 63);
            this.pic0B3.Name = "pic0B3";
            this.pic0B3.Size = new System.Drawing.Size(20, 22);
            this.pic0B3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0B3.TabIndex = 543;
            this.pic0B3.TabStop = false;
            // 
            // pic0C3
            // 
            this.pic0C3.Location = new System.Drawing.Point(228, 63);
            this.pic0C3.Name = "pic0C3";
            this.pic0C3.Size = new System.Drawing.Size(20, 22);
            this.pic0C3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0C3.TabIndex = 544;
            this.pic0C3.TabStop = false;
            // 
            // pic0D3
            // 
            this.pic0D3.Location = new System.Drawing.Point(247, 63);
            this.pic0D3.Name = "pic0D3";
            this.pic0D3.Size = new System.Drawing.Size(20, 22);
            this.pic0D3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0D3.TabIndex = 545;
            this.pic0D3.TabStop = false;
            // 
            // pic0E3
            // 
            this.pic0E3.Location = new System.Drawing.Point(266, 63);
            this.pic0E3.Name = "pic0E3";
            this.pic0E3.Size = new System.Drawing.Size(20, 22);
            this.pic0E3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0E3.TabIndex = 546;
            this.pic0E3.TabStop = false;
            // 
            // pic0F3
            // 
            this.pic0F3.Location = new System.Drawing.Point(285, 63);
            this.pic0F3.Name = "pic0F3";
            this.pic0F3.Size = new System.Drawing.Size(20, 22);
            this.pic0F3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0F3.TabIndex = 547;
            this.pic0F3.TabStop = false;
            // 
            // pic103
            // 
            this.pic103.Location = new System.Drawing.Point(304, 63);
            this.pic103.Name = "pic103";
            this.pic103.Size = new System.Drawing.Size(20, 22);
            this.pic103.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic103.TabIndex = 548;
            this.pic103.TabStop = false;
            // 
            // pic113
            // 
            this.pic113.Location = new System.Drawing.Point(323, 63);
            this.pic113.Name = "pic113";
            this.pic113.Size = new System.Drawing.Size(20, 22);
            this.pic113.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic113.TabIndex = 549;
            this.pic113.TabStop = false;
            // 
            // pic123
            // 
            this.pic123.Location = new System.Drawing.Point(342, 63);
            this.pic123.Name = "pic123";
            this.pic123.Size = new System.Drawing.Size(20, 22);
            this.pic123.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic123.TabIndex = 550;
            this.pic123.TabStop = false;
            // 
            // pic133
            // 
            this.pic133.Location = new System.Drawing.Point(361, 63);
            this.pic133.Name = "pic133";
            this.pic133.Size = new System.Drawing.Size(20, 22);
            this.pic133.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic133.TabIndex = 551;
            this.pic133.TabStop = false;
            // 
            // pic143
            // 
            this.pic143.Location = new System.Drawing.Point(380, 63);
            this.pic143.Name = "pic143";
            this.pic143.Size = new System.Drawing.Size(20, 22);
            this.pic143.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic143.TabIndex = 552;
            this.pic143.TabStop = false;
            // 
            // pic153
            // 
            this.pic153.Location = new System.Drawing.Point(399, 63);
            this.pic153.Name = "pic153";
            this.pic153.Size = new System.Drawing.Size(20, 22);
            this.pic153.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic153.TabIndex = 553;
            this.pic153.TabStop = false;
            // 
            // pic163
            // 
            this.pic163.Location = new System.Drawing.Point(418, 63);
            this.pic163.Name = "pic163";
            this.pic163.Size = new System.Drawing.Size(20, 22);
            this.pic163.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic163.TabIndex = 554;
            this.pic163.TabStop = false;
            // 
            // pic173
            // 
            this.pic173.Location = new System.Drawing.Point(437, 63);
            this.pic173.Name = "pic173";
            this.pic173.Size = new System.Drawing.Size(20, 22);
            this.pic173.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic173.TabIndex = 555;
            this.pic173.TabStop = false;
            // 
            // pic183
            // 
            this.pic183.Location = new System.Drawing.Point(456, 63);
            this.pic183.Name = "pic183";
            this.pic183.Size = new System.Drawing.Size(20, 22);
            this.pic183.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic183.TabIndex = 556;
            this.pic183.TabStop = false;
            // 
            // pic193
            // 
            this.pic193.Location = new System.Drawing.Point(475, 63);
            this.pic193.Name = "pic193";
            this.pic193.Size = new System.Drawing.Size(20, 22);
            this.pic193.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic193.TabIndex = 557;
            this.pic193.TabStop = false;
            // 
            // pic1A3
            // 
            this.pic1A3.Location = new System.Drawing.Point(494, 63);
            this.pic1A3.Name = "pic1A3";
            this.pic1A3.Size = new System.Drawing.Size(20, 22);
            this.pic1A3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1A3.TabIndex = 558;
            this.pic1A3.TabStop = false;
            // 
            // pic1B3
            // 
            this.pic1B3.Location = new System.Drawing.Point(513, 63);
            this.pic1B3.Name = "pic1B3";
            this.pic1B3.Size = new System.Drawing.Size(20, 22);
            this.pic1B3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1B3.TabIndex = 559;
            this.pic1B3.TabStop = false;
            // 
            // pic004
            // 
            this.pic004.Location = new System.Drawing.Point(0, 84);
            this.pic004.Name = "pic004";
            this.pic004.Size = new System.Drawing.Size(20, 22);
            this.pic004.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic004.TabIndex = 560;
            this.pic004.TabStop = false;
            // 
            // pic014
            // 
            this.pic014.Location = new System.Drawing.Point(19, 84);
            this.pic014.Name = "pic014";
            this.pic014.Size = new System.Drawing.Size(20, 22);
            this.pic014.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic014.TabIndex = 561;
            this.pic014.TabStop = false;
            // 
            // pic024
            // 
            this.pic024.Location = new System.Drawing.Point(38, 84);
            this.pic024.Name = "pic024";
            this.pic024.Size = new System.Drawing.Size(20, 22);
            this.pic024.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic024.TabIndex = 562;
            this.pic024.TabStop = false;
            // 
            // pic034
            // 
            this.pic034.Location = new System.Drawing.Point(57, 84);
            this.pic034.Name = "pic034";
            this.pic034.Size = new System.Drawing.Size(20, 22);
            this.pic034.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic034.TabIndex = 563;
            this.pic034.TabStop = false;
            // 
            // pic044
            // 
            this.pic044.Location = new System.Drawing.Point(76, 84);
            this.pic044.Name = "pic044";
            this.pic044.Size = new System.Drawing.Size(20, 22);
            this.pic044.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic044.TabIndex = 564;
            this.pic044.TabStop = false;
            // 
            // pic054
            // 
            this.pic054.Location = new System.Drawing.Point(95, 84);
            this.pic054.Name = "pic054";
            this.pic054.Size = new System.Drawing.Size(20, 22);
            this.pic054.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic054.TabIndex = 565;
            this.pic054.TabStop = false;
            // 
            // pic064
            // 
            this.pic064.Location = new System.Drawing.Point(114, 84);
            this.pic064.Name = "pic064";
            this.pic064.Size = new System.Drawing.Size(20, 22);
            this.pic064.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic064.TabIndex = 566;
            this.pic064.TabStop = false;
            // 
            // pic074
            // 
            this.pic074.Location = new System.Drawing.Point(133, 84);
            this.pic074.Name = "pic074";
            this.pic074.Size = new System.Drawing.Size(20, 22);
            this.pic074.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic074.TabIndex = 567;
            this.pic074.TabStop = false;
            // 
            // pic084
            // 
            this.pic084.Location = new System.Drawing.Point(152, 84);
            this.pic084.Name = "pic084";
            this.pic084.Size = new System.Drawing.Size(20, 22);
            this.pic084.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic084.TabIndex = 568;
            this.pic084.TabStop = false;
            // 
            // pic094
            // 
            this.pic094.Location = new System.Drawing.Point(171, 84);
            this.pic094.Name = "pic094";
            this.pic094.Size = new System.Drawing.Size(20, 22);
            this.pic094.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic094.TabIndex = 569;
            this.pic094.TabStop = false;
            // 
            // pic0A4
            // 
            this.pic0A4.Location = new System.Drawing.Point(190, 84);
            this.pic0A4.Name = "pic0A4";
            this.pic0A4.Size = new System.Drawing.Size(20, 22);
            this.pic0A4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0A4.TabIndex = 570;
            this.pic0A4.TabStop = false;
            // 
            // pic0B4
            // 
            this.pic0B4.Location = new System.Drawing.Point(209, 84);
            this.pic0B4.Name = "pic0B4";
            this.pic0B4.Size = new System.Drawing.Size(20, 22);
            this.pic0B4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0B4.TabIndex = 571;
            this.pic0B4.TabStop = false;
            // 
            // pic0C4
            // 
            this.pic0C4.Location = new System.Drawing.Point(228, 84);
            this.pic0C4.Name = "pic0C4";
            this.pic0C4.Size = new System.Drawing.Size(20, 22);
            this.pic0C4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0C4.TabIndex = 572;
            this.pic0C4.TabStop = false;
            // 
            // pic0D4
            // 
            this.pic0D4.Location = new System.Drawing.Point(247, 84);
            this.pic0D4.Name = "pic0D4";
            this.pic0D4.Size = new System.Drawing.Size(20, 22);
            this.pic0D4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0D4.TabIndex = 573;
            this.pic0D4.TabStop = false;
            // 
            // pic0E4
            // 
            this.pic0E4.Location = new System.Drawing.Point(266, 84);
            this.pic0E4.Name = "pic0E4";
            this.pic0E4.Size = new System.Drawing.Size(20, 22);
            this.pic0E4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0E4.TabIndex = 574;
            this.pic0E4.TabStop = false;
            // 
            // pic0F4
            // 
            this.pic0F4.Location = new System.Drawing.Point(285, 84);
            this.pic0F4.Name = "pic0F4";
            this.pic0F4.Size = new System.Drawing.Size(20, 22);
            this.pic0F4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0F4.TabIndex = 575;
            this.pic0F4.TabStop = false;
            // 
            // pic104
            // 
            this.pic104.Location = new System.Drawing.Point(304, 84);
            this.pic104.Name = "pic104";
            this.pic104.Size = new System.Drawing.Size(20, 22);
            this.pic104.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic104.TabIndex = 576;
            this.pic104.TabStop = false;
            // 
            // pic114
            // 
            this.pic114.Location = new System.Drawing.Point(323, 84);
            this.pic114.Name = "pic114";
            this.pic114.Size = new System.Drawing.Size(20, 22);
            this.pic114.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic114.TabIndex = 577;
            this.pic114.TabStop = false;
            // 
            // pic124
            // 
            this.pic124.Location = new System.Drawing.Point(342, 84);
            this.pic124.Name = "pic124";
            this.pic124.Size = new System.Drawing.Size(20, 22);
            this.pic124.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic124.TabIndex = 578;
            this.pic124.TabStop = false;
            // 
            // pic134
            // 
            this.pic134.Location = new System.Drawing.Point(361, 84);
            this.pic134.Name = "pic134";
            this.pic134.Size = new System.Drawing.Size(20, 22);
            this.pic134.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic134.TabIndex = 579;
            this.pic134.TabStop = false;
            // 
            // pic144
            // 
            this.pic144.Location = new System.Drawing.Point(380, 84);
            this.pic144.Name = "pic144";
            this.pic144.Size = new System.Drawing.Size(20, 22);
            this.pic144.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic144.TabIndex = 580;
            this.pic144.TabStop = false;
            // 
            // pic154
            // 
            this.pic154.Location = new System.Drawing.Point(399, 84);
            this.pic154.Name = "pic154";
            this.pic154.Size = new System.Drawing.Size(20, 22);
            this.pic154.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic154.TabIndex = 581;
            this.pic154.TabStop = false;
            // 
            // pic164
            // 
            this.pic164.Location = new System.Drawing.Point(418, 84);
            this.pic164.Name = "pic164";
            this.pic164.Size = new System.Drawing.Size(20, 22);
            this.pic164.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic164.TabIndex = 582;
            this.pic164.TabStop = false;
            // 
            // pic174
            // 
            this.pic174.Location = new System.Drawing.Point(437, 84);
            this.pic174.Name = "pic174";
            this.pic174.Size = new System.Drawing.Size(20, 22);
            this.pic174.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic174.TabIndex = 583;
            this.pic174.TabStop = false;
            // 
            // pic184
            // 
            this.pic184.Location = new System.Drawing.Point(456, 84);
            this.pic184.Name = "pic184";
            this.pic184.Size = new System.Drawing.Size(20, 22);
            this.pic184.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic184.TabIndex = 584;
            this.pic184.TabStop = false;
            // 
            // pic194
            // 
            this.pic194.Location = new System.Drawing.Point(475, 84);
            this.pic194.Name = "pic194";
            this.pic194.Size = new System.Drawing.Size(20, 22);
            this.pic194.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic194.TabIndex = 585;
            this.pic194.TabStop = false;
            // 
            // pic1A4
            // 
            this.pic1A4.Location = new System.Drawing.Point(494, 84);
            this.pic1A4.Name = "pic1A4";
            this.pic1A4.Size = new System.Drawing.Size(20, 22);
            this.pic1A4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1A4.TabIndex = 586;
            this.pic1A4.TabStop = false;
            // 
            // pic1B4
            // 
            this.pic1B4.Location = new System.Drawing.Point(513, 84);
            this.pic1B4.Name = "pic1B4";
            this.pic1B4.Size = new System.Drawing.Size(20, 22);
            this.pic1B4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1B4.TabIndex = 587;
            this.pic1B4.TabStop = false;
            // 
            // pic005
            // 
            this.pic005.Location = new System.Drawing.Point(0, 105);
            this.pic005.Name = "pic005";
            this.pic005.Size = new System.Drawing.Size(20, 22);
            this.pic005.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic005.TabIndex = 588;
            this.pic005.TabStop = false;
            // 
            // pic015
            // 
            this.pic015.Location = new System.Drawing.Point(19, 105);
            this.pic015.Name = "pic015";
            this.pic015.Size = new System.Drawing.Size(20, 22);
            this.pic015.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic015.TabIndex = 589;
            this.pic015.TabStop = false;
            // 
            // pic025
            // 
            this.pic025.Location = new System.Drawing.Point(38, 105);
            this.pic025.Name = "pic025";
            this.pic025.Size = new System.Drawing.Size(20, 22);
            this.pic025.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic025.TabIndex = 590;
            this.pic025.TabStop = false;
            // 
            // pic035
            // 
            this.pic035.Location = new System.Drawing.Point(57, 105);
            this.pic035.Name = "pic035";
            this.pic035.Size = new System.Drawing.Size(20, 22);
            this.pic035.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic035.TabIndex = 591;
            this.pic035.TabStop = false;
            // 
            // pic045
            // 
            this.pic045.Location = new System.Drawing.Point(76, 105);
            this.pic045.Name = "pic045";
            this.pic045.Size = new System.Drawing.Size(20, 22);
            this.pic045.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic045.TabIndex = 592;
            this.pic045.TabStop = false;
            // 
            // pic055
            // 
            this.pic055.Location = new System.Drawing.Point(95, 105);
            this.pic055.Name = "pic055";
            this.pic055.Size = new System.Drawing.Size(20, 22);
            this.pic055.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic055.TabIndex = 593;
            this.pic055.TabStop = false;
            // 
            // pic065
            // 
            this.pic065.Location = new System.Drawing.Point(114, 105);
            this.pic065.Name = "pic065";
            this.pic065.Size = new System.Drawing.Size(20, 22);
            this.pic065.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic065.TabIndex = 594;
            this.pic065.TabStop = false;
            // 
            // pic075
            // 
            this.pic075.Location = new System.Drawing.Point(133, 105);
            this.pic075.Name = "pic075";
            this.pic075.Size = new System.Drawing.Size(20, 22);
            this.pic075.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic075.TabIndex = 595;
            this.pic075.TabStop = false;
            // 
            // pic085
            // 
            this.pic085.Location = new System.Drawing.Point(152, 105);
            this.pic085.Name = "pic085";
            this.pic085.Size = new System.Drawing.Size(20, 22);
            this.pic085.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic085.TabIndex = 596;
            this.pic085.TabStop = false;
            // 
            // pic095
            // 
            this.pic095.Location = new System.Drawing.Point(171, 105);
            this.pic095.Name = "pic095";
            this.pic095.Size = new System.Drawing.Size(20, 22);
            this.pic095.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic095.TabIndex = 597;
            this.pic095.TabStop = false;
            // 
            // pic0A5
            // 
            this.pic0A5.Location = new System.Drawing.Point(190, 105);
            this.pic0A5.Name = "pic0A5";
            this.pic0A5.Size = new System.Drawing.Size(20, 22);
            this.pic0A5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0A5.TabIndex = 598;
            this.pic0A5.TabStop = false;
            // 
            // pic0B5
            // 
            this.pic0B5.Location = new System.Drawing.Point(209, 105);
            this.pic0B5.Name = "pic0B5";
            this.pic0B5.Size = new System.Drawing.Size(20, 22);
            this.pic0B5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0B5.TabIndex = 599;
            this.pic0B5.TabStop = false;
            // 
            // pic0C5
            // 
            this.pic0C5.Location = new System.Drawing.Point(228, 105);
            this.pic0C5.Name = "pic0C5";
            this.pic0C5.Size = new System.Drawing.Size(20, 22);
            this.pic0C5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0C5.TabIndex = 600;
            this.pic0C5.TabStop = false;
            // 
            // pic0D5
            // 
            this.pic0D5.Location = new System.Drawing.Point(247, 105);
            this.pic0D5.Name = "pic0D5";
            this.pic0D5.Size = new System.Drawing.Size(20, 22);
            this.pic0D5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0D5.TabIndex = 601;
            this.pic0D5.TabStop = false;
            // 
            // pic0E5
            // 
            this.pic0E5.Location = new System.Drawing.Point(266, 105);
            this.pic0E5.Name = "pic0E5";
            this.pic0E5.Size = new System.Drawing.Size(20, 22);
            this.pic0E5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0E5.TabIndex = 602;
            this.pic0E5.TabStop = false;
            // 
            // pic0F5
            // 
            this.pic0F5.Location = new System.Drawing.Point(285, 105);
            this.pic0F5.Name = "pic0F5";
            this.pic0F5.Size = new System.Drawing.Size(20, 22);
            this.pic0F5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0F5.TabIndex = 603;
            this.pic0F5.TabStop = false;
            // 
            // pic105
            // 
            this.pic105.Location = new System.Drawing.Point(304, 105);
            this.pic105.Name = "pic105";
            this.pic105.Size = new System.Drawing.Size(20, 22);
            this.pic105.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic105.TabIndex = 604;
            this.pic105.TabStop = false;
            // 
            // pic115
            // 
            this.pic115.Location = new System.Drawing.Point(323, 105);
            this.pic115.Name = "pic115";
            this.pic115.Size = new System.Drawing.Size(20, 22);
            this.pic115.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic115.TabIndex = 605;
            this.pic115.TabStop = false;
            // 
            // pic125
            // 
            this.pic125.Location = new System.Drawing.Point(342, 105);
            this.pic125.Name = "pic125";
            this.pic125.Size = new System.Drawing.Size(20, 22);
            this.pic125.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic125.TabIndex = 606;
            this.pic125.TabStop = false;
            // 
            // pic135
            // 
            this.pic135.Location = new System.Drawing.Point(361, 105);
            this.pic135.Name = "pic135";
            this.pic135.Size = new System.Drawing.Size(20, 22);
            this.pic135.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic135.TabIndex = 607;
            this.pic135.TabStop = false;
            // 
            // pic145
            // 
            this.pic145.Location = new System.Drawing.Point(380, 105);
            this.pic145.Name = "pic145";
            this.pic145.Size = new System.Drawing.Size(20, 22);
            this.pic145.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic145.TabIndex = 608;
            this.pic145.TabStop = false;
            // 
            // pic155
            // 
            this.pic155.Location = new System.Drawing.Point(399, 105);
            this.pic155.Name = "pic155";
            this.pic155.Size = new System.Drawing.Size(20, 22);
            this.pic155.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic155.TabIndex = 609;
            this.pic155.TabStop = false;
            // 
            // pic165
            // 
            this.pic165.Location = new System.Drawing.Point(418, 105);
            this.pic165.Name = "pic165";
            this.pic165.Size = new System.Drawing.Size(20, 22);
            this.pic165.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic165.TabIndex = 610;
            this.pic165.TabStop = false;
            // 
            // pic175
            // 
            this.pic175.Location = new System.Drawing.Point(437, 105);
            this.pic175.Name = "pic175";
            this.pic175.Size = new System.Drawing.Size(20, 22);
            this.pic175.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic175.TabIndex = 611;
            this.pic175.TabStop = false;
            // 
            // pic185
            // 
            this.pic185.Location = new System.Drawing.Point(456, 105);
            this.pic185.Name = "pic185";
            this.pic185.Size = new System.Drawing.Size(20, 22);
            this.pic185.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic185.TabIndex = 612;
            this.pic185.TabStop = false;
            // 
            // pic195
            // 
            this.pic195.Location = new System.Drawing.Point(475, 105);
            this.pic195.Name = "pic195";
            this.pic195.Size = new System.Drawing.Size(20, 22);
            this.pic195.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic195.TabIndex = 613;
            this.pic195.TabStop = false;
            // 
            // pic1A5
            // 
            this.pic1A5.Location = new System.Drawing.Point(494, 105);
            this.pic1A5.Name = "pic1A5";
            this.pic1A5.Size = new System.Drawing.Size(20, 22);
            this.pic1A5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1A5.TabIndex = 614;
            this.pic1A5.TabStop = false;
            // 
            // pic1B5
            // 
            this.pic1B5.Location = new System.Drawing.Point(513, 105);
            this.pic1B5.Name = "pic1B5";
            this.pic1B5.Size = new System.Drawing.Size(20, 22);
            this.pic1B5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1B5.TabIndex = 615;
            this.pic1B5.TabStop = false;
            // 
            // pic006
            // 
            this.pic006.Location = new System.Drawing.Point(0, 126);
            this.pic006.Name = "pic006";
            this.pic006.Size = new System.Drawing.Size(20, 22);
            this.pic006.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic006.TabIndex = 616;
            this.pic006.TabStop = false;
            // 
            // pic016
            // 
            this.pic016.Location = new System.Drawing.Point(19, 126);
            this.pic016.Name = "pic016";
            this.pic016.Size = new System.Drawing.Size(20, 22);
            this.pic016.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic016.TabIndex = 617;
            this.pic016.TabStop = false;
            // 
            // pic026
            // 
            this.pic026.Location = new System.Drawing.Point(38, 126);
            this.pic026.Name = "pic026";
            this.pic026.Size = new System.Drawing.Size(20, 22);
            this.pic026.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic026.TabIndex = 618;
            this.pic026.TabStop = false;
            // 
            // pic036
            // 
            this.pic036.Location = new System.Drawing.Point(57, 126);
            this.pic036.Name = "pic036";
            this.pic036.Size = new System.Drawing.Size(20, 22);
            this.pic036.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic036.TabIndex = 619;
            this.pic036.TabStop = false;
            // 
            // pic046
            // 
            this.pic046.Location = new System.Drawing.Point(76, 126);
            this.pic046.Name = "pic046";
            this.pic046.Size = new System.Drawing.Size(20, 22);
            this.pic046.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic046.TabIndex = 620;
            this.pic046.TabStop = false;
            // 
            // pic056
            // 
            this.pic056.Location = new System.Drawing.Point(95, 126);
            this.pic056.Name = "pic056";
            this.pic056.Size = new System.Drawing.Size(20, 22);
            this.pic056.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic056.TabIndex = 621;
            this.pic056.TabStop = false;
            // 
            // pic066
            // 
            this.pic066.Location = new System.Drawing.Point(114, 126);
            this.pic066.Name = "pic066";
            this.pic066.Size = new System.Drawing.Size(20, 22);
            this.pic066.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic066.TabIndex = 622;
            this.pic066.TabStop = false;
            // 
            // pic076
            // 
            this.pic076.Location = new System.Drawing.Point(133, 126);
            this.pic076.Name = "pic076";
            this.pic076.Size = new System.Drawing.Size(20, 22);
            this.pic076.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic076.TabIndex = 623;
            this.pic076.TabStop = false;
            // 
            // pic086
            // 
            this.pic086.Location = new System.Drawing.Point(152, 126);
            this.pic086.Name = "pic086";
            this.pic086.Size = new System.Drawing.Size(20, 22);
            this.pic086.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic086.TabIndex = 624;
            this.pic086.TabStop = false;
            // 
            // pic096
            // 
            this.pic096.Location = new System.Drawing.Point(171, 126);
            this.pic096.Name = "pic096";
            this.pic096.Size = new System.Drawing.Size(20, 22);
            this.pic096.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic096.TabIndex = 625;
            this.pic096.TabStop = false;
            // 
            // pic0A6
            // 
            this.pic0A6.Location = new System.Drawing.Point(190, 126);
            this.pic0A6.Name = "pic0A6";
            this.pic0A6.Size = new System.Drawing.Size(20, 22);
            this.pic0A6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0A6.TabIndex = 626;
            this.pic0A6.TabStop = false;
            // 
            // pic0B6
            // 
            this.pic0B6.Location = new System.Drawing.Point(209, 126);
            this.pic0B6.Name = "pic0B6";
            this.pic0B6.Size = new System.Drawing.Size(20, 22);
            this.pic0B6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0B6.TabIndex = 627;
            this.pic0B6.TabStop = false;
            // 
            // pic0C6
            // 
            this.pic0C6.Location = new System.Drawing.Point(228, 126);
            this.pic0C6.Name = "pic0C6";
            this.pic0C6.Size = new System.Drawing.Size(20, 22);
            this.pic0C6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0C6.TabIndex = 628;
            this.pic0C6.TabStop = false;
            // 
            // pic0D6
            // 
            this.pic0D6.Location = new System.Drawing.Point(247, 126);
            this.pic0D6.Name = "pic0D6";
            this.pic0D6.Size = new System.Drawing.Size(20, 22);
            this.pic0D6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0D6.TabIndex = 629;
            this.pic0D6.TabStop = false;
            // 
            // pic0E6
            // 
            this.pic0E6.Location = new System.Drawing.Point(266, 126);
            this.pic0E6.Name = "pic0E6";
            this.pic0E6.Size = new System.Drawing.Size(20, 22);
            this.pic0E6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0E6.TabIndex = 630;
            this.pic0E6.TabStop = false;
            // 
            // pic0F6
            // 
            this.pic0F6.Location = new System.Drawing.Point(285, 126);
            this.pic0F6.Name = "pic0F6";
            this.pic0F6.Size = new System.Drawing.Size(20, 22);
            this.pic0F6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0F6.TabIndex = 631;
            this.pic0F6.TabStop = false;
            // 
            // pic106
            // 
            this.pic106.Location = new System.Drawing.Point(304, 126);
            this.pic106.Name = "pic106";
            this.pic106.Size = new System.Drawing.Size(20, 22);
            this.pic106.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic106.TabIndex = 632;
            this.pic106.TabStop = false;
            // 
            // pic116
            // 
            this.pic116.Location = new System.Drawing.Point(323, 126);
            this.pic116.Name = "pic116";
            this.pic116.Size = new System.Drawing.Size(20, 22);
            this.pic116.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic116.TabIndex = 633;
            this.pic116.TabStop = false;
            // 
            // pic126
            // 
            this.pic126.Location = new System.Drawing.Point(342, 126);
            this.pic126.Name = "pic126";
            this.pic126.Size = new System.Drawing.Size(20, 22);
            this.pic126.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic126.TabIndex = 634;
            this.pic126.TabStop = false;
            // 
            // pic136
            // 
            this.pic136.Location = new System.Drawing.Point(361, 126);
            this.pic136.Name = "pic136";
            this.pic136.Size = new System.Drawing.Size(20, 22);
            this.pic136.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic136.TabIndex = 635;
            this.pic136.TabStop = false;
            // 
            // pic146
            // 
            this.pic146.Location = new System.Drawing.Point(380, 126);
            this.pic146.Name = "pic146";
            this.pic146.Size = new System.Drawing.Size(20, 22);
            this.pic146.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic146.TabIndex = 636;
            this.pic146.TabStop = false;
            // 
            // pic156
            // 
            this.pic156.Location = new System.Drawing.Point(399, 126);
            this.pic156.Name = "pic156";
            this.pic156.Size = new System.Drawing.Size(20, 22);
            this.pic156.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic156.TabIndex = 637;
            this.pic156.TabStop = false;
            // 
            // pic166
            // 
            this.pic166.Location = new System.Drawing.Point(418, 126);
            this.pic166.Name = "pic166";
            this.pic166.Size = new System.Drawing.Size(20, 22);
            this.pic166.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic166.TabIndex = 638;
            this.pic166.TabStop = false;
            // 
            // pic176
            // 
            this.pic176.Location = new System.Drawing.Point(437, 126);
            this.pic176.Name = "pic176";
            this.pic176.Size = new System.Drawing.Size(20, 22);
            this.pic176.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic176.TabIndex = 639;
            this.pic176.TabStop = false;
            // 
            // pic186
            // 
            this.pic186.Location = new System.Drawing.Point(456, 126);
            this.pic186.Name = "pic186";
            this.pic186.Size = new System.Drawing.Size(20, 22);
            this.pic186.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic186.TabIndex = 640;
            this.pic186.TabStop = false;
            // 
            // pic196
            // 
            this.pic196.Location = new System.Drawing.Point(475, 126);
            this.pic196.Name = "pic196";
            this.pic196.Size = new System.Drawing.Size(20, 22);
            this.pic196.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic196.TabIndex = 641;
            this.pic196.TabStop = false;
            // 
            // pic1A6
            // 
            this.pic1A6.Location = new System.Drawing.Point(494, 126);
            this.pic1A6.Name = "pic1A6";
            this.pic1A6.Size = new System.Drawing.Size(20, 22);
            this.pic1A6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1A6.TabIndex = 642;
            this.pic1A6.TabStop = false;
            // 
            // pic1B6
            // 
            this.pic1B6.Location = new System.Drawing.Point(513, 126);
            this.pic1B6.Name = "pic1B6";
            this.pic1B6.Size = new System.Drawing.Size(20, 22);
            this.pic1B6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1B6.TabIndex = 643;
            this.pic1B6.TabStop = false;
            // 
            // pic007
            // 
            this.pic007.Location = new System.Drawing.Point(0, 147);
            this.pic007.Name = "pic007";
            this.pic007.Size = new System.Drawing.Size(20, 22);
            this.pic007.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic007.TabIndex = 644;
            this.pic007.TabStop = false;
            // 
            // pic017
            // 
            this.pic017.Location = new System.Drawing.Point(19, 147);
            this.pic017.Name = "pic017";
            this.pic017.Size = new System.Drawing.Size(20, 22);
            this.pic017.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic017.TabIndex = 645;
            this.pic017.TabStop = false;
            // 
            // pic027
            // 
            this.pic027.Location = new System.Drawing.Point(38, 147);
            this.pic027.Name = "pic027";
            this.pic027.Size = new System.Drawing.Size(20, 22);
            this.pic027.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic027.TabIndex = 646;
            this.pic027.TabStop = false;
            // 
            // pic037
            // 
            this.pic037.Location = new System.Drawing.Point(57, 147);
            this.pic037.Name = "pic037";
            this.pic037.Size = new System.Drawing.Size(20, 22);
            this.pic037.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic037.TabIndex = 647;
            this.pic037.TabStop = false;
            // 
            // pic047
            // 
            this.pic047.Location = new System.Drawing.Point(76, 147);
            this.pic047.Name = "pic047";
            this.pic047.Size = new System.Drawing.Size(20, 22);
            this.pic047.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic047.TabIndex = 648;
            this.pic047.TabStop = false;
            // 
            // pic057
            // 
            this.pic057.Location = new System.Drawing.Point(95, 147);
            this.pic057.Name = "pic057";
            this.pic057.Size = new System.Drawing.Size(20, 22);
            this.pic057.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic057.TabIndex = 649;
            this.pic057.TabStop = false;
            // 
            // pic067
            // 
            this.pic067.Location = new System.Drawing.Point(114, 147);
            this.pic067.Name = "pic067";
            this.pic067.Size = new System.Drawing.Size(20, 22);
            this.pic067.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic067.TabIndex = 650;
            this.pic067.TabStop = false;
            // 
            // pic077
            // 
            this.pic077.Location = new System.Drawing.Point(133, 147);
            this.pic077.Name = "pic077";
            this.pic077.Size = new System.Drawing.Size(20, 22);
            this.pic077.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic077.TabIndex = 651;
            this.pic077.TabStop = false;
            // 
            // pic087
            // 
            this.pic087.Location = new System.Drawing.Point(152, 147);
            this.pic087.Name = "pic087";
            this.pic087.Size = new System.Drawing.Size(20, 22);
            this.pic087.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic087.TabIndex = 652;
            this.pic087.TabStop = false;
            // 
            // pic097
            // 
            this.pic097.Location = new System.Drawing.Point(171, 147);
            this.pic097.Name = "pic097";
            this.pic097.Size = new System.Drawing.Size(20, 22);
            this.pic097.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic097.TabIndex = 653;
            this.pic097.TabStop = false;
            // 
            // pic0A7
            // 
            this.pic0A7.Location = new System.Drawing.Point(190, 147);
            this.pic0A7.Name = "pic0A7";
            this.pic0A7.Size = new System.Drawing.Size(20, 22);
            this.pic0A7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0A7.TabIndex = 654;
            this.pic0A7.TabStop = false;
            // 
            // pic0B7
            // 
            this.pic0B7.Location = new System.Drawing.Point(209, 147);
            this.pic0B7.Name = "pic0B7";
            this.pic0B7.Size = new System.Drawing.Size(20, 22);
            this.pic0B7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0B7.TabIndex = 655;
            this.pic0B7.TabStop = false;
            // 
            // pic0C7
            // 
            this.pic0C7.Location = new System.Drawing.Point(228, 147);
            this.pic0C7.Name = "pic0C7";
            this.pic0C7.Size = new System.Drawing.Size(20, 22);
            this.pic0C7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0C7.TabIndex = 656;
            this.pic0C7.TabStop = false;
            // 
            // pic0D7
            // 
            this.pic0D7.Location = new System.Drawing.Point(247, 147);
            this.pic0D7.Name = "pic0D7";
            this.pic0D7.Size = new System.Drawing.Size(20, 22);
            this.pic0D7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0D7.TabIndex = 657;
            this.pic0D7.TabStop = false;
            // 
            // pic0E7
            // 
            this.pic0E7.Location = new System.Drawing.Point(266, 147);
            this.pic0E7.Name = "pic0E7";
            this.pic0E7.Size = new System.Drawing.Size(20, 22);
            this.pic0E7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0E7.TabIndex = 658;
            this.pic0E7.TabStop = false;
            // 
            // pic0F7
            // 
            this.pic0F7.Location = new System.Drawing.Point(285, 147);
            this.pic0F7.Name = "pic0F7";
            this.pic0F7.Size = new System.Drawing.Size(20, 22);
            this.pic0F7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0F7.TabIndex = 659;
            this.pic0F7.TabStop = false;
            // 
            // pic107
            // 
            this.pic107.Location = new System.Drawing.Point(304, 147);
            this.pic107.Name = "pic107";
            this.pic107.Size = new System.Drawing.Size(20, 22);
            this.pic107.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic107.TabIndex = 660;
            this.pic107.TabStop = false;
            // 
            // pic117
            // 
            this.pic117.Location = new System.Drawing.Point(323, 147);
            this.pic117.Name = "pic117";
            this.pic117.Size = new System.Drawing.Size(20, 22);
            this.pic117.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic117.TabIndex = 661;
            this.pic117.TabStop = false;
            // 
            // pic127
            // 
            this.pic127.Location = new System.Drawing.Point(342, 147);
            this.pic127.Name = "pic127";
            this.pic127.Size = new System.Drawing.Size(20, 22);
            this.pic127.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic127.TabIndex = 662;
            this.pic127.TabStop = false;
            // 
            // pic137
            // 
            this.pic137.Location = new System.Drawing.Point(361, 147);
            this.pic137.Name = "pic137";
            this.pic137.Size = new System.Drawing.Size(20, 22);
            this.pic137.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic137.TabIndex = 663;
            this.pic137.TabStop = false;
            // 
            // pic147
            // 
            this.pic147.Location = new System.Drawing.Point(380, 147);
            this.pic147.Name = "pic147";
            this.pic147.Size = new System.Drawing.Size(20, 22);
            this.pic147.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic147.TabIndex = 664;
            this.pic147.TabStop = false;
            // 
            // pic157
            // 
            this.pic157.Location = new System.Drawing.Point(399, 147);
            this.pic157.Name = "pic157";
            this.pic157.Size = new System.Drawing.Size(20, 22);
            this.pic157.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic157.TabIndex = 665;
            this.pic157.TabStop = false;
            // 
            // pic167
            // 
            this.pic167.Location = new System.Drawing.Point(418, 147);
            this.pic167.Name = "pic167";
            this.pic167.Size = new System.Drawing.Size(20, 22);
            this.pic167.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic167.TabIndex = 666;
            this.pic167.TabStop = false;
            // 
            // pic177
            // 
            this.pic177.Location = new System.Drawing.Point(437, 147);
            this.pic177.Name = "pic177";
            this.pic177.Size = new System.Drawing.Size(20, 22);
            this.pic177.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic177.TabIndex = 667;
            this.pic177.TabStop = false;
            // 
            // pic187
            // 
            this.pic187.Location = new System.Drawing.Point(456, 147);
            this.pic187.Name = "pic187";
            this.pic187.Size = new System.Drawing.Size(20, 22);
            this.pic187.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic187.TabIndex = 668;
            this.pic187.TabStop = false;
            // 
            // pic197
            // 
            this.pic197.Location = new System.Drawing.Point(475, 147);
            this.pic197.Name = "pic197";
            this.pic197.Size = new System.Drawing.Size(20, 22);
            this.pic197.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic197.TabIndex = 669;
            this.pic197.TabStop = false;
            // 
            // pic1A7
            // 
            this.pic1A7.Location = new System.Drawing.Point(494, 147);
            this.pic1A7.Name = "pic1A7";
            this.pic1A7.Size = new System.Drawing.Size(20, 22);
            this.pic1A7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1A7.TabIndex = 670;
            this.pic1A7.TabStop = false;
            // 
            // pic1B7
            // 
            this.pic1B7.Location = new System.Drawing.Point(513, 147);
            this.pic1B7.Name = "pic1B7";
            this.pic1B7.Size = new System.Drawing.Size(20, 22);
            this.pic1B7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1B7.TabIndex = 671;
            this.pic1B7.TabStop = false;
            // 
            // pic008
            // 
            this.pic008.Location = new System.Drawing.Point(0, 168);
            this.pic008.Name = "pic008";
            this.pic008.Size = new System.Drawing.Size(20, 22);
            this.pic008.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic008.TabIndex = 672;
            this.pic008.TabStop = false;
            // 
            // pic018
            // 
            this.pic018.Location = new System.Drawing.Point(19, 168);
            this.pic018.Name = "pic018";
            this.pic018.Size = new System.Drawing.Size(20, 22);
            this.pic018.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic018.TabIndex = 673;
            this.pic018.TabStop = false;
            // 
            // pic028
            // 
            this.pic028.Location = new System.Drawing.Point(38, 168);
            this.pic028.Name = "pic028";
            this.pic028.Size = new System.Drawing.Size(20, 22);
            this.pic028.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic028.TabIndex = 674;
            this.pic028.TabStop = false;
            // 
            // pic038
            // 
            this.pic038.Location = new System.Drawing.Point(57, 168);
            this.pic038.Name = "pic038";
            this.pic038.Size = new System.Drawing.Size(20, 22);
            this.pic038.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic038.TabIndex = 675;
            this.pic038.TabStop = false;
            // 
            // pic048
            // 
            this.pic048.Location = new System.Drawing.Point(76, 168);
            this.pic048.Name = "pic048";
            this.pic048.Size = new System.Drawing.Size(20, 22);
            this.pic048.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic048.TabIndex = 676;
            this.pic048.TabStop = false;
            // 
            // pic058
            // 
            this.pic058.Location = new System.Drawing.Point(95, 168);
            this.pic058.Name = "pic058";
            this.pic058.Size = new System.Drawing.Size(20, 22);
            this.pic058.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic058.TabIndex = 677;
            this.pic058.TabStop = false;
            // 
            // pic068
            // 
            this.pic068.Location = new System.Drawing.Point(114, 168);
            this.pic068.Name = "pic068";
            this.pic068.Size = new System.Drawing.Size(20, 22);
            this.pic068.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic068.TabIndex = 678;
            this.pic068.TabStop = false;
            // 
            // pic078
            // 
            this.pic078.Location = new System.Drawing.Point(133, 168);
            this.pic078.Name = "pic078";
            this.pic078.Size = new System.Drawing.Size(20, 22);
            this.pic078.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic078.TabIndex = 679;
            this.pic078.TabStop = false;
            // 
            // pic088
            // 
            this.pic088.Location = new System.Drawing.Point(152, 168);
            this.pic088.Name = "pic088";
            this.pic088.Size = new System.Drawing.Size(20, 22);
            this.pic088.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic088.TabIndex = 680;
            this.pic088.TabStop = false;
            // 
            // pic098
            // 
            this.pic098.Location = new System.Drawing.Point(171, 168);
            this.pic098.Name = "pic098";
            this.pic098.Size = new System.Drawing.Size(20, 22);
            this.pic098.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic098.TabIndex = 681;
            this.pic098.TabStop = false;
            // 
            // pic0A8
            // 
            this.pic0A8.Location = new System.Drawing.Point(190, 168);
            this.pic0A8.Name = "pic0A8";
            this.pic0A8.Size = new System.Drawing.Size(20, 22);
            this.pic0A8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0A8.TabIndex = 682;
            this.pic0A8.TabStop = false;
            // 
            // pic0B8
            // 
            this.pic0B8.Location = new System.Drawing.Point(209, 168);
            this.pic0B8.Name = "pic0B8";
            this.pic0B8.Size = new System.Drawing.Size(20, 22);
            this.pic0B8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0B8.TabIndex = 683;
            this.pic0B8.TabStop = false;
            // 
            // pic0C8
            // 
            this.pic0C8.Location = new System.Drawing.Point(228, 168);
            this.pic0C8.Name = "pic0C8";
            this.pic0C8.Size = new System.Drawing.Size(20, 22);
            this.pic0C8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0C8.TabIndex = 684;
            this.pic0C8.TabStop = false;
            // 
            // pic0D8
            // 
            this.pic0D8.Location = new System.Drawing.Point(247, 168);
            this.pic0D8.Name = "pic0D8";
            this.pic0D8.Size = new System.Drawing.Size(20, 22);
            this.pic0D8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0D8.TabIndex = 685;
            this.pic0D8.TabStop = false;
            // 
            // pic0E8
            // 
            this.pic0E8.Location = new System.Drawing.Point(266, 168);
            this.pic0E8.Name = "pic0E8";
            this.pic0E8.Size = new System.Drawing.Size(20, 22);
            this.pic0E8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0E8.TabIndex = 686;
            this.pic0E8.TabStop = false;
            // 
            // pic0F8
            // 
            this.pic0F8.Location = new System.Drawing.Point(285, 168);
            this.pic0F8.Name = "pic0F8";
            this.pic0F8.Size = new System.Drawing.Size(20, 22);
            this.pic0F8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0F8.TabIndex = 687;
            this.pic0F8.TabStop = false;
            // 
            // pic108
            // 
            this.pic108.Location = new System.Drawing.Point(304, 168);
            this.pic108.Name = "pic108";
            this.pic108.Size = new System.Drawing.Size(20, 22);
            this.pic108.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic108.TabIndex = 688;
            this.pic108.TabStop = false;
            // 
            // pic118
            // 
            this.pic118.Location = new System.Drawing.Point(323, 168);
            this.pic118.Name = "pic118";
            this.pic118.Size = new System.Drawing.Size(20, 22);
            this.pic118.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic118.TabIndex = 689;
            this.pic118.TabStop = false;
            // 
            // pic128
            // 
            this.pic128.Location = new System.Drawing.Point(342, 168);
            this.pic128.Name = "pic128";
            this.pic128.Size = new System.Drawing.Size(20, 22);
            this.pic128.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic128.TabIndex = 690;
            this.pic128.TabStop = false;
            // 
            // pic138
            // 
            this.pic138.Location = new System.Drawing.Point(361, 168);
            this.pic138.Name = "pic138";
            this.pic138.Size = new System.Drawing.Size(20, 22);
            this.pic138.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic138.TabIndex = 691;
            this.pic138.TabStop = false;
            // 
            // pic148
            // 
            this.pic148.Location = new System.Drawing.Point(380, 168);
            this.pic148.Name = "pic148";
            this.pic148.Size = new System.Drawing.Size(20, 22);
            this.pic148.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic148.TabIndex = 692;
            this.pic148.TabStop = false;
            // 
            // pic158
            // 
            this.pic158.Location = new System.Drawing.Point(399, 168);
            this.pic158.Name = "pic158";
            this.pic158.Size = new System.Drawing.Size(20, 22);
            this.pic158.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic158.TabIndex = 693;
            this.pic158.TabStop = false;
            // 
            // pic168
            // 
            this.pic168.Location = new System.Drawing.Point(418, 168);
            this.pic168.Name = "pic168";
            this.pic168.Size = new System.Drawing.Size(20, 22);
            this.pic168.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic168.TabIndex = 694;
            this.pic168.TabStop = false;
            // 
            // pic178
            // 
            this.pic178.Location = new System.Drawing.Point(437, 168);
            this.pic178.Name = "pic178";
            this.pic178.Size = new System.Drawing.Size(20, 22);
            this.pic178.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic178.TabIndex = 695;
            this.pic178.TabStop = false;
            // 
            // pic188
            // 
            this.pic188.Location = new System.Drawing.Point(456, 168);
            this.pic188.Name = "pic188";
            this.pic188.Size = new System.Drawing.Size(20, 22);
            this.pic188.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic188.TabIndex = 696;
            this.pic188.TabStop = false;
            // 
            // pic198
            // 
            this.pic198.Location = new System.Drawing.Point(475, 168);
            this.pic198.Name = "pic198";
            this.pic198.Size = new System.Drawing.Size(20, 22);
            this.pic198.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic198.TabIndex = 697;
            this.pic198.TabStop = false;
            // 
            // pic1A8
            // 
            this.pic1A8.Location = new System.Drawing.Point(494, 168);
            this.pic1A8.Name = "pic1A8";
            this.pic1A8.Size = new System.Drawing.Size(20, 22);
            this.pic1A8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1A8.TabIndex = 698;
            this.pic1A8.TabStop = false;
            // 
            // pic1B8
            // 
            this.pic1B8.Location = new System.Drawing.Point(513, 168);
            this.pic1B8.Name = "pic1B8";
            this.pic1B8.Size = new System.Drawing.Size(20, 22);
            this.pic1B8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1B8.TabIndex = 699;
            this.pic1B8.TabStop = false;
            // 
            // pic009
            // 
            this.pic009.Location = new System.Drawing.Point(0, 189);
            this.pic009.Name = "pic009";
            this.pic009.Size = new System.Drawing.Size(20, 22);
            this.pic009.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic009.TabIndex = 700;
            this.pic009.TabStop = false;
            // 
            // pic019
            // 
            this.pic019.Location = new System.Drawing.Point(19, 189);
            this.pic019.Name = "pic019";
            this.pic019.Size = new System.Drawing.Size(20, 22);
            this.pic019.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic019.TabIndex = 701;
            this.pic019.TabStop = false;
            // 
            // pic029
            // 
            this.pic029.Location = new System.Drawing.Point(38, 189);
            this.pic029.Name = "pic029";
            this.pic029.Size = new System.Drawing.Size(20, 22);
            this.pic029.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic029.TabIndex = 702;
            this.pic029.TabStop = false;
            // 
            // pic039
            // 
            this.pic039.Location = new System.Drawing.Point(57, 189);
            this.pic039.Name = "pic039";
            this.pic039.Size = new System.Drawing.Size(20, 22);
            this.pic039.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic039.TabIndex = 703;
            this.pic039.TabStop = false;
            // 
            // pic049
            // 
            this.pic049.Location = new System.Drawing.Point(76, 189);
            this.pic049.Name = "pic049";
            this.pic049.Size = new System.Drawing.Size(20, 22);
            this.pic049.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic049.TabIndex = 704;
            this.pic049.TabStop = false;
            // 
            // pic059
            // 
            this.pic059.Location = new System.Drawing.Point(95, 189);
            this.pic059.Name = "pic059";
            this.pic059.Size = new System.Drawing.Size(20, 22);
            this.pic059.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic059.TabIndex = 705;
            this.pic059.TabStop = false;
            // 
            // pic069
            // 
            this.pic069.Location = new System.Drawing.Point(114, 189);
            this.pic069.Name = "pic069";
            this.pic069.Size = new System.Drawing.Size(20, 22);
            this.pic069.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic069.TabIndex = 706;
            this.pic069.TabStop = false;
            // 
            // pic079
            // 
            this.pic079.Location = new System.Drawing.Point(133, 189);
            this.pic079.Name = "pic079";
            this.pic079.Size = new System.Drawing.Size(20, 22);
            this.pic079.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic079.TabIndex = 707;
            this.pic079.TabStop = false;
            // 
            // pic089
            // 
            this.pic089.Location = new System.Drawing.Point(152, 189);
            this.pic089.Name = "pic089";
            this.pic089.Size = new System.Drawing.Size(20, 22);
            this.pic089.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic089.TabIndex = 708;
            this.pic089.TabStop = false;
            // 
            // pic099
            // 
            this.pic099.Location = new System.Drawing.Point(171, 189);
            this.pic099.Name = "pic099";
            this.pic099.Size = new System.Drawing.Size(20, 22);
            this.pic099.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic099.TabIndex = 709;
            this.pic099.TabStop = false;
            // 
            // pic0A9
            // 
            this.pic0A9.Location = new System.Drawing.Point(190, 189);
            this.pic0A9.Name = "pic0A9";
            this.pic0A9.Size = new System.Drawing.Size(20, 22);
            this.pic0A9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0A9.TabIndex = 710;
            this.pic0A9.TabStop = false;
            // 
            // pic0B9
            // 
            this.pic0B9.Location = new System.Drawing.Point(209, 189);
            this.pic0B9.Name = "pic0B9";
            this.pic0B9.Size = new System.Drawing.Size(20, 22);
            this.pic0B9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0B9.TabIndex = 711;
            this.pic0B9.TabStop = false;
            // 
            // pic0C9
            // 
            this.pic0C9.Location = new System.Drawing.Point(228, 189);
            this.pic0C9.Name = "pic0C9";
            this.pic0C9.Size = new System.Drawing.Size(20, 22);
            this.pic0C9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0C9.TabIndex = 712;
            this.pic0C9.TabStop = false;
            // 
            // pic0D9
            // 
            this.pic0D9.Location = new System.Drawing.Point(247, 189);
            this.pic0D9.Name = "pic0D9";
            this.pic0D9.Size = new System.Drawing.Size(20, 22);
            this.pic0D9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0D9.TabIndex = 713;
            this.pic0D9.TabStop = false;
            // 
            // pic0E9
            // 
            this.pic0E9.Location = new System.Drawing.Point(266, 189);
            this.pic0E9.Name = "pic0E9";
            this.pic0E9.Size = new System.Drawing.Size(20, 22);
            this.pic0E9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0E9.TabIndex = 714;
            this.pic0E9.TabStop = false;
            // 
            // pic0F9
            // 
            this.pic0F9.Location = new System.Drawing.Point(285, 189);
            this.pic0F9.Name = "pic0F9";
            this.pic0F9.Size = new System.Drawing.Size(20, 22);
            this.pic0F9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0F9.TabIndex = 715;
            this.pic0F9.TabStop = false;
            // 
            // pic109
            // 
            this.pic109.Location = new System.Drawing.Point(304, 189);
            this.pic109.Name = "pic109";
            this.pic109.Size = new System.Drawing.Size(20, 22);
            this.pic109.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic109.TabIndex = 716;
            this.pic109.TabStop = false;
            // 
            // pic119
            // 
            this.pic119.Location = new System.Drawing.Point(323, 189);
            this.pic119.Name = "pic119";
            this.pic119.Size = new System.Drawing.Size(20, 22);
            this.pic119.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic119.TabIndex = 717;
            this.pic119.TabStop = false;
            // 
            // pic129
            // 
            this.pic129.Location = new System.Drawing.Point(342, 189);
            this.pic129.Name = "pic129";
            this.pic129.Size = new System.Drawing.Size(20, 22);
            this.pic129.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic129.TabIndex = 718;
            this.pic129.TabStop = false;
            // 
            // pic139
            // 
            this.pic139.Location = new System.Drawing.Point(361, 189);
            this.pic139.Name = "pic139";
            this.pic139.Size = new System.Drawing.Size(20, 22);
            this.pic139.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic139.TabIndex = 719;
            this.pic139.TabStop = false;
            // 
            // pic149
            // 
            this.pic149.Location = new System.Drawing.Point(380, 189);
            this.pic149.Name = "pic149";
            this.pic149.Size = new System.Drawing.Size(20, 22);
            this.pic149.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic149.TabIndex = 720;
            this.pic149.TabStop = false;
            // 
            // pic159
            // 
            this.pic159.Location = new System.Drawing.Point(399, 189);
            this.pic159.Name = "pic159";
            this.pic159.Size = new System.Drawing.Size(20, 22);
            this.pic159.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic159.TabIndex = 721;
            this.pic159.TabStop = false;
            // 
            // pic169
            // 
            this.pic169.Location = new System.Drawing.Point(418, 189);
            this.pic169.Name = "pic169";
            this.pic169.Size = new System.Drawing.Size(20, 22);
            this.pic169.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic169.TabIndex = 722;
            this.pic169.TabStop = false;
            // 
            // pic179
            // 
            this.pic179.Location = new System.Drawing.Point(437, 189);
            this.pic179.Name = "pic179";
            this.pic179.Size = new System.Drawing.Size(20, 22);
            this.pic179.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic179.TabIndex = 723;
            this.pic179.TabStop = false;
            // 
            // pic189
            // 
            this.pic189.Location = new System.Drawing.Point(456, 189);
            this.pic189.Name = "pic189";
            this.pic189.Size = new System.Drawing.Size(20, 22);
            this.pic189.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic189.TabIndex = 724;
            this.pic189.TabStop = false;
            // 
            // pic199
            // 
            this.pic199.Location = new System.Drawing.Point(475, 189);
            this.pic199.Name = "pic199";
            this.pic199.Size = new System.Drawing.Size(20, 22);
            this.pic199.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic199.TabIndex = 725;
            this.pic199.TabStop = false;
            // 
            // pic1A9
            // 
            this.pic1A9.Location = new System.Drawing.Point(494, 189);
            this.pic1A9.Name = "pic1A9";
            this.pic1A9.Size = new System.Drawing.Size(20, 22);
            this.pic1A9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1A9.TabIndex = 726;
            this.pic1A9.TabStop = false;
            // 
            // pic1B9
            // 
            this.pic1B9.Location = new System.Drawing.Point(513, 189);
            this.pic1B9.Name = "pic1B9";
            this.pic1B9.Size = new System.Drawing.Size(20, 22);
            this.pic1B9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1B9.TabIndex = 727;
            this.pic1B9.TabStop = false;
            // 
            // pic00A
            // 
            this.pic00A.Location = new System.Drawing.Point(0, 210);
            this.pic00A.Name = "pic00A";
            this.pic00A.Size = new System.Drawing.Size(20, 22);
            this.pic00A.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic00A.TabIndex = 728;
            this.pic00A.TabStop = false;
            // 
            // pic01A
            // 
            this.pic01A.Location = new System.Drawing.Point(19, 210);
            this.pic01A.Name = "pic01A";
            this.pic01A.Size = new System.Drawing.Size(20, 22);
            this.pic01A.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic01A.TabIndex = 729;
            this.pic01A.TabStop = false;
            // 
            // pic02A
            // 
            this.pic02A.Location = new System.Drawing.Point(38, 210);
            this.pic02A.Name = "pic02A";
            this.pic02A.Size = new System.Drawing.Size(20, 22);
            this.pic02A.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic02A.TabIndex = 730;
            this.pic02A.TabStop = false;
            // 
            // pic03A
            // 
            this.pic03A.Location = new System.Drawing.Point(57, 210);
            this.pic03A.Name = "pic03A";
            this.pic03A.Size = new System.Drawing.Size(20, 22);
            this.pic03A.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic03A.TabIndex = 731;
            this.pic03A.TabStop = false;
            // 
            // pic04A
            // 
            this.pic04A.Location = new System.Drawing.Point(76, 210);
            this.pic04A.Name = "pic04A";
            this.pic04A.Size = new System.Drawing.Size(20, 22);
            this.pic04A.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic04A.TabIndex = 732;
            this.pic04A.TabStop = false;
            // 
            // pic05A
            // 
            this.pic05A.Location = new System.Drawing.Point(95, 210);
            this.pic05A.Name = "pic05A";
            this.pic05A.Size = new System.Drawing.Size(20, 22);
            this.pic05A.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic05A.TabIndex = 733;
            this.pic05A.TabStop = false;
            // 
            // pic06A
            // 
            this.pic06A.Location = new System.Drawing.Point(114, 210);
            this.pic06A.Name = "pic06A";
            this.pic06A.Size = new System.Drawing.Size(20, 22);
            this.pic06A.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic06A.TabIndex = 734;
            this.pic06A.TabStop = false;
            // 
            // pic07A
            // 
            this.pic07A.Location = new System.Drawing.Point(133, 210);
            this.pic07A.Name = "pic07A";
            this.pic07A.Size = new System.Drawing.Size(20, 22);
            this.pic07A.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic07A.TabIndex = 735;
            this.pic07A.TabStop = false;
            // 
            // pic08A
            // 
            this.pic08A.Location = new System.Drawing.Point(152, 210);
            this.pic08A.Name = "pic08A";
            this.pic08A.Size = new System.Drawing.Size(20, 22);
            this.pic08A.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic08A.TabIndex = 736;
            this.pic08A.TabStop = false;
            // 
            // pic09A
            // 
            this.pic09A.Location = new System.Drawing.Point(171, 210);
            this.pic09A.Name = "pic09A";
            this.pic09A.Size = new System.Drawing.Size(20, 22);
            this.pic09A.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic09A.TabIndex = 737;
            this.pic09A.TabStop = false;
            // 
            // pic0AA
            // 
            this.pic0AA.Location = new System.Drawing.Point(190, 210);
            this.pic0AA.Name = "pic0AA";
            this.pic0AA.Size = new System.Drawing.Size(20, 22);
            this.pic0AA.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0AA.TabIndex = 738;
            this.pic0AA.TabStop = false;
            // 
            // pic0BA
            // 
            this.pic0BA.Location = new System.Drawing.Point(209, 210);
            this.pic0BA.Name = "pic0BA";
            this.pic0BA.Size = new System.Drawing.Size(20, 22);
            this.pic0BA.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0BA.TabIndex = 739;
            this.pic0BA.TabStop = false;
            // 
            // pic0CA
            // 
            this.pic0CA.Location = new System.Drawing.Point(228, 210);
            this.pic0CA.Name = "pic0CA";
            this.pic0CA.Size = new System.Drawing.Size(20, 22);
            this.pic0CA.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0CA.TabIndex = 740;
            this.pic0CA.TabStop = false;
            // 
            // pic0DA
            // 
            this.pic0DA.Location = new System.Drawing.Point(247, 210);
            this.pic0DA.Name = "pic0DA";
            this.pic0DA.Size = new System.Drawing.Size(20, 22);
            this.pic0DA.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0DA.TabIndex = 741;
            this.pic0DA.TabStop = false;
            // 
            // pic0EA
            // 
            this.pic0EA.Location = new System.Drawing.Point(266, 210);
            this.pic0EA.Name = "pic0EA";
            this.pic0EA.Size = new System.Drawing.Size(20, 22);
            this.pic0EA.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0EA.TabIndex = 742;
            this.pic0EA.TabStop = false;
            // 
            // pic0FA
            // 
            this.pic0FA.Location = new System.Drawing.Point(285, 210);
            this.pic0FA.Name = "pic0FA";
            this.pic0FA.Size = new System.Drawing.Size(20, 22);
            this.pic0FA.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0FA.TabIndex = 743;
            this.pic0FA.TabStop = false;
            // 
            // pic10A
            // 
            this.pic10A.Location = new System.Drawing.Point(304, 210);
            this.pic10A.Name = "pic10A";
            this.pic10A.Size = new System.Drawing.Size(20, 22);
            this.pic10A.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic10A.TabIndex = 744;
            this.pic10A.TabStop = false;
            // 
            // pic11A
            // 
            this.pic11A.Location = new System.Drawing.Point(323, 210);
            this.pic11A.Name = "pic11A";
            this.pic11A.Size = new System.Drawing.Size(20, 22);
            this.pic11A.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic11A.TabIndex = 745;
            this.pic11A.TabStop = false;
            // 
            // pic12A
            // 
            this.pic12A.Location = new System.Drawing.Point(342, 210);
            this.pic12A.Name = "pic12A";
            this.pic12A.Size = new System.Drawing.Size(20, 22);
            this.pic12A.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic12A.TabIndex = 746;
            this.pic12A.TabStop = false;
            // 
            // pic13A
            // 
            this.pic13A.Location = new System.Drawing.Point(361, 210);
            this.pic13A.Name = "pic13A";
            this.pic13A.Size = new System.Drawing.Size(20, 22);
            this.pic13A.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic13A.TabIndex = 747;
            this.pic13A.TabStop = false;
            // 
            // pic14A
            // 
            this.pic14A.Location = new System.Drawing.Point(380, 210);
            this.pic14A.Name = "pic14A";
            this.pic14A.Size = new System.Drawing.Size(20, 22);
            this.pic14A.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic14A.TabIndex = 748;
            this.pic14A.TabStop = false;
            // 
            // pic15A
            // 
            this.pic15A.Location = new System.Drawing.Point(399, 210);
            this.pic15A.Name = "pic15A";
            this.pic15A.Size = new System.Drawing.Size(20, 22);
            this.pic15A.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic15A.TabIndex = 749;
            this.pic15A.TabStop = false;
            // 
            // pic16A
            // 
            this.pic16A.Location = new System.Drawing.Point(418, 210);
            this.pic16A.Name = "pic16A";
            this.pic16A.Size = new System.Drawing.Size(20, 22);
            this.pic16A.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic16A.TabIndex = 750;
            this.pic16A.TabStop = false;
            // 
            // pic17A
            // 
            this.pic17A.Location = new System.Drawing.Point(437, 210);
            this.pic17A.Name = "pic17A";
            this.pic17A.Size = new System.Drawing.Size(20, 22);
            this.pic17A.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic17A.TabIndex = 751;
            this.pic17A.TabStop = false;
            // 
            // pic18A
            // 
            this.pic18A.Location = new System.Drawing.Point(456, 210);
            this.pic18A.Name = "pic18A";
            this.pic18A.Size = new System.Drawing.Size(20, 22);
            this.pic18A.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic18A.TabIndex = 752;
            this.pic18A.TabStop = false;
            // 
            // pic19A
            // 
            this.pic19A.Location = new System.Drawing.Point(475, 210);
            this.pic19A.Name = "pic19A";
            this.pic19A.Size = new System.Drawing.Size(20, 22);
            this.pic19A.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic19A.TabIndex = 753;
            this.pic19A.TabStop = false;
            // 
            // pic1AA
            // 
            this.pic1AA.Location = new System.Drawing.Point(494, 210);
            this.pic1AA.Name = "pic1AA";
            this.pic1AA.Size = new System.Drawing.Size(20, 22);
            this.pic1AA.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1AA.TabIndex = 754;
            this.pic1AA.TabStop = false;
            // 
            // pic1BA
            // 
            this.pic1BA.Location = new System.Drawing.Point(513, 210);
            this.pic1BA.Name = "pic1BA";
            this.pic1BA.Size = new System.Drawing.Size(20, 22);
            this.pic1BA.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1BA.TabIndex = 755;
            this.pic1BA.TabStop = false;
            // 
            // pic00B
            // 
            this.pic00B.Location = new System.Drawing.Point(0, 231);
            this.pic00B.Name = "pic00B";
            this.pic00B.Size = new System.Drawing.Size(20, 22);
            this.pic00B.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic00B.TabIndex = 756;
            this.pic00B.TabStop = false;
            // 
            // pic01B
            // 
            this.pic01B.Location = new System.Drawing.Point(19, 231);
            this.pic01B.Name = "pic01B";
            this.pic01B.Size = new System.Drawing.Size(20, 22);
            this.pic01B.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic01B.TabIndex = 757;
            this.pic01B.TabStop = false;
            // 
            // pic02B
            // 
            this.pic02B.Location = new System.Drawing.Point(38, 231);
            this.pic02B.Name = "pic02B";
            this.pic02B.Size = new System.Drawing.Size(20, 22);
            this.pic02B.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic02B.TabIndex = 758;
            this.pic02B.TabStop = false;
            // 
            // pic03B
            // 
            this.pic03B.Location = new System.Drawing.Point(57, 231);
            this.pic03B.Name = "pic03B";
            this.pic03B.Size = new System.Drawing.Size(20, 22);
            this.pic03B.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic03B.TabIndex = 759;
            this.pic03B.TabStop = false;
            // 
            // pic04B
            // 
            this.pic04B.Location = new System.Drawing.Point(76, 231);
            this.pic04B.Name = "pic04B";
            this.pic04B.Size = new System.Drawing.Size(20, 22);
            this.pic04B.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic04B.TabIndex = 760;
            this.pic04B.TabStop = false;
            // 
            // pic05B
            // 
            this.pic05B.Location = new System.Drawing.Point(95, 231);
            this.pic05B.Name = "pic05B";
            this.pic05B.Size = new System.Drawing.Size(20, 22);
            this.pic05B.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic05B.TabIndex = 761;
            this.pic05B.TabStop = false;
            // 
            // pic06B
            // 
            this.pic06B.Location = new System.Drawing.Point(114, 231);
            this.pic06B.Name = "pic06B";
            this.pic06B.Size = new System.Drawing.Size(20, 22);
            this.pic06B.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic06B.TabIndex = 762;
            this.pic06B.TabStop = false;
            // 
            // pic07B
            // 
            this.pic07B.Location = new System.Drawing.Point(133, 231);
            this.pic07B.Name = "pic07B";
            this.pic07B.Size = new System.Drawing.Size(20, 22);
            this.pic07B.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic07B.TabIndex = 763;
            this.pic07B.TabStop = false;
            // 
            // pic08B
            // 
            this.pic08B.Location = new System.Drawing.Point(152, 231);
            this.pic08B.Name = "pic08B";
            this.pic08B.Size = new System.Drawing.Size(20, 22);
            this.pic08B.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic08B.TabIndex = 764;
            this.pic08B.TabStop = false;
            // 
            // pic09B
            // 
            this.pic09B.Location = new System.Drawing.Point(171, 231);
            this.pic09B.Name = "pic09B";
            this.pic09B.Size = new System.Drawing.Size(20, 22);
            this.pic09B.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic09B.TabIndex = 765;
            this.pic09B.TabStop = false;
            // 
            // pic0AB
            // 
            this.pic0AB.Location = new System.Drawing.Point(190, 231);
            this.pic0AB.Name = "pic0AB";
            this.pic0AB.Size = new System.Drawing.Size(20, 22);
            this.pic0AB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0AB.TabIndex = 766;
            this.pic0AB.TabStop = false;
            // 
            // pic0BB
            // 
            this.pic0BB.Location = new System.Drawing.Point(209, 231);
            this.pic0BB.Name = "pic0BB";
            this.pic0BB.Size = new System.Drawing.Size(20, 22);
            this.pic0BB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0BB.TabIndex = 767;
            this.pic0BB.TabStop = false;
            // 
            // pic0CB
            // 
            this.pic0CB.Location = new System.Drawing.Point(228, 231);
            this.pic0CB.Name = "pic0CB";
            this.pic0CB.Size = new System.Drawing.Size(20, 22);
            this.pic0CB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0CB.TabIndex = 768;
            this.pic0CB.TabStop = false;
            // 
            // pic0DB
            // 
            this.pic0DB.Location = new System.Drawing.Point(247, 231);
            this.pic0DB.Name = "pic0DB";
            this.pic0DB.Size = new System.Drawing.Size(20, 22);
            this.pic0DB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0DB.TabIndex = 769;
            this.pic0DB.TabStop = false;
            // 
            // pic0EB
            // 
            this.pic0EB.Location = new System.Drawing.Point(266, 231);
            this.pic0EB.Name = "pic0EB";
            this.pic0EB.Size = new System.Drawing.Size(20, 22);
            this.pic0EB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0EB.TabIndex = 770;
            this.pic0EB.TabStop = false;
            // 
            // pic0FB
            // 
            this.pic0FB.Location = new System.Drawing.Point(285, 231);
            this.pic0FB.Name = "pic0FB";
            this.pic0FB.Size = new System.Drawing.Size(20, 22);
            this.pic0FB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0FB.TabIndex = 771;
            this.pic0FB.TabStop = false;
            // 
            // pic10B
            // 
            this.pic10B.Location = new System.Drawing.Point(304, 231);
            this.pic10B.Name = "pic10B";
            this.pic10B.Size = new System.Drawing.Size(20, 22);
            this.pic10B.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic10B.TabIndex = 772;
            this.pic10B.TabStop = false;
            // 
            // pic11B
            // 
            this.pic11B.Location = new System.Drawing.Point(323, 231);
            this.pic11B.Name = "pic11B";
            this.pic11B.Size = new System.Drawing.Size(20, 22);
            this.pic11B.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic11B.TabIndex = 773;
            this.pic11B.TabStop = false;
            // 
            // pic12B
            // 
            this.pic12B.Location = new System.Drawing.Point(342, 231);
            this.pic12B.Name = "pic12B";
            this.pic12B.Size = new System.Drawing.Size(20, 22);
            this.pic12B.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic12B.TabIndex = 774;
            this.pic12B.TabStop = false;
            // 
            // pic13B
            // 
            this.pic13B.Location = new System.Drawing.Point(361, 231);
            this.pic13B.Name = "pic13B";
            this.pic13B.Size = new System.Drawing.Size(20, 22);
            this.pic13B.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic13B.TabIndex = 775;
            this.pic13B.TabStop = false;
            // 
            // pic14B
            // 
            this.pic14B.Location = new System.Drawing.Point(380, 231);
            this.pic14B.Name = "pic14B";
            this.pic14B.Size = new System.Drawing.Size(20, 22);
            this.pic14B.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic14B.TabIndex = 776;
            this.pic14B.TabStop = false;
            // 
            // pic15B
            // 
            this.pic15B.Location = new System.Drawing.Point(399, 231);
            this.pic15B.Name = "pic15B";
            this.pic15B.Size = new System.Drawing.Size(20, 22);
            this.pic15B.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic15B.TabIndex = 777;
            this.pic15B.TabStop = false;
            // 
            // pic16B
            // 
            this.pic16B.Location = new System.Drawing.Point(418, 231);
            this.pic16B.Name = "pic16B";
            this.pic16B.Size = new System.Drawing.Size(20, 22);
            this.pic16B.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic16B.TabIndex = 778;
            this.pic16B.TabStop = false;
            // 
            // pic17B
            // 
            this.pic17B.Location = new System.Drawing.Point(437, 231);
            this.pic17B.Name = "pic17B";
            this.pic17B.Size = new System.Drawing.Size(20, 22);
            this.pic17B.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic17B.TabIndex = 779;
            this.pic17B.TabStop = false;
            // 
            // pic18B
            // 
            this.pic18B.Location = new System.Drawing.Point(456, 231);
            this.pic18B.Name = "pic18B";
            this.pic18B.Size = new System.Drawing.Size(20, 22);
            this.pic18B.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic18B.TabIndex = 780;
            this.pic18B.TabStop = false;
            // 
            // pic19B
            // 
            this.pic19B.Location = new System.Drawing.Point(475, 231);
            this.pic19B.Name = "pic19B";
            this.pic19B.Size = new System.Drawing.Size(20, 22);
            this.pic19B.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic19B.TabIndex = 781;
            this.pic19B.TabStop = false;
            // 
            // pic1AB
            // 
            this.pic1AB.Location = new System.Drawing.Point(494, 231);
            this.pic1AB.Name = "pic1AB";
            this.pic1AB.Size = new System.Drawing.Size(20, 22);
            this.pic1AB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1AB.TabIndex = 782;
            this.pic1AB.TabStop = false;
            // 
            // pic1BB
            // 
            this.pic1BB.Location = new System.Drawing.Point(513, 231);
            this.pic1BB.Name = "pic1BB";
            this.pic1BB.Size = new System.Drawing.Size(20, 22);
            this.pic1BB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1BB.TabIndex = 783;
            this.pic1BB.TabStop = false;
            // 
            // pic00C
            // 
            this.pic00C.Location = new System.Drawing.Point(0, 252);
            this.pic00C.Name = "pic00C";
            this.pic00C.Size = new System.Drawing.Size(20, 22);
            this.pic00C.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic00C.TabIndex = 784;
            this.pic00C.TabStop = false;
            // 
            // pic01C
            // 
            this.pic01C.Location = new System.Drawing.Point(19, 252);
            this.pic01C.Name = "pic01C";
            this.pic01C.Size = new System.Drawing.Size(20, 22);
            this.pic01C.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic01C.TabIndex = 785;
            this.pic01C.TabStop = false;
            // 
            // pic02C
            // 
            this.pic02C.Location = new System.Drawing.Point(38, 252);
            this.pic02C.Name = "pic02C";
            this.pic02C.Size = new System.Drawing.Size(20, 22);
            this.pic02C.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic02C.TabIndex = 786;
            this.pic02C.TabStop = false;
            // 
            // pic03C
            // 
            this.pic03C.Location = new System.Drawing.Point(57, 252);
            this.pic03C.Name = "pic03C";
            this.pic03C.Size = new System.Drawing.Size(20, 22);
            this.pic03C.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic03C.TabIndex = 787;
            this.pic03C.TabStop = false;
            // 
            // pic04C
            // 
            this.pic04C.Location = new System.Drawing.Point(76, 252);
            this.pic04C.Name = "pic04C";
            this.pic04C.Size = new System.Drawing.Size(20, 22);
            this.pic04C.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic04C.TabIndex = 788;
            this.pic04C.TabStop = false;
            // 
            // pic05C
            // 
            this.pic05C.Location = new System.Drawing.Point(95, 252);
            this.pic05C.Name = "pic05C";
            this.pic05C.Size = new System.Drawing.Size(20, 22);
            this.pic05C.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic05C.TabIndex = 789;
            this.pic05C.TabStop = false;
            // 
            // pic06C
            // 
            this.pic06C.Location = new System.Drawing.Point(114, 252);
            this.pic06C.Name = "pic06C";
            this.pic06C.Size = new System.Drawing.Size(20, 22);
            this.pic06C.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic06C.TabIndex = 790;
            this.pic06C.TabStop = false;
            // 
            // pic07C
            // 
            this.pic07C.Location = new System.Drawing.Point(133, 252);
            this.pic07C.Name = "pic07C";
            this.pic07C.Size = new System.Drawing.Size(20, 22);
            this.pic07C.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic07C.TabIndex = 791;
            this.pic07C.TabStop = false;
            // 
            // pic08C
            // 
            this.pic08C.Location = new System.Drawing.Point(152, 252);
            this.pic08C.Name = "pic08C";
            this.pic08C.Size = new System.Drawing.Size(20, 22);
            this.pic08C.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic08C.TabIndex = 792;
            this.pic08C.TabStop = false;
            // 
            // pic09C
            // 
            this.pic09C.Location = new System.Drawing.Point(171, 252);
            this.pic09C.Name = "pic09C";
            this.pic09C.Size = new System.Drawing.Size(20, 22);
            this.pic09C.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic09C.TabIndex = 793;
            this.pic09C.TabStop = false;
            // 
            // pic0AC
            // 
            this.pic0AC.Location = new System.Drawing.Point(190, 252);
            this.pic0AC.Name = "pic0AC";
            this.pic0AC.Size = new System.Drawing.Size(20, 22);
            this.pic0AC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0AC.TabIndex = 794;
            this.pic0AC.TabStop = false;
            // 
            // pic0BC
            // 
            this.pic0BC.Location = new System.Drawing.Point(209, 252);
            this.pic0BC.Name = "pic0BC";
            this.pic0BC.Size = new System.Drawing.Size(20, 22);
            this.pic0BC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0BC.TabIndex = 795;
            this.pic0BC.TabStop = false;
            // 
            // pic0CC
            // 
            this.pic0CC.Location = new System.Drawing.Point(228, 252);
            this.pic0CC.Name = "pic0CC";
            this.pic0CC.Size = new System.Drawing.Size(20, 22);
            this.pic0CC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0CC.TabIndex = 796;
            this.pic0CC.TabStop = false;
            // 
            // pic0DC
            // 
            this.pic0DC.Location = new System.Drawing.Point(247, 252);
            this.pic0DC.Name = "pic0DC";
            this.pic0DC.Size = new System.Drawing.Size(20, 22);
            this.pic0DC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0DC.TabIndex = 797;
            this.pic0DC.TabStop = false;
            // 
            // pic0EC
            // 
            this.pic0EC.Location = new System.Drawing.Point(266, 252);
            this.pic0EC.Name = "pic0EC";
            this.pic0EC.Size = new System.Drawing.Size(20, 22);
            this.pic0EC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0EC.TabIndex = 798;
            this.pic0EC.TabStop = false;
            // 
            // pic0FC
            // 
            this.pic0FC.Location = new System.Drawing.Point(285, 252);
            this.pic0FC.Name = "pic0FC";
            this.pic0FC.Size = new System.Drawing.Size(20, 22);
            this.pic0FC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0FC.TabIndex = 799;
            this.pic0FC.TabStop = false;
            // 
            // pic10C
            // 
            this.pic10C.Location = new System.Drawing.Point(304, 252);
            this.pic10C.Name = "pic10C";
            this.pic10C.Size = new System.Drawing.Size(20, 22);
            this.pic10C.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic10C.TabIndex = 800;
            this.pic10C.TabStop = false;
            // 
            // pic11C
            // 
            this.pic11C.Location = new System.Drawing.Point(323, 252);
            this.pic11C.Name = "pic11C";
            this.pic11C.Size = new System.Drawing.Size(20, 22);
            this.pic11C.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic11C.TabIndex = 801;
            this.pic11C.TabStop = false;
            // 
            // pic12C
            // 
            this.pic12C.Location = new System.Drawing.Point(342, 252);
            this.pic12C.Name = "pic12C";
            this.pic12C.Size = new System.Drawing.Size(20, 22);
            this.pic12C.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic12C.TabIndex = 802;
            this.pic12C.TabStop = false;
            // 
            // pic13C
            // 
            this.pic13C.Location = new System.Drawing.Point(361, 252);
            this.pic13C.Name = "pic13C";
            this.pic13C.Size = new System.Drawing.Size(20, 22);
            this.pic13C.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic13C.TabIndex = 803;
            this.pic13C.TabStop = false;
            // 
            // pic14C
            // 
            this.pic14C.Location = new System.Drawing.Point(380, 252);
            this.pic14C.Name = "pic14C";
            this.pic14C.Size = new System.Drawing.Size(20, 22);
            this.pic14C.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic14C.TabIndex = 804;
            this.pic14C.TabStop = false;
            // 
            // pic15C
            // 
            this.pic15C.Location = new System.Drawing.Point(399, 252);
            this.pic15C.Name = "pic15C";
            this.pic15C.Size = new System.Drawing.Size(20, 22);
            this.pic15C.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic15C.TabIndex = 805;
            this.pic15C.TabStop = false;
            // 
            // pic16C
            // 
            this.pic16C.Location = new System.Drawing.Point(418, 252);
            this.pic16C.Name = "pic16C";
            this.pic16C.Size = new System.Drawing.Size(20, 22);
            this.pic16C.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic16C.TabIndex = 806;
            this.pic16C.TabStop = false;
            // 
            // pic17C
            // 
            this.pic17C.Location = new System.Drawing.Point(437, 252);
            this.pic17C.Name = "pic17C";
            this.pic17C.Size = new System.Drawing.Size(20, 22);
            this.pic17C.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic17C.TabIndex = 807;
            this.pic17C.TabStop = false;
            // 
            // pic18C
            // 
            this.pic18C.Location = new System.Drawing.Point(456, 252);
            this.pic18C.Name = "pic18C";
            this.pic18C.Size = new System.Drawing.Size(20, 22);
            this.pic18C.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic18C.TabIndex = 808;
            this.pic18C.TabStop = false;
            // 
            // pic19C
            // 
            this.pic19C.Location = new System.Drawing.Point(475, 252);
            this.pic19C.Name = "pic19C";
            this.pic19C.Size = new System.Drawing.Size(20, 22);
            this.pic19C.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic19C.TabIndex = 809;
            this.pic19C.TabStop = false;
            // 
            // pic1AC
            // 
            this.pic1AC.Location = new System.Drawing.Point(494, 252);
            this.pic1AC.Name = "pic1AC";
            this.pic1AC.Size = new System.Drawing.Size(20, 22);
            this.pic1AC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1AC.TabIndex = 810;
            this.pic1AC.TabStop = false;
            // 
            // pic1BC
            // 
            this.pic1BC.Location = new System.Drawing.Point(513, 252);
            this.pic1BC.Name = "pic1BC";
            this.pic1BC.Size = new System.Drawing.Size(20, 22);
            this.pic1BC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1BC.TabIndex = 811;
            this.pic1BC.TabStop = false;
            // 
            // pic00D
            // 
            this.pic00D.Location = new System.Drawing.Point(0, 273);
            this.pic00D.Name = "pic00D";
            this.pic00D.Size = new System.Drawing.Size(20, 22);
            this.pic00D.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic00D.TabIndex = 812;
            this.pic00D.TabStop = false;
            // 
            // pic01D
            // 
            this.pic01D.Location = new System.Drawing.Point(19, 273);
            this.pic01D.Name = "pic01D";
            this.pic01D.Size = new System.Drawing.Size(20, 22);
            this.pic01D.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic01D.TabIndex = 813;
            this.pic01D.TabStop = false;
            // 
            // pic02D
            // 
            this.pic02D.Location = new System.Drawing.Point(38, 273);
            this.pic02D.Name = "pic02D";
            this.pic02D.Size = new System.Drawing.Size(20, 22);
            this.pic02D.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic02D.TabIndex = 814;
            this.pic02D.TabStop = false;
            // 
            // pic03D
            // 
            this.pic03D.Location = new System.Drawing.Point(57, 273);
            this.pic03D.Name = "pic03D";
            this.pic03D.Size = new System.Drawing.Size(20, 22);
            this.pic03D.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic03D.TabIndex = 815;
            this.pic03D.TabStop = false;
            // 
            // pic04D
            // 
            this.pic04D.Location = new System.Drawing.Point(76, 273);
            this.pic04D.Name = "pic04D";
            this.pic04D.Size = new System.Drawing.Size(20, 22);
            this.pic04D.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic04D.TabIndex = 816;
            this.pic04D.TabStop = false;
            // 
            // pic05D
            // 
            this.pic05D.Location = new System.Drawing.Point(95, 273);
            this.pic05D.Name = "pic05D";
            this.pic05D.Size = new System.Drawing.Size(20, 22);
            this.pic05D.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic05D.TabIndex = 817;
            this.pic05D.TabStop = false;
            // 
            // pic06D
            // 
            this.pic06D.Location = new System.Drawing.Point(114, 273);
            this.pic06D.Name = "pic06D";
            this.pic06D.Size = new System.Drawing.Size(20, 22);
            this.pic06D.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic06D.TabIndex = 818;
            this.pic06D.TabStop = false;
            // 
            // pic07D
            // 
            this.pic07D.Location = new System.Drawing.Point(133, 273);
            this.pic07D.Name = "pic07D";
            this.pic07D.Size = new System.Drawing.Size(20, 22);
            this.pic07D.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic07D.TabIndex = 819;
            this.pic07D.TabStop = false;
            // 
            // pic08D
            // 
            this.pic08D.Location = new System.Drawing.Point(152, 273);
            this.pic08D.Name = "pic08D";
            this.pic08D.Size = new System.Drawing.Size(20, 22);
            this.pic08D.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic08D.TabIndex = 820;
            this.pic08D.TabStop = false;
            // 
            // pic09D
            // 
            this.pic09D.Location = new System.Drawing.Point(171, 273);
            this.pic09D.Name = "pic09D";
            this.pic09D.Size = new System.Drawing.Size(20, 22);
            this.pic09D.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic09D.TabIndex = 821;
            this.pic09D.TabStop = false;
            // 
            // pic0AD
            // 
            this.pic0AD.Location = new System.Drawing.Point(190, 273);
            this.pic0AD.Name = "pic0AD";
            this.pic0AD.Size = new System.Drawing.Size(20, 22);
            this.pic0AD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0AD.TabIndex = 822;
            this.pic0AD.TabStop = false;
            // 
            // pic0BD
            // 
            this.pic0BD.Location = new System.Drawing.Point(209, 273);
            this.pic0BD.Name = "pic0BD";
            this.pic0BD.Size = new System.Drawing.Size(20, 22);
            this.pic0BD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0BD.TabIndex = 823;
            this.pic0BD.TabStop = false;
            // 
            // pic0CD
            // 
            this.pic0CD.Location = new System.Drawing.Point(228, 273);
            this.pic0CD.Name = "pic0CD";
            this.pic0CD.Size = new System.Drawing.Size(20, 22);
            this.pic0CD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0CD.TabIndex = 824;
            this.pic0CD.TabStop = false;
            // 
            // pic0DD
            // 
            this.pic0DD.Location = new System.Drawing.Point(247, 273);
            this.pic0DD.Name = "pic0DD";
            this.pic0DD.Size = new System.Drawing.Size(20, 22);
            this.pic0DD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0DD.TabIndex = 825;
            this.pic0DD.TabStop = false;
            // 
            // pic0ED
            // 
            this.pic0ED.Location = new System.Drawing.Point(266, 273);
            this.pic0ED.Name = "pic0ED";
            this.pic0ED.Size = new System.Drawing.Size(20, 22);
            this.pic0ED.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0ED.TabIndex = 826;
            this.pic0ED.TabStop = false;
            // 
            // pic0FD
            // 
            this.pic0FD.Location = new System.Drawing.Point(285, 273);
            this.pic0FD.Name = "pic0FD";
            this.pic0FD.Size = new System.Drawing.Size(20, 22);
            this.pic0FD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0FD.TabIndex = 827;
            this.pic0FD.TabStop = false;
            // 
            // pic10D
            // 
            this.pic10D.Location = new System.Drawing.Point(304, 273);
            this.pic10D.Name = "pic10D";
            this.pic10D.Size = new System.Drawing.Size(20, 22);
            this.pic10D.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic10D.TabIndex = 828;
            this.pic10D.TabStop = false;
            // 
            // pic11D
            // 
            this.pic11D.Location = new System.Drawing.Point(323, 273);
            this.pic11D.Name = "pic11D";
            this.pic11D.Size = new System.Drawing.Size(20, 22);
            this.pic11D.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic11D.TabIndex = 829;
            this.pic11D.TabStop = false;
            // 
            // pic12D
            // 
            this.pic12D.Location = new System.Drawing.Point(342, 273);
            this.pic12D.Name = "pic12D";
            this.pic12D.Size = new System.Drawing.Size(20, 22);
            this.pic12D.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic12D.TabIndex = 830;
            this.pic12D.TabStop = false;
            // 
            // pic13D
            // 
            this.pic13D.Location = new System.Drawing.Point(361, 273);
            this.pic13D.Name = "pic13D";
            this.pic13D.Size = new System.Drawing.Size(20, 22);
            this.pic13D.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic13D.TabIndex = 831;
            this.pic13D.TabStop = false;
            // 
            // pic14D
            // 
            this.pic14D.Location = new System.Drawing.Point(380, 273);
            this.pic14D.Name = "pic14D";
            this.pic14D.Size = new System.Drawing.Size(20, 22);
            this.pic14D.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic14D.TabIndex = 832;
            this.pic14D.TabStop = false;
            // 
            // pic15D
            // 
            this.pic15D.Location = new System.Drawing.Point(399, 273);
            this.pic15D.Name = "pic15D";
            this.pic15D.Size = new System.Drawing.Size(20, 22);
            this.pic15D.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic15D.TabIndex = 833;
            this.pic15D.TabStop = false;
            // 
            // pic16D
            // 
            this.pic16D.Location = new System.Drawing.Point(418, 273);
            this.pic16D.Name = "pic16D";
            this.pic16D.Size = new System.Drawing.Size(20, 22);
            this.pic16D.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic16D.TabIndex = 834;
            this.pic16D.TabStop = false;
            // 
            // pic17D
            // 
            this.pic17D.Location = new System.Drawing.Point(437, 273);
            this.pic17D.Name = "pic17D";
            this.pic17D.Size = new System.Drawing.Size(20, 22);
            this.pic17D.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic17D.TabIndex = 835;
            this.pic17D.TabStop = false;
            // 
            // pic18D
            // 
            this.pic18D.Location = new System.Drawing.Point(456, 273);
            this.pic18D.Name = "pic18D";
            this.pic18D.Size = new System.Drawing.Size(20, 22);
            this.pic18D.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic18D.TabIndex = 836;
            this.pic18D.TabStop = false;
            // 
            // pic19D
            // 
            this.pic19D.Location = new System.Drawing.Point(475, 273);
            this.pic19D.Name = "pic19D";
            this.pic19D.Size = new System.Drawing.Size(20, 22);
            this.pic19D.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic19D.TabIndex = 837;
            this.pic19D.TabStop = false;
            // 
            // pic1AD
            // 
            this.pic1AD.Location = new System.Drawing.Point(494, 273);
            this.pic1AD.Name = "pic1AD";
            this.pic1AD.Size = new System.Drawing.Size(20, 22);
            this.pic1AD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1AD.TabIndex = 838;
            this.pic1AD.TabStop = false;
            // 
            // pic1BD
            // 
            this.pic1BD.Location = new System.Drawing.Point(513, 273);
            this.pic1BD.Name = "pic1BD";
            this.pic1BD.Size = new System.Drawing.Size(20, 22);
            this.pic1BD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1BD.TabIndex = 839;
            this.pic1BD.TabStop = false;
            // 
            // pic00E
            // 
            this.pic00E.Location = new System.Drawing.Point(0, 294);
            this.pic00E.Name = "pic00E";
            this.pic00E.Size = new System.Drawing.Size(20, 22);
            this.pic00E.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic00E.TabIndex = 840;
            this.pic00E.TabStop = false;
            // 
            // pic01E
            // 
            this.pic01E.Location = new System.Drawing.Point(19, 294);
            this.pic01E.Name = "pic01E";
            this.pic01E.Size = new System.Drawing.Size(20, 22);
            this.pic01E.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic01E.TabIndex = 841;
            this.pic01E.TabStop = false;
            // 
            // pic02E
            // 
            this.pic02E.Location = new System.Drawing.Point(38, 294);
            this.pic02E.Name = "pic02E";
            this.pic02E.Size = new System.Drawing.Size(20, 22);
            this.pic02E.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic02E.TabIndex = 842;
            this.pic02E.TabStop = false;
            // 
            // pic03E
            // 
            this.pic03E.Location = new System.Drawing.Point(57, 294);
            this.pic03E.Name = "pic03E";
            this.pic03E.Size = new System.Drawing.Size(20, 22);
            this.pic03E.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic03E.TabIndex = 843;
            this.pic03E.TabStop = false;
            // 
            // pic04E
            // 
            this.pic04E.Location = new System.Drawing.Point(76, 294);
            this.pic04E.Name = "pic04E";
            this.pic04E.Size = new System.Drawing.Size(20, 22);
            this.pic04E.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic04E.TabIndex = 844;
            this.pic04E.TabStop = false;
            // 
            // pic05E
            // 
            this.pic05E.Location = new System.Drawing.Point(95, 294);
            this.pic05E.Name = "pic05E";
            this.pic05E.Size = new System.Drawing.Size(20, 22);
            this.pic05E.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic05E.TabIndex = 845;
            this.pic05E.TabStop = false;
            // 
            // pic06E
            // 
            this.pic06E.Location = new System.Drawing.Point(114, 294);
            this.pic06E.Name = "pic06E";
            this.pic06E.Size = new System.Drawing.Size(20, 22);
            this.pic06E.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic06E.TabIndex = 846;
            this.pic06E.TabStop = false;
            // 
            // pic07E
            // 
            this.pic07E.Location = new System.Drawing.Point(133, 294);
            this.pic07E.Name = "pic07E";
            this.pic07E.Size = new System.Drawing.Size(20, 22);
            this.pic07E.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic07E.TabIndex = 847;
            this.pic07E.TabStop = false;
            // 
            // pic08E
            // 
            this.pic08E.Location = new System.Drawing.Point(152, 294);
            this.pic08E.Name = "pic08E";
            this.pic08E.Size = new System.Drawing.Size(20, 22);
            this.pic08E.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic08E.TabIndex = 848;
            this.pic08E.TabStop = false;
            // 
            // pic09E
            // 
            this.pic09E.Location = new System.Drawing.Point(171, 294);
            this.pic09E.Name = "pic09E";
            this.pic09E.Size = new System.Drawing.Size(20, 22);
            this.pic09E.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic09E.TabIndex = 849;
            this.pic09E.TabStop = false;
            // 
            // pic0AE
            // 
            this.pic0AE.Location = new System.Drawing.Point(190, 294);
            this.pic0AE.Name = "pic0AE";
            this.pic0AE.Size = new System.Drawing.Size(20, 22);
            this.pic0AE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0AE.TabIndex = 850;
            this.pic0AE.TabStop = false;
            // 
            // pic0BE
            // 
            this.pic0BE.Location = new System.Drawing.Point(209, 294);
            this.pic0BE.Name = "pic0BE";
            this.pic0BE.Size = new System.Drawing.Size(20, 22);
            this.pic0BE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0BE.TabIndex = 851;
            this.pic0BE.TabStop = false;
            // 
            // pic0CE
            // 
            this.pic0CE.Location = new System.Drawing.Point(228, 294);
            this.pic0CE.Name = "pic0CE";
            this.pic0CE.Size = new System.Drawing.Size(20, 22);
            this.pic0CE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0CE.TabIndex = 852;
            this.pic0CE.TabStop = false;
            // 
            // pic0DE
            // 
            this.pic0DE.Location = new System.Drawing.Point(247, 294);
            this.pic0DE.Name = "pic0DE";
            this.pic0DE.Size = new System.Drawing.Size(20, 22);
            this.pic0DE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0DE.TabIndex = 853;
            this.pic0DE.TabStop = false;
            // 
            // pic0EE
            // 
            this.pic0EE.Location = new System.Drawing.Point(266, 294);
            this.pic0EE.Name = "pic0EE";
            this.pic0EE.Size = new System.Drawing.Size(20, 22);
            this.pic0EE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0EE.TabIndex = 854;
            this.pic0EE.TabStop = false;
            // 
            // pic0FE
            // 
            this.pic0FE.Location = new System.Drawing.Point(285, 294);
            this.pic0FE.Name = "pic0FE";
            this.pic0FE.Size = new System.Drawing.Size(20, 22);
            this.pic0FE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0FE.TabIndex = 855;
            this.pic0FE.TabStop = false;
            // 
            // pic10E
            // 
            this.pic10E.Location = new System.Drawing.Point(304, 294);
            this.pic10E.Name = "pic10E";
            this.pic10E.Size = new System.Drawing.Size(20, 22);
            this.pic10E.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic10E.TabIndex = 856;
            this.pic10E.TabStop = false;
            // 
            // pic11E
            // 
            this.pic11E.Location = new System.Drawing.Point(323, 294);
            this.pic11E.Name = "pic11E";
            this.pic11E.Size = new System.Drawing.Size(20, 22);
            this.pic11E.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic11E.TabIndex = 857;
            this.pic11E.TabStop = false;
            // 
            // pic12E
            // 
            this.pic12E.Location = new System.Drawing.Point(342, 294);
            this.pic12E.Name = "pic12E";
            this.pic12E.Size = new System.Drawing.Size(20, 22);
            this.pic12E.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic12E.TabIndex = 858;
            this.pic12E.TabStop = false;
            // 
            // pic13E
            // 
            this.pic13E.Location = new System.Drawing.Point(361, 294);
            this.pic13E.Name = "pic13E";
            this.pic13E.Size = new System.Drawing.Size(20, 22);
            this.pic13E.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic13E.TabIndex = 859;
            this.pic13E.TabStop = false;
            // 
            // pic14E
            // 
            this.pic14E.Location = new System.Drawing.Point(380, 294);
            this.pic14E.Name = "pic14E";
            this.pic14E.Size = new System.Drawing.Size(20, 22);
            this.pic14E.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic14E.TabIndex = 860;
            this.pic14E.TabStop = false;
            // 
            // pic15E
            // 
            this.pic15E.Location = new System.Drawing.Point(399, 294);
            this.pic15E.Name = "pic15E";
            this.pic15E.Size = new System.Drawing.Size(20, 22);
            this.pic15E.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic15E.TabIndex = 861;
            this.pic15E.TabStop = false;
            // 
            // pic16E
            // 
            this.pic16E.Location = new System.Drawing.Point(418, 294);
            this.pic16E.Name = "pic16E";
            this.pic16E.Size = new System.Drawing.Size(20, 22);
            this.pic16E.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic16E.TabIndex = 862;
            this.pic16E.TabStop = false;
            // 
            // pic17E
            // 
            this.pic17E.Location = new System.Drawing.Point(437, 294);
            this.pic17E.Name = "pic17E";
            this.pic17E.Size = new System.Drawing.Size(20, 22);
            this.pic17E.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic17E.TabIndex = 863;
            this.pic17E.TabStop = false;
            // 
            // pic18E
            // 
            this.pic18E.Location = new System.Drawing.Point(456, 294);
            this.pic18E.Name = "pic18E";
            this.pic18E.Size = new System.Drawing.Size(20, 22);
            this.pic18E.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic18E.TabIndex = 864;
            this.pic18E.TabStop = false;
            // 
            // pic19E
            // 
            this.pic19E.Location = new System.Drawing.Point(475, 294);
            this.pic19E.Name = "pic19E";
            this.pic19E.Size = new System.Drawing.Size(20, 22);
            this.pic19E.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic19E.TabIndex = 865;
            this.pic19E.TabStop = false;
            // 
            // pic1AE
            // 
            this.pic1AE.Location = new System.Drawing.Point(494, 294);
            this.pic1AE.Name = "pic1AE";
            this.pic1AE.Size = new System.Drawing.Size(20, 22);
            this.pic1AE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1AE.TabIndex = 866;
            this.pic1AE.TabStop = false;
            // 
            // pic1BE
            // 
            this.pic1BE.Location = new System.Drawing.Point(513, 294);
            this.pic1BE.Name = "pic1BE";
            this.pic1BE.Size = new System.Drawing.Size(20, 22);
            this.pic1BE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1BE.TabIndex = 867;
            this.pic1BE.TabStop = false;
            // 
            // pic00F
            // 
            this.pic00F.Location = new System.Drawing.Point(0, 315);
            this.pic00F.Name = "pic00F";
            this.pic00F.Size = new System.Drawing.Size(20, 22);
            this.pic00F.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pic00F.TabIndex = 868;
            this.pic00F.TabStop = false;
            // 
            // pic01F
            // 
            this.pic01F.Location = new System.Drawing.Point(19, 315);
            this.pic01F.Name = "pic01F";
            this.pic01F.Size = new System.Drawing.Size(20, 22);
            this.pic01F.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pic01F.TabIndex = 869;
            this.pic01F.TabStop = false;
            // 
            // pic02F
            // 
            this.pic02F.Location = new System.Drawing.Point(38, 315);
            this.pic02F.Name = "pic02F";
            this.pic02F.Size = new System.Drawing.Size(20, 22);
            this.pic02F.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic02F.TabIndex = 870;
            this.pic02F.TabStop = false;
            // 
            // pic03F
            // 
            this.pic03F.Location = new System.Drawing.Point(57, 315);
            this.pic03F.Name = "pic03F";
            this.pic03F.Size = new System.Drawing.Size(20, 22);
            this.pic03F.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic03F.TabIndex = 871;
            this.pic03F.TabStop = false;
            // 
            // pic04F
            // 
            this.pic04F.Location = new System.Drawing.Point(76, 315);
            this.pic04F.Name = "pic04F";
            this.pic04F.Size = new System.Drawing.Size(20, 22);
            this.pic04F.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic04F.TabIndex = 872;
            this.pic04F.TabStop = false;
            // 
            // pic05F
            // 
            this.pic05F.Location = new System.Drawing.Point(95, 315);
            this.pic05F.Name = "pic05F";
            this.pic05F.Size = new System.Drawing.Size(20, 22);
            this.pic05F.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic05F.TabIndex = 873;
            this.pic05F.TabStop = false;
            // 
            // pic06F
            // 
            this.pic06F.Location = new System.Drawing.Point(114, 315);
            this.pic06F.Name = "pic06F";
            this.pic06F.Size = new System.Drawing.Size(20, 22);
            this.pic06F.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic06F.TabIndex = 874;
            this.pic06F.TabStop = false;
            // 
            // pic07F
            // 
            this.pic07F.Location = new System.Drawing.Point(133, 315);
            this.pic07F.Name = "pic07F";
            this.pic07F.Size = new System.Drawing.Size(20, 22);
            this.pic07F.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic07F.TabIndex = 875;
            this.pic07F.TabStop = false;
            // 
            // pic08F
            // 
            this.pic08F.Location = new System.Drawing.Point(152, 315);
            this.pic08F.Name = "pic08F";
            this.pic08F.Size = new System.Drawing.Size(20, 22);
            this.pic08F.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic08F.TabIndex = 876;
            this.pic08F.TabStop = false;
            // 
            // pic09F
            // 
            this.pic09F.Location = new System.Drawing.Point(171, 315);
            this.pic09F.Name = "pic09F";
            this.pic09F.Size = new System.Drawing.Size(20, 22);
            this.pic09F.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic09F.TabIndex = 877;
            this.pic09F.TabStop = false;
            // 
            // pic0AF
            // 
            this.pic0AF.Location = new System.Drawing.Point(190, 315);
            this.pic0AF.Name = "pic0AF";
            this.pic0AF.Size = new System.Drawing.Size(20, 22);
            this.pic0AF.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0AF.TabIndex = 878;
            this.pic0AF.TabStop = false;
            // 
            // pic0BF
            // 
            this.pic0BF.Location = new System.Drawing.Point(209, 315);
            this.pic0BF.Name = "pic0BF";
            this.pic0BF.Size = new System.Drawing.Size(20, 22);
            this.pic0BF.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0BF.TabIndex = 879;
            this.pic0BF.TabStop = false;
            // 
            // pic0CF
            // 
            this.pic0CF.Location = new System.Drawing.Point(228, 315);
            this.pic0CF.Name = "pic0CF";
            this.pic0CF.Size = new System.Drawing.Size(20, 22);
            this.pic0CF.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0CF.TabIndex = 880;
            this.pic0CF.TabStop = false;
            // 
            // pic0DF
            // 
            this.pic0DF.Location = new System.Drawing.Point(247, 315);
            this.pic0DF.Name = "pic0DF";
            this.pic0DF.Size = new System.Drawing.Size(20, 22);
            this.pic0DF.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0DF.TabIndex = 881;
            this.pic0DF.TabStop = false;
            // 
            // pic0EF
            // 
            this.pic0EF.Location = new System.Drawing.Point(266, 315);
            this.pic0EF.Name = "pic0EF";
            this.pic0EF.Size = new System.Drawing.Size(20, 22);
            this.pic0EF.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0EF.TabIndex = 882;
            this.pic0EF.TabStop = false;
            // 
            // pic0FF
            // 
            this.pic0FF.Location = new System.Drawing.Point(285, 315);
            this.pic0FF.Name = "pic0FF";
            this.pic0FF.Size = new System.Drawing.Size(20, 22);
            this.pic0FF.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic0FF.TabIndex = 883;
            this.pic0FF.TabStop = false;
            // 
            // pic10F
            // 
            this.pic10F.Location = new System.Drawing.Point(304, 315);
            this.pic10F.Name = "pic10F";
            this.pic10F.Size = new System.Drawing.Size(20, 22);
            this.pic10F.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic10F.TabIndex = 884;
            this.pic10F.TabStop = false;
            // 
            // pic11F
            // 
            this.pic11F.Location = new System.Drawing.Point(323, 315);
            this.pic11F.Name = "pic11F";
            this.pic11F.Size = new System.Drawing.Size(20, 22);
            this.pic11F.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic11F.TabIndex = 885;
            this.pic11F.TabStop = false;
            // 
            // pic12F
            // 
            this.pic12F.Location = new System.Drawing.Point(342, 315);
            this.pic12F.Name = "pic12F";
            this.pic12F.Size = new System.Drawing.Size(20, 22);
            this.pic12F.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic12F.TabIndex = 886;
            this.pic12F.TabStop = false;
            // 
            // pic13F
            // 
            this.pic13F.Location = new System.Drawing.Point(361, 315);
            this.pic13F.Name = "pic13F";
            this.pic13F.Size = new System.Drawing.Size(20, 22);
            this.pic13F.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic13F.TabIndex = 887;
            this.pic13F.TabStop = false;
            // 
            // pic14F
            // 
            this.pic14F.Location = new System.Drawing.Point(380, 315);
            this.pic14F.Name = "pic14F";
            this.pic14F.Size = new System.Drawing.Size(20, 22);
            this.pic14F.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic14F.TabIndex = 888;
            this.pic14F.TabStop = false;
            // 
            // pic15F
            // 
            this.pic15F.Location = new System.Drawing.Point(399, 315);
            this.pic15F.Name = "pic15F";
            this.pic15F.Size = new System.Drawing.Size(20, 22);
            this.pic15F.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic15F.TabIndex = 889;
            this.pic15F.TabStop = false;
            // 
            // pic16F
            // 
            this.pic16F.Location = new System.Drawing.Point(418, 315);
            this.pic16F.Name = "pic16F";
            this.pic16F.Size = new System.Drawing.Size(20, 22);
            this.pic16F.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic16F.TabIndex = 890;
            this.pic16F.TabStop = false;
            // 
            // pic17F
            // 
            this.pic17F.Location = new System.Drawing.Point(437, 315);
            this.pic17F.Name = "pic17F";
            this.pic17F.Size = new System.Drawing.Size(20, 22);
            this.pic17F.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic17F.TabIndex = 891;
            this.pic17F.TabStop = false;
            // 
            // pic18F
            // 
            this.pic18F.Location = new System.Drawing.Point(456, 315);
            this.pic18F.Name = "pic18F";
            this.pic18F.Size = new System.Drawing.Size(20, 22);
            this.pic18F.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic18F.TabIndex = 892;
            this.pic18F.TabStop = false;
            // 
            // pic19F
            // 
            this.pic19F.Location = new System.Drawing.Point(475, 315);
            this.pic19F.Name = "pic19F";
            this.pic19F.Size = new System.Drawing.Size(20, 22);
            this.pic19F.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic19F.TabIndex = 893;
            this.pic19F.TabStop = false;
            // 
            // pic1AF
            // 
            this.pic1AF.Location = new System.Drawing.Point(494, 315);
            this.pic1AF.Name = "pic1AF";
            this.pic1AF.Size = new System.Drawing.Size(20, 22);
            this.pic1AF.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1AF.TabIndex = 894;
            this.pic1AF.TabStop = false;
            // 
            // pic1BF
            // 
            this.pic1BF.Location = new System.Drawing.Point(513, 315);
            this.pic1BF.Name = "pic1BF";
            this.pic1BF.Size = new System.Drawing.Size(20, 22);
            this.pic1BF.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic1BF.TabIndex = 895;
            this.pic1BF.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Yellow;
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Location = new System.Drawing.Point(312, 417);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(24, 26);
            this.panel2.TabIndex = 450;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(2, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(20, 22);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 450;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel3.Controls.Add(this.pictureBox2);
            this.panel3.Location = new System.Drawing.Point(342, 417);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(24, 26);
            this.panel3.TabIndex = 451;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(2, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(20, 22);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 450;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(434, 417);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(20, 22);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 452;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(455, 417);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(20, 22);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 453;
            this.pictureBox4.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel4.BackgroundImage")));
            this.panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel4.Location = new System.Drawing.Point(520, 417);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(20, 22);
            this.panel4.TabIndex = 454;
            // 
            // panel5
            // 
            this.panel5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel5.BackgroundImage")));
            this.panel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel5.Location = new System.Drawing.Point(540, 417);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(20, 22);
            this.panel5.TabIndex = 455;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(690, 498);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseClick);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pic000)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic010)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic020)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic030)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic040)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic050)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic060)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic070)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic080)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic090)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0A0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0B0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0C0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0D0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0E0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0F0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic100)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic110)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic120)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic130)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic140)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic150)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic160)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic170)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic180)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic190)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1A0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1B0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic001)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic011)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic021)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic031)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic041)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic051)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic061)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic071)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic081)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic091)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0A1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0B1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0C1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0D1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0E1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0F1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic101)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic111)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic121)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic131)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic141)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic151)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic161)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic171)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic181)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic191)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1A1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1B1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic002)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic012)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic022)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic032)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic042)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic052)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic062)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic072)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic082)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic092)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0A2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0B2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0C2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0D2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0E2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0F2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic102)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic112)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic122)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic132)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic142)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic152)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic162)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic172)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic182)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic192)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1A2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1B2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic003)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic013)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic023)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic033)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic043)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic053)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic063)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic073)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic083)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic093)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0A3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0B3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0C3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0D3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0E3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0F3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic103)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic113)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic123)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic133)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic143)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic153)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic163)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic173)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic183)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic193)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1A3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1B3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic004)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic014)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic024)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic034)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic044)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic054)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic064)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic074)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic084)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic094)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0A4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0B4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0C4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0D4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0E4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0F4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic104)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic114)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic124)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic134)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic144)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic154)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic164)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic174)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic184)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic194)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1A4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1B4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic005)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic015)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic025)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic035)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic045)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic055)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic065)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic075)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic085)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic095)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0A5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0B5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0C5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0D5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0E5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0F5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic105)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic115)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic125)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic135)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic145)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic155)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic165)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic175)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic185)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic195)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1A5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1B5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic006)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic016)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic026)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic036)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic046)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic056)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic066)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic076)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic086)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic096)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0A6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0B6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0C6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0D6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0E6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0F6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic106)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic116)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic126)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic136)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic146)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic156)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic166)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic176)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic186)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic196)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1A6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1B6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic007)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic017)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic027)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic037)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic047)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic057)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic067)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic077)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic087)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic097)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0A7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0B7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0C7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0D7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0E7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0F7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic107)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic117)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic127)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic137)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic147)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic157)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic167)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic177)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic187)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic197)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1A7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1B7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic008)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic018)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic028)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic038)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic048)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic058)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic068)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic078)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic088)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic098)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0A8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0B8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0C8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0D8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0E8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0F8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic108)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic118)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic128)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic138)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic148)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic158)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic168)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic178)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic188)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic198)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1A8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1B8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic009)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic019)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic029)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic039)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic049)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic059)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic069)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic079)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic089)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic099)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0A9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0B9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0C9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0D9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0E9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0F9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic109)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic119)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic129)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic139)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic149)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic159)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic169)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic179)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic189)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic199)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1A9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1B9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic00A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic01A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic02A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic03A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic04A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic05A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic06A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic07A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic08A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic09A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0AA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0BA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0CA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0DA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0EA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0FA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic10A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic11A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic12A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic13A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic14A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic15A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic16A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic17A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic18A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic19A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1AA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1BA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic00B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic01B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic02B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic03B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic04B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic05B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic06B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic07B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic08B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic09B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0AB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0BB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0CB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0DB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0EB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0FB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic10B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic11B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic12B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic13B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic14B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic15B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic16B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic17B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic18B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic19B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1AB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1BB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic00C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic01C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic02C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic03C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic04C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic05C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic06C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic07C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic08C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic09C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0AC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0BC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0CC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0DC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0EC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0FC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic10C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic11C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic12C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic13C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic14C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic15C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic16C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic17C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic18C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic19C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1AC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1BC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic00D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic01D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic02D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic03D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic04D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic05D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic06D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic07D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic08D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic09D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0AD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0BD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0CD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0DD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0ED)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0FD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic10D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic11D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic12D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic13D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic14D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic15D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic16D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic17D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic18D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic19D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1AD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1BD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic00E)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic01E)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic02E)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic03E)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic04E)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic05E)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic06E)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic07E)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic08E)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic09E)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0AE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0BE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0CE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0DE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0EE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0FE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic10E)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic11E)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic12E)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic13E)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic14E)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic15E)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic16E)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic17E)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic18E)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic19E)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1AE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1BE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic00F)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic01F)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic02F)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic03F)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic04F)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic05F)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic06F)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic07F)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic08F)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic09F)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0AF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0BF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0CF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0DF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0EF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic0FF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic10F)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic11F)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic12F)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic13F)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic14F)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic15F)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic16F)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic17F)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic18F)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic19F)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1AF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1BF)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ImageList imgBlocks;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pic000;
        private System.Windows.Forms.PictureBox pic010;
        private System.Windows.Forms.PictureBox pic020;
        private System.Windows.Forms.PictureBox pic030;
        private System.Windows.Forms.PictureBox pic040;
        private System.Windows.Forms.PictureBox pic050;
        private System.Windows.Forms.PictureBox pic060;
        private System.Windows.Forms.PictureBox pic070;
        private System.Windows.Forms.PictureBox pic080;
        private System.Windows.Forms.PictureBox pic090;
        private System.Windows.Forms.PictureBox pic0A0;
        private System.Windows.Forms.PictureBox pic0B0;
        private System.Windows.Forms.PictureBox pic0C0;
        private System.Windows.Forms.PictureBox pic0D0;
        private System.Windows.Forms.PictureBox pic0E0;
        private System.Windows.Forms.PictureBox pic0F0;
        private System.Windows.Forms.PictureBox pic100;
        private System.Windows.Forms.PictureBox pic110;
        private System.Windows.Forms.PictureBox pic120;
        private System.Windows.Forms.PictureBox pic130;
        private System.Windows.Forms.PictureBox pic140;
        private System.Windows.Forms.PictureBox pic150;
        private System.Windows.Forms.PictureBox pic160;
        private System.Windows.Forms.PictureBox pic170;
        private System.Windows.Forms.PictureBox pic180;
        private System.Windows.Forms.PictureBox pic190;
        private System.Windows.Forms.PictureBox pic1A0;
        private System.Windows.Forms.PictureBox pic1B0;
        private System.Windows.Forms.PictureBox pic001;
        private System.Windows.Forms.PictureBox pic011;
        private System.Windows.Forms.PictureBox pic021;
        private System.Windows.Forms.PictureBox pic031;
        private System.Windows.Forms.PictureBox pic041;
        private System.Windows.Forms.PictureBox pic051;
        private System.Windows.Forms.PictureBox pic061;
        private System.Windows.Forms.PictureBox pic071;
        private System.Windows.Forms.PictureBox pic081;
        private System.Windows.Forms.PictureBox pic091;
        private System.Windows.Forms.PictureBox pic0A1;
        private System.Windows.Forms.PictureBox pic0B1;
        private System.Windows.Forms.PictureBox pic0C1;
        private System.Windows.Forms.PictureBox pic0D1;
        private System.Windows.Forms.PictureBox pic0E1;
        private System.Windows.Forms.PictureBox pic0F1;
        private System.Windows.Forms.PictureBox pic101;
        private System.Windows.Forms.PictureBox pic111;
        private System.Windows.Forms.PictureBox pic121;
        private System.Windows.Forms.PictureBox pic131;
        private System.Windows.Forms.PictureBox pic141;
        private System.Windows.Forms.PictureBox pic151;
        private System.Windows.Forms.PictureBox pic161;
        private System.Windows.Forms.PictureBox pic171;
        private System.Windows.Forms.PictureBox pic181;
        private System.Windows.Forms.PictureBox pic191;
        private System.Windows.Forms.PictureBox pic1A1;
        private System.Windows.Forms.PictureBox pic1B1;
        private System.Windows.Forms.PictureBox pic002;
        private System.Windows.Forms.PictureBox pic012;
        private System.Windows.Forms.PictureBox pic022;
        private System.Windows.Forms.PictureBox pic032;
        private System.Windows.Forms.PictureBox pic042;
        private System.Windows.Forms.PictureBox pic052;
        private System.Windows.Forms.PictureBox pic062;
        private System.Windows.Forms.PictureBox pic072;
        private System.Windows.Forms.PictureBox pic082;
        private System.Windows.Forms.PictureBox pic092;
        private System.Windows.Forms.PictureBox pic0A2;
        private System.Windows.Forms.PictureBox pic0B2;
        private System.Windows.Forms.PictureBox pic0C2;
        private System.Windows.Forms.PictureBox pic0D2;
        private System.Windows.Forms.PictureBox pic0E2;
        private System.Windows.Forms.PictureBox pic0F2;
        private System.Windows.Forms.PictureBox pic102;
        private System.Windows.Forms.PictureBox pic112;
        private System.Windows.Forms.PictureBox pic122;
        private System.Windows.Forms.PictureBox pic132;
        private System.Windows.Forms.PictureBox pic142;
        private System.Windows.Forms.PictureBox pic152;
        private System.Windows.Forms.PictureBox pic162;
        private System.Windows.Forms.PictureBox pic172;
        private System.Windows.Forms.PictureBox pic182;
        private System.Windows.Forms.PictureBox pic192;
        private System.Windows.Forms.PictureBox pic1A2;
        private System.Windows.Forms.PictureBox pic1B2;
        private System.Windows.Forms.PictureBox pic003;
        private System.Windows.Forms.PictureBox pic013;
        private System.Windows.Forms.PictureBox pic023;
        private System.Windows.Forms.PictureBox pic033;
        private System.Windows.Forms.PictureBox pic043;
        private System.Windows.Forms.PictureBox pic053;
        private System.Windows.Forms.PictureBox pic063;
        private System.Windows.Forms.PictureBox pic073;
        private System.Windows.Forms.PictureBox pic083;
        private System.Windows.Forms.PictureBox pic093;
        private System.Windows.Forms.PictureBox pic0A3;
        private System.Windows.Forms.PictureBox pic0B3;
        private System.Windows.Forms.PictureBox pic0C3;
        private System.Windows.Forms.PictureBox pic0D3;
        private System.Windows.Forms.PictureBox pic0E3;
        private System.Windows.Forms.PictureBox pic0F3;
        private System.Windows.Forms.PictureBox pic103;
        private System.Windows.Forms.PictureBox pic113;
        private System.Windows.Forms.PictureBox pic123;
        private System.Windows.Forms.PictureBox pic133;
        private System.Windows.Forms.PictureBox pic143;
        private System.Windows.Forms.PictureBox pic153;
        private System.Windows.Forms.PictureBox pic163;
        private System.Windows.Forms.PictureBox pic173;
        private System.Windows.Forms.PictureBox pic183;
        private System.Windows.Forms.PictureBox pic193;
        private System.Windows.Forms.PictureBox pic1A3;
        private System.Windows.Forms.PictureBox pic1B3;
        private System.Windows.Forms.PictureBox pic004;
        private System.Windows.Forms.PictureBox pic014;
        private System.Windows.Forms.PictureBox pic024;
        private System.Windows.Forms.PictureBox pic034;
        private System.Windows.Forms.PictureBox pic044;
        private System.Windows.Forms.PictureBox pic054;
        private System.Windows.Forms.PictureBox pic064;
        private System.Windows.Forms.PictureBox pic074;
        private System.Windows.Forms.PictureBox pic084;
        private System.Windows.Forms.PictureBox pic094;
        private System.Windows.Forms.PictureBox pic0A4;
        private System.Windows.Forms.PictureBox pic0B4;
        private System.Windows.Forms.PictureBox pic0C4;
        private System.Windows.Forms.PictureBox pic0D4;
        private System.Windows.Forms.PictureBox pic0E4;
        private System.Windows.Forms.PictureBox pic0F4;
        private System.Windows.Forms.PictureBox pic104;
        private System.Windows.Forms.PictureBox pic114;
        private System.Windows.Forms.PictureBox pic124;
        private System.Windows.Forms.PictureBox pic134;
        private System.Windows.Forms.PictureBox pic144;
        private System.Windows.Forms.PictureBox pic154;
        private System.Windows.Forms.PictureBox pic164;
        private System.Windows.Forms.PictureBox pic174;
        private System.Windows.Forms.PictureBox pic184;
        private System.Windows.Forms.PictureBox pic194;
        private System.Windows.Forms.PictureBox pic1A4;
        private System.Windows.Forms.PictureBox pic1B4;
        private System.Windows.Forms.PictureBox pic005;
        private System.Windows.Forms.PictureBox pic015;
        private System.Windows.Forms.PictureBox pic025;
        private System.Windows.Forms.PictureBox pic035;
        private System.Windows.Forms.PictureBox pic045;
        private System.Windows.Forms.PictureBox pic055;
        private System.Windows.Forms.PictureBox pic065;
        private System.Windows.Forms.PictureBox pic075;
        private System.Windows.Forms.PictureBox pic085;
        private System.Windows.Forms.PictureBox pic095;
        private System.Windows.Forms.PictureBox pic0A5;
        private System.Windows.Forms.PictureBox pic0B5;
        private System.Windows.Forms.PictureBox pic0C5;
        private System.Windows.Forms.PictureBox pic0D5;
        private System.Windows.Forms.PictureBox pic0E5;
        private System.Windows.Forms.PictureBox pic0F5;
        private System.Windows.Forms.PictureBox pic105;
        private System.Windows.Forms.PictureBox pic115;
        private System.Windows.Forms.PictureBox pic125;
        private System.Windows.Forms.PictureBox pic135;
        private System.Windows.Forms.PictureBox pic145;
        private System.Windows.Forms.PictureBox pic155;
        private System.Windows.Forms.PictureBox pic165;
        private System.Windows.Forms.PictureBox pic175;
        private System.Windows.Forms.PictureBox pic185;
        private System.Windows.Forms.PictureBox pic195;
        private System.Windows.Forms.PictureBox pic1A5;
        private System.Windows.Forms.PictureBox pic1B5;
        private System.Windows.Forms.PictureBox pic006;
        private System.Windows.Forms.PictureBox pic016;
        private System.Windows.Forms.PictureBox pic026;
        private System.Windows.Forms.PictureBox pic036;
        private System.Windows.Forms.PictureBox pic046;
        private System.Windows.Forms.PictureBox pic056;
        private System.Windows.Forms.PictureBox pic066;
        private System.Windows.Forms.PictureBox pic076;
        private System.Windows.Forms.PictureBox pic086;
        private System.Windows.Forms.PictureBox pic096;
        private System.Windows.Forms.PictureBox pic0A6;
        private System.Windows.Forms.PictureBox pic0B6;
        private System.Windows.Forms.PictureBox pic0C6;
        private System.Windows.Forms.PictureBox pic0D6;
        private System.Windows.Forms.PictureBox pic0E6;
        private System.Windows.Forms.PictureBox pic0F6;
        private System.Windows.Forms.PictureBox pic106;
        private System.Windows.Forms.PictureBox pic116;
        private System.Windows.Forms.PictureBox pic126;
        private System.Windows.Forms.PictureBox pic136;
        private System.Windows.Forms.PictureBox pic146;
        private System.Windows.Forms.PictureBox pic156;
        private System.Windows.Forms.PictureBox pic166;
        private System.Windows.Forms.PictureBox pic176;
        private System.Windows.Forms.PictureBox pic186;
        private System.Windows.Forms.PictureBox pic196;
        private System.Windows.Forms.PictureBox pic1A6;
        private System.Windows.Forms.PictureBox pic1B6;
        private System.Windows.Forms.PictureBox pic007;
        private System.Windows.Forms.PictureBox pic017;
        private System.Windows.Forms.PictureBox pic027;
        private System.Windows.Forms.PictureBox pic037;
        private System.Windows.Forms.PictureBox pic047;
        private System.Windows.Forms.PictureBox pic057;
        private System.Windows.Forms.PictureBox pic067;
        private System.Windows.Forms.PictureBox pic077;
        private System.Windows.Forms.PictureBox pic087;
        private System.Windows.Forms.PictureBox pic097;
        private System.Windows.Forms.PictureBox pic0A7;
        private System.Windows.Forms.PictureBox pic0B7;
        private System.Windows.Forms.PictureBox pic0C7;
        private System.Windows.Forms.PictureBox pic0D7;
        private System.Windows.Forms.PictureBox pic0E7;
        private System.Windows.Forms.PictureBox pic0F7;
        private System.Windows.Forms.PictureBox pic107;
        private System.Windows.Forms.PictureBox pic117;
        private System.Windows.Forms.PictureBox pic127;
        private System.Windows.Forms.PictureBox pic137;
        private System.Windows.Forms.PictureBox pic147;
        private System.Windows.Forms.PictureBox pic157;
        private System.Windows.Forms.PictureBox pic167;
        private System.Windows.Forms.PictureBox pic177;
        private System.Windows.Forms.PictureBox pic187;
        private System.Windows.Forms.PictureBox pic197;
        private System.Windows.Forms.PictureBox pic1A7;
        private System.Windows.Forms.PictureBox pic1B7;
        private System.Windows.Forms.PictureBox pic008;
        private System.Windows.Forms.PictureBox pic018;
        private System.Windows.Forms.PictureBox pic028;
        private System.Windows.Forms.PictureBox pic038;
        private System.Windows.Forms.PictureBox pic048;
        private System.Windows.Forms.PictureBox pic058;
        private System.Windows.Forms.PictureBox pic068;
        private System.Windows.Forms.PictureBox pic078;
        private System.Windows.Forms.PictureBox pic088;
        private System.Windows.Forms.PictureBox pic098;
        private System.Windows.Forms.PictureBox pic0A8;
        private System.Windows.Forms.PictureBox pic0B8;
        private System.Windows.Forms.PictureBox pic0C8;
        private System.Windows.Forms.PictureBox pic0D8;
        private System.Windows.Forms.PictureBox pic0E8;
        private System.Windows.Forms.PictureBox pic0F8;
        private System.Windows.Forms.PictureBox pic108;
        private System.Windows.Forms.PictureBox pic118;
        private System.Windows.Forms.PictureBox pic128;
        private System.Windows.Forms.PictureBox pic138;
        private System.Windows.Forms.PictureBox pic148;
        private System.Windows.Forms.PictureBox pic158;
        private System.Windows.Forms.PictureBox pic168;
        private System.Windows.Forms.PictureBox pic178;
        private System.Windows.Forms.PictureBox pic188;
        private System.Windows.Forms.PictureBox pic198;
        private System.Windows.Forms.PictureBox pic1A8;
        private System.Windows.Forms.PictureBox pic1B8;
        private System.Windows.Forms.PictureBox pic009;
        private System.Windows.Forms.PictureBox pic019;
        private System.Windows.Forms.PictureBox pic029;
        private System.Windows.Forms.PictureBox pic039;
        private System.Windows.Forms.PictureBox pic049;
        private System.Windows.Forms.PictureBox pic059;
        private System.Windows.Forms.PictureBox pic069;
        private System.Windows.Forms.PictureBox pic079;
        private System.Windows.Forms.PictureBox pic089;
        private System.Windows.Forms.PictureBox pic099;
        private System.Windows.Forms.PictureBox pic0A9;
        private System.Windows.Forms.PictureBox pic0B9;
        private System.Windows.Forms.PictureBox pic0C9;
        private System.Windows.Forms.PictureBox pic0D9;
        private System.Windows.Forms.PictureBox pic0E9;
        private System.Windows.Forms.PictureBox pic0F9;
        private System.Windows.Forms.PictureBox pic109;
        private System.Windows.Forms.PictureBox pic119;
        private System.Windows.Forms.PictureBox pic129;
        private System.Windows.Forms.PictureBox pic139;
        private System.Windows.Forms.PictureBox pic149;
        private System.Windows.Forms.PictureBox pic159;
        private System.Windows.Forms.PictureBox pic169;
        private System.Windows.Forms.PictureBox pic179;
        private System.Windows.Forms.PictureBox pic189;
        private System.Windows.Forms.PictureBox pic199;
        private System.Windows.Forms.PictureBox pic1A9;
        private System.Windows.Forms.PictureBox pic1B9;
        private System.Windows.Forms.PictureBox pic00A;
        private System.Windows.Forms.PictureBox pic01A;
        private System.Windows.Forms.PictureBox pic02A;
        private System.Windows.Forms.PictureBox pic03A;
        private System.Windows.Forms.PictureBox pic04A;
        private System.Windows.Forms.PictureBox pic05A;
        private System.Windows.Forms.PictureBox pic06A;
        private System.Windows.Forms.PictureBox pic07A;
        private System.Windows.Forms.PictureBox pic08A;
        private System.Windows.Forms.PictureBox pic09A;
        private System.Windows.Forms.PictureBox pic0AA;
        private System.Windows.Forms.PictureBox pic0BA;
        private System.Windows.Forms.PictureBox pic0CA;
        private System.Windows.Forms.PictureBox pic0DA;
        private System.Windows.Forms.PictureBox pic0EA;
        private System.Windows.Forms.PictureBox pic0FA;
        private System.Windows.Forms.PictureBox pic10A;
        private System.Windows.Forms.PictureBox pic11A;
        private System.Windows.Forms.PictureBox pic12A;
        private System.Windows.Forms.PictureBox pic13A;
        private System.Windows.Forms.PictureBox pic14A;
        private System.Windows.Forms.PictureBox pic15A;
        private System.Windows.Forms.PictureBox pic16A;
        private System.Windows.Forms.PictureBox pic17A;
        private System.Windows.Forms.PictureBox pic18A;
        private System.Windows.Forms.PictureBox pic19A;
        private System.Windows.Forms.PictureBox pic1AA;
        private System.Windows.Forms.PictureBox pic1BA;
        private System.Windows.Forms.PictureBox pic00B;
        private System.Windows.Forms.PictureBox pic01B;
        private System.Windows.Forms.PictureBox pic02B;
        private System.Windows.Forms.PictureBox pic03B;
        private System.Windows.Forms.PictureBox pic04B;
        private System.Windows.Forms.PictureBox pic05B;
        private System.Windows.Forms.PictureBox pic06B;
        private System.Windows.Forms.PictureBox pic07B;
        private System.Windows.Forms.PictureBox pic08B;
        private System.Windows.Forms.PictureBox pic09B;
        private System.Windows.Forms.PictureBox pic0AB;
        private System.Windows.Forms.PictureBox pic0BB;
        private System.Windows.Forms.PictureBox pic0CB;
        private System.Windows.Forms.PictureBox pic0DB;
        private System.Windows.Forms.PictureBox pic0EB;
        private System.Windows.Forms.PictureBox pic0FB;
        private System.Windows.Forms.PictureBox pic10B;
        private System.Windows.Forms.PictureBox pic11B;
        private System.Windows.Forms.PictureBox pic12B;
        private System.Windows.Forms.PictureBox pic13B;
        private System.Windows.Forms.PictureBox pic14B;
        private System.Windows.Forms.PictureBox pic15B;
        private System.Windows.Forms.PictureBox pic16B;
        private System.Windows.Forms.PictureBox pic17B;
        private System.Windows.Forms.PictureBox pic18B;
        private System.Windows.Forms.PictureBox pic19B;
        private System.Windows.Forms.PictureBox pic1AB;
        private System.Windows.Forms.PictureBox pic1BB;
        private System.Windows.Forms.PictureBox pic00C;
        private System.Windows.Forms.PictureBox pic01C;
        private System.Windows.Forms.PictureBox pic02C;
        private System.Windows.Forms.PictureBox pic03C;
        private System.Windows.Forms.PictureBox pic04C;
        private System.Windows.Forms.PictureBox pic05C;
        private System.Windows.Forms.PictureBox pic06C;
        private System.Windows.Forms.PictureBox pic07C;
        private System.Windows.Forms.PictureBox pic08C;
        private System.Windows.Forms.PictureBox pic09C;
        private System.Windows.Forms.PictureBox pic0AC;
        private System.Windows.Forms.PictureBox pic0BC;
        private System.Windows.Forms.PictureBox pic0CC;
        private System.Windows.Forms.PictureBox pic0DC;
        private System.Windows.Forms.PictureBox pic0EC;
        private System.Windows.Forms.PictureBox pic0FC;
        private System.Windows.Forms.PictureBox pic10C;
        private System.Windows.Forms.PictureBox pic11C;
        private System.Windows.Forms.PictureBox pic12C;
        private System.Windows.Forms.PictureBox pic13C;
        private System.Windows.Forms.PictureBox pic14C;
        private System.Windows.Forms.PictureBox pic15C;
        private System.Windows.Forms.PictureBox pic16C;
        private System.Windows.Forms.PictureBox pic17C;
        private System.Windows.Forms.PictureBox pic18C;
        private System.Windows.Forms.PictureBox pic19C;
        private System.Windows.Forms.PictureBox pic1AC;
        private System.Windows.Forms.PictureBox pic1BC;
        private System.Windows.Forms.PictureBox pic00D;
        private System.Windows.Forms.PictureBox pic01D;
        private System.Windows.Forms.PictureBox pic02D;
        private System.Windows.Forms.PictureBox pic03D;
        private System.Windows.Forms.PictureBox pic04D;
        private System.Windows.Forms.PictureBox pic05D;
        private System.Windows.Forms.PictureBox pic06D;
        private System.Windows.Forms.PictureBox pic07D;
        private System.Windows.Forms.PictureBox pic08D;
        private System.Windows.Forms.PictureBox pic09D;
        private System.Windows.Forms.PictureBox pic0AD;
        private System.Windows.Forms.PictureBox pic0BD;
        private System.Windows.Forms.PictureBox pic0CD;
        private System.Windows.Forms.PictureBox pic0DD;
        private System.Windows.Forms.PictureBox pic0ED;
        private System.Windows.Forms.PictureBox pic0FD;
        private System.Windows.Forms.PictureBox pic10D;
        private System.Windows.Forms.PictureBox pic11D;
        private System.Windows.Forms.PictureBox pic12D;
        private System.Windows.Forms.PictureBox pic13D;
        private System.Windows.Forms.PictureBox pic14D;
        private System.Windows.Forms.PictureBox pic15D;
        private System.Windows.Forms.PictureBox pic16D;
        private System.Windows.Forms.PictureBox pic17D;
        private System.Windows.Forms.PictureBox pic18D;
        private System.Windows.Forms.PictureBox pic19D;
        private System.Windows.Forms.PictureBox pic1AD;
        private System.Windows.Forms.PictureBox pic1BD;
        private System.Windows.Forms.PictureBox pic00E;
        private System.Windows.Forms.PictureBox pic01E;
        private System.Windows.Forms.PictureBox pic02E;
        private System.Windows.Forms.PictureBox pic03E;
        private System.Windows.Forms.PictureBox pic04E;
        private System.Windows.Forms.PictureBox pic05E;
        private System.Windows.Forms.PictureBox pic06E;
        private System.Windows.Forms.PictureBox pic07E;
        private System.Windows.Forms.PictureBox pic08E;
        private System.Windows.Forms.PictureBox pic09E;
        private System.Windows.Forms.PictureBox pic0AE;
        private System.Windows.Forms.PictureBox pic0BE;
        private System.Windows.Forms.PictureBox pic0CE;
        private System.Windows.Forms.PictureBox pic0DE;
        private System.Windows.Forms.PictureBox pic0EE;
        private System.Windows.Forms.PictureBox pic0FE;
        private System.Windows.Forms.PictureBox pic10E;
        private System.Windows.Forms.PictureBox pic11E;
        private System.Windows.Forms.PictureBox pic12E;
        private System.Windows.Forms.PictureBox pic13E;
        private System.Windows.Forms.PictureBox pic14E;
        private System.Windows.Forms.PictureBox pic15E;
        private System.Windows.Forms.PictureBox pic16E;
        private System.Windows.Forms.PictureBox pic17E;
        private System.Windows.Forms.PictureBox pic18E;
        private System.Windows.Forms.PictureBox pic19E;
        private System.Windows.Forms.PictureBox pic1AE;
        private System.Windows.Forms.PictureBox pic1BE;
        private System.Windows.Forms.PictureBox pic00F;
        private System.Windows.Forms.PictureBox pic01F;
        private System.Windows.Forms.PictureBox pic02F;
        private System.Windows.Forms.PictureBox pic03F;
        private System.Windows.Forms.PictureBox pic04F;
        private System.Windows.Forms.PictureBox pic05F;
        private System.Windows.Forms.PictureBox pic06F;
        private System.Windows.Forms.PictureBox pic07F;
        private System.Windows.Forms.PictureBox pic08F;
        private System.Windows.Forms.PictureBox pic09F;
        private System.Windows.Forms.PictureBox pic0AF;
        private System.Windows.Forms.PictureBox pic0BF;
        private System.Windows.Forms.PictureBox pic0CF;
        private System.Windows.Forms.PictureBox pic0DF;
        private System.Windows.Forms.PictureBox pic0EF;
        private System.Windows.Forms.PictureBox pic0FF;
        private System.Windows.Forms.PictureBox pic10F;
        private System.Windows.Forms.PictureBox pic11F;
        private System.Windows.Forms.PictureBox pic12F;
        private System.Windows.Forms.PictureBox pic13F;
        private System.Windows.Forms.PictureBox pic14F;
        private System.Windows.Forms.PictureBox pic15F;
        private System.Windows.Forms.PictureBox pic16F;
        private System.Windows.Forms.PictureBox pic17F;
        private System.Windows.Forms.PictureBox pic18F;
        private System.Windows.Forms.PictureBox pic19F;
        private System.Windows.Forms.PictureBox pic1AF;
        private System.Windows.Forms.PictureBox pic1BF;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
    }
}

